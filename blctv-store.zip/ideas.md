# BLCTV Store — Brainstorm Design

## Contexte
Site vitrine pour vendre des abonnements IPTV. Logo : icône B/play en bleu métallique glacé avec texte "BLCTV STORE". Fonctionnalités : paiement Stripe, téléchargement APK, tutoriels vidéo Vimeo.

---

<response>
<idea>

## Idée 1 — "Cinematic Dark Theater"

**Design Movement** : Dark UI cinématographique inspirée des plateformes de streaming premium (Netflix, Disney+)

**Core Principles** :
- Fond sombre profond (#0A0E1A) avec des accents bleu glacé lumineux qui rappellent le logo
- Hiérarchie visuelle forte avec des contrastes marqués
- Sensation immersive de "salle de cinéma" avec des effets de lumière subtils

**Color Philosophy** : Le noir profond évoque le premium et le cinéma. Le bleu glacé métallique (#3B9FD8 → #7DD3FC) apporte la touche technologique et futuriste. Des touches de blanc pur pour la lisibilité.

**Layout Paradigm** : Sections plein écran empilées verticalement avec des transitions fluides. Hero section immersive avec le logo en grand. Cards de pricing flottantes avec effet glassmorphism.

**Signature Elements** :
- Effet glassmorphism (verre dépoli) sur les cartes de prix
- Glow bleu subtil autour des éléments interactifs
- Particules lumineuses en arrière-plan du hero

**Interaction Philosophy** : Hover effects avec glow bleu, transitions douces, scroll reveal animations

**Animation** : Fade-in au scroll, glow pulsant sur les CTA, hover scale sur les cards

**Typography System** : Orbitron pour les titres (futuriste), Outfit pour le corps (moderne et lisible)

</idea>
<probability>0.08</probability>
<text>Approche cinématographique sombre premium</text>
</response>

<response>
<idea>

## Idée 2 — "Frosted Glass Tech"

**Design Movement** : Glassmorphism nordique avec une palette froide et épurée

**Core Principles** :
- Fond avec dégradé subtil du bleu très foncé au noir avec des formes géométriques floues
- Surfaces en verre dépoli (backdrop-blur) omniprésentes
- Minimalisme fonctionnel avec beaucoup d'espace blanc/négatif

**Color Philosophy** : Dégradé de fond du #050B18 au #0C1B3A. Surfaces glassmorphism en blanc 10% opacité. Accents en bleu glacé (#4DB8E8) et cyan (#00D4FF). Le bleu métallique du logo est la couleur signature.

**Layout Paradigm** : Layout asymétrique avec une grille décalée. Hero avec le logo flottant sur un fond de particules. Section pricing en grille 3 colonnes avec cards en verre. Sidebar flottante pour la navigation.

**Signature Elements** :
- Cards en verre dépoli avec bordure bleu subtile lumineuse
- Orbes de lumière bleue floues en arrière-plan
- Lignes de grille subtiles rappelant un circuit imprimé

**Interaction Philosophy** : Les éléments réagissent à la proximité du curseur avec un glow. Les cards se soulèvent au hover avec une ombre bleue.

**Animation** : Parallax subtil sur les orbes de fond, stagger animations sur les cards, morphing smooth entre sections

**Typography System** : Space Grotesk pour les titres (géométrique, tech), DM Sans pour le corps (neutre, moderne)

</idea>
<probability>0.06</probability>
<text>Glassmorphism nordique tech</text>
</response>

<response>
<idea>

## Idée 3 — "Electric Neon Stream"

**Design Movement** : Cyberpunk néon avec une esthétique de flux de données

**Core Principles** :
- Fond noir absolu avec des lignes de néon bleu qui traversent la page
- Énergie visuelle forte avec des contrastes extrêmes
- Sensation de vitesse et de flux de données/streaming

**Color Philosophy** : Noir pur (#000000) comme toile. Bleu électrique (#00A3FF) comme couleur primaire néon. Cyan (#00FFFF) pour les accents. Le gradient du logo se retrouve dans les effets de glow.

**Layout Paradigm** : Sections séparées par des lignes de néon horizontales. Hero avec effet de "tunnel de données". Cards de pricing avec bordures néon animées. Layout en Z pour guider l'œil.

**Signature Elements** :
- Bordures néon animées qui "courent" autour des éléments
- Effet de scan line subtil rappelant un écran CRT
- Trails de lumière bleue qui suivent le scroll

**Interaction Philosophy** : Effets néon au hover, transitions rapides et énergiques, feedback visuel immédiat

**Animation** : Néon flicker subtil, border-running animations, glitch effects légers sur les transitions

**Typography System** : Rajdhani pour les titres (angulaire, tech), Exo 2 pour le corps (futuriste mais lisible)

</idea>
<probability>0.04</probability>
<text>Cyberpunk néon streaming</text>
</response>

---

## Choix retenu : Idée 2 — "Frosted Glass Tech"

Cette approche est la plus cohérente avec le logo BLCTV Store qui a un rendu métallique glacé/chrome. Le glassmorphism nordique renforce cette esthétique de verre et de glace tout en restant premium et professionnel. Les orbes de lumière bleue en fond créent une ambiance immersive sans être trop agressive comme le cyberpunk.
