/*
 * BLCTV Store — Frosted Glass Tech Design
 * Home page: assembles all sections into a single-page experience
 */
import { useEffect } from "react";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import DiscoverSection from "@/components/DiscoverSection";
import TVShowcaseSection from "@/components/TVShowcaseSection";
import StreamingContentSection from "@/components/StreamingContentSection";
import AboutSection from "@/components/AboutSection";
import FeaturesSection from "@/components/FeaturesSection";
import ChannelsSection from "@/components/ChannelsSection";
import PricingSection from "@/components/PricingSection";
import DownloadSection from "@/components/DownloadSection";
import TutorialsSection from "@/components/TutorialsSection";
import FooterSection from "@/components/FooterSection";
import ChatWidget from "@/components/ChatWidget";

export default function Home() {
  useEffect(() => {
    document.title = "BLCTV Store - Abonnement IPTV Premium 4K | Chaînes TV";
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      <HeroSection />
      <DiscoverSection />
      <TVShowcaseSection />
      <StreamingContentSection />
      <AboutSection />
      <FeaturesSection />
      <ChannelsSection />
      <PricingSection />
      <DownloadSection />
      <TutorialsSection />
      <FooterSection />
      <ChatWidget />
    </div>
  );
}
