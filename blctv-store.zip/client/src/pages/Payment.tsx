/**
 * Page de paiement intégrée — Le client ne voit que des euros
 * Crée une facture NowPayments via le serveur et redirige vers la page de paiement
 */
import { useState } from "react";
import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import {
  CreditCard,
  Shield,
  Lock,
  CheckCircle2,
  ArrowLeft,
  Loader2,
  Mail,
} from "lucide-react";

const PLAN_DETAILS: Record<
  string,
  { title: string; price: string; period: string; features: string[] }
> = {
  test6: {
    title: "Test 7 jours",
    price: "6€",
    period: "7 jours",
    features: [
      "Accès complet pendant 7 jours",
      "10 000+ chaînes TV",
      "25 000+ films",
      "Qualité 4K Ultra HD",
    ],
  },
  "12mois_new": {
    title: "Abonnement 12 Mois",
    price: "150€",
    period: "12 mois",
    features: [
      "Accès illimité 12 mois",
      "10 000+ chaînes TV",
      "25 000+ films & 7 000+ séries",
      "3 appareils connectés",
      "Support prioritaire 24/7",
    ],
  },
  "12mois_renew": {
    title: "Renouvellement 12 Mois",
    price: "100€",
    period: "12 mois",
    features: [
      "Renouvellement client existant",
      "Accès illimité 12 mois",
      "10 000+ chaînes TV",
      "25 000+ films & 7 000+ séries",
      "Support prioritaire 24/7",
    ],
  },
  "24mois": {
    title: "Abonnement 24 Mois",
    price: "200€",
    period: "24 mois",
    features: [
      "Accès illimité 24 mois",
      "10 000+ chaînes TV",
      "25 000+ films & 7 000+ séries",
      "5 appareils connectés",
      "Assistance VIP offerte",
    ],
  },
  adultes: {
    title: "Option Chaînes Adultes",
    price: "50€",
    period: "durée de l'abonnement",
    features: [
      "Accès aux chaînes adultes",
      "Ajout à votre abonnement existant",
      "Activation immédiate",
    ],
  },
};

export default function Payment() {
  const [, params] = useRoute("/paiement/:planId");
  const planId = params?.planId || "";
  const plan = PLAN_DETAILS[planId];

  const [email, setEmail] = useState("");
  const [isRedirecting, setIsRedirecting] = useState(false);
  const [error, setError] = useState("");

  const createInvoice = trpc.payment.createInvoice.useMutation({
    onSuccess: (data) => {
      setIsRedirecting(true);
      // Redirect to NowPayments invoice page
      window.location.href = data.invoiceUrl;
    },
    onError: (err) => {
      setError(err.message || "Erreur lors de la création du paiement. Veuillez réessayer.");
      setIsRedirecting(false);
    },
  });

  if (!plan) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Offre introuvable</h1>
          <a
            href="/#pricing"
            className="text-[oklch(0.72_0.15_210)] hover:underline"
          >
            Retour aux offres
          </a>
        </div>
      </div>
    );
  }

  const handlePay = () => {
    setError("");
    createInvoice.mutate({
      planId: planId as "test6" | "12mois_new" | "12mois_renew" | "24mois" | "adultes",
      email: email || undefined,
      origin: window.location.origin,
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-[oklch(0.25_0.03_250/40%)]">
        <div className="container py-4 flex items-center gap-4">
          <a
            href="/#pricing"
            className="flex items-center gap-2 text-sm text-[oklch(0.65_0.03_250)] hover:text-white transition-colors"
          >
            <ArrowLeft size={16} />
            Retour aux offres
          </a>
          <div className="flex items-center gap-2 ml-auto text-xs text-[oklch(0.55_0.03_250)]">
            <Lock size={12} />
            Paiement sécurisé
          </div>
        </div>
      </div>

      <div className="container py-12 max-w-4xl mx-auto">
        <div className="grid md:grid-cols-5 gap-8">
          {/* Left — Order summary */}
          <div className="md:col-span-2">
            <div className="glass-card rounded-2xl p-6 sticky top-8">
              <h2 className="text-lg font-bold text-white mb-4">
                Récapitulatif
              </h2>

              <div className="space-y-3 mb-6">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[oklch(0.65_0.03_250)]">
                    Offre
                  </span>
                  <span className="text-sm font-semibold text-white">
                    {plan.title}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[oklch(0.65_0.03_250)]">
                    Durée
                  </span>
                  <span className="text-sm text-white">{plan.period}</span>
                </div>
                <div className="border-t border-[oklch(0.25_0.03_250/40%)] pt-3">
                  <div className="flex justify-between items-center">
                    <span className="text-base font-bold text-white">
                      Total
                    </span>
                    <span className="text-2xl font-bold text-[oklch(0.72_0.15_210)] neon-text">
                      {plan.price}
                    </span>
                  </div>
                </div>
              </div>

              <ul className="space-y-2">
                {plan.features.map((feat) => (
                  <li
                    key={feat}
                    className="flex items-start gap-2 text-xs text-[oklch(0.65_0.03_250)]"
                  >
                    <CheckCircle2
                      size={12}
                      className="mt-0.5 shrink-0 text-[oklch(0.72_0.15_210)]"
                    />
                    {feat}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Right — Payment form */}
          <div className="md:col-span-3">
            <div className="glass-card rounded-2xl p-8">
              <div className="flex items-center gap-3 mb-6">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center bg-[oklch(0.55_0.18_240/15%)]"
                  style={{
                    boxShadow: "0 0 20px oklch(0.65 0.18 240 / 30%)",
                  }}
                >
                  <CreditCard
                    size={24}
                    className="text-[oklch(0.72_0.15_210)]"
                  />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">Paiement</h1>
                  <p className="text-xs text-[oklch(0.55_0.03_250)]">
                    Paiement sécurisé — Montant en euros
                  </p>
                </div>
              </div>

              {/* Email field (optional) */}
              <div className="mb-6">
                <label className="text-sm text-[oklch(0.65_0.03_250)] mb-2 block">
                  Email (optionnel — pour recevoir la confirmation)
                </label>
                <div className="relative">
                  <Mail
                    size={16}
                    className="absolute left-4 top-1/2 -translate-y-1/2 text-[oklch(0.45_0.03_250)]"
                  />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="votre@email.com"
                    className="w-full pl-11 pr-4 py-3 rounded-xl text-sm bg-[oklch(0.10_0.015_250/80%)] border border-[oklch(0.30_0.04_250/40%)] text-white placeholder:text-[oklch(0.40_0.03_250)] focus:outline-none focus:border-[oklch(0.55_0.15_240/60%)] transition-colors"
                  />
                </div>
              </div>

              {/* Info box */}
              <div className="mb-6 p-4 rounded-xl bg-[oklch(0.20_0.04_240/30%)] border border-[oklch(0.35_0.08_240/30%)]">
                <p className="text-xs text-[oklch(0.70_0.05_240)] leading-relaxed">
                  Vous allez être redirigé vers notre page de paiement sécurisée.
                  Le montant affiché est en <strong>euros (€)</strong>.
                  Plusieurs méthodes de paiement sont disponibles.
                  Votre abonnement sera activé dès réception du paiement.
                </p>
              </div>

              {error && (
                <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
                  {error}
                </div>
              )}

              {/* Pay button */}
              <button
                onClick={handlePay}
                disabled={createInvoice.isPending || isRedirecting}
                className="w-full py-4 rounded-xl font-bold text-base text-white bg-[oklch(0.55_0.18_240)] hover:bg-[oklch(0.60_0.20_240)] transition-all duration-300 flex items-center justify-center gap-3 glow-blue-hover disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {createInvoice.isPending || isRedirecting ? (
                  <>
                    <Loader2 size={20} className="animate-spin" />
                    {isRedirecting
                      ? "Redirection vers le paiement..."
                      : "Création du paiement..."}
                  </>
                ) : (
                  <>
                    <Lock size={18} />
                    Payer {plan.price}
                  </>
                )}
              </button>

              {/* Trust badges */}
              <div className="flex flex-wrap justify-center gap-4 mt-6 text-xs text-[oklch(0.50_0.03_250)]">
                <div className="flex items-center gap-1.5">
                  <Shield size={12} className="text-[oklch(0.72_0.15_210)]" />
                  Paiement sécurisé SSL
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2
                    size={12}
                    className="text-[oklch(0.72_0.15_210)]"
                  />
                  Activation instantanée
                </div>
                <div className="flex items-center gap-1.5">
                  <Lock size={12} className="text-[oklch(0.72_0.15_210)]" />
                  Données protégées
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
