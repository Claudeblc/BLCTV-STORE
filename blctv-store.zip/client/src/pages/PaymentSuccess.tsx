/**
 * Page de confirmation de paiement réussi
 */
import { CheckCircle2, ArrowLeft, MessageCircle } from "lucide-react";

export default function PaymentSuccess() {
  const params = new URLSearchParams(window.location.search);
  const orderId = params.get("order") || "";
  const planId = params.get("plan") || "";

  const planNames: Record<string, string> = {
    test6: "Test 7 jours",
    "12mois_new": "Abonnement 12 Mois",
    "12mois_renew": "Renouvellement 12 Mois",
    "24mois": "Abonnement 24 Mois",
    adultes: "Option Chaînes Adultes",
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-4">
      <div className="glass-card rounded-2xl p-8 max-w-md w-full text-center">
        <div
          className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 bg-[oklch(0.25_0.10_150/40%)]"
          style={{ boxShadow: "0 0 30px oklch(0.55 0.18 150 / 30%)" }}
        >
          <CheckCircle2 size={40} className="text-[oklch(0.72_0.18_150)]" />
        </div>

        <h1 className="text-2xl font-bold text-white mb-2">
          Paiement en cours de traitement
        </h1>
        <p className="text-[oklch(0.65_0.03_250)] mb-6">
          Votre paiement pour{" "}
          <strong className="text-white">
            {planNames[planId] || "votre abonnement"}
          </strong>{" "}
          est en cours de traitement. Vous recevrez vos identifiants dès
          confirmation.
        </p>

        {orderId && (
          <div className="mb-6 p-3 rounded-xl bg-[oklch(0.15_0.02_250/60%)] border border-[oklch(0.30_0.04_250/30%)]">
            <p className="text-xs text-[oklch(0.55_0.03_250)]">
              Référence commande
            </p>
            <p className="text-sm font-mono text-white mt-1">{orderId}</p>
          </div>
        )}

        <div className="space-y-3">
          <a
            href="/"
            className="w-full py-3 rounded-xl font-semibold text-sm text-white bg-[oklch(0.55_0.18_240)] hover:bg-[oklch(0.60_0.20_240)] transition-all duration-300 flex items-center justify-center gap-2"
          >
            <ArrowLeft size={16} />
            Retour à l'accueil
          </a>
          <button
            onClick={() => {
              window.location.href = "/";
              setTimeout(() => {
                window.dispatchEvent(
                  new CustomEvent("open-chat-with-message", {
                    detail: {
                      message: `Bonjour, je viens d'effectuer un paiement (réf: ${orderId}). Quand recevrai-je mes identifiants ?`,
                    },
                  })
                );
              }, 1000);
            }}
            className="w-full py-3 rounded-xl font-semibold text-sm text-[oklch(0.80_0.10_240)] border border-[oklch(0.50_0.15_240/40%)] hover:bg-[oklch(0.20_0.03_250/40%)] transition-all duration-300 flex items-center justify-center gap-2"
          >
            <MessageCircle size={16} />
            Contacter le support
          </button>
        </div>
      </div>
    </div>
  );
}
