/**
 * Page d'annulation de paiement
 */
import { XCircle, ArrowLeft } from "lucide-react";

export default function PaymentCancel() {
  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-4">
      <div className="glass-card rounded-2xl p-8 max-w-md w-full text-center">
        <div
          className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 bg-[oklch(0.25_0.10_30/40%)]"
          style={{ boxShadow: "0 0 30px oklch(0.55 0.18 30 / 30%)" }}
        >
          <XCircle size={40} className="text-[oklch(0.72_0.18_30)]" />
        </div>

        <h1 className="text-2xl font-bold text-white mb-2">
          Paiement annulé
        </h1>
        <p className="text-[oklch(0.65_0.03_250)] mb-6">
          Votre paiement a été annulé. Aucun montant n'a été débité.
          Vous pouvez réessayer à tout moment.
        </p>

        <a
          href="/#pricing"
          className="w-full py-3 rounded-xl font-semibold text-sm text-white bg-[oklch(0.55_0.18_240)] hover:bg-[oklch(0.60_0.20_240)] transition-all duration-300 flex items-center justify-center gap-2"
        >
          <ArrowLeft size={16} />
          Retour aux offres
        </a>
      </div>
    </div>
  );
}
