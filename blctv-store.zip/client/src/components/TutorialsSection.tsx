/*
 * BLCTV Store — Frosted Glass Tech Design
 * Tutorials: Video tutorials for playlist setup
 * Responsive: stacked on mobile, grid on tablet/desktop
 */
import { motion } from "framer-motion";
import { PlayCircle, BookOpen } from "lucide-react";
import { useState } from "react";

const TUTO_VIDEO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/tuto-playlist_93acd7bb.mp4";

const tutorials = [
  {
    title: "Ajouter une liste de lecture",
    description: "Découvrez comment configurer votre liste de lecture (playlist) pour accéder à toutes vos chaînes, films et séries sur BLCTV Player.",
    videoUrl: TUTO_VIDEO_URL,
    featured: true,
  },
  {
    title: "Installation sur Mobile",
    description: "Apprenez à installer BLCTV Player sur votre smartphone ou tablette Android en quelques minutes.",
    videoUrl: "",
    featured: false,
  },
  {
    title: "Configuration sur Smart TV",
    description: "Guide pas à pas pour configurer BLCTV Player sur votre Smart TV ou Fire Stick.",
    videoUrl: "",
    featured: false,
  },
];

export default function TutorialsSection() {
  const [playingIdx, setPlayingIdx] = useState<number | null>(null);

  return (
    <section id="tutorials" className="relative py-16 sm:py-24 overflow-hidden">
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] rounded-full bg-[oklch(0.55_0.15_240/4%)] blur-[130px] pointer-events-none" />

      <div className="container relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10 sm:mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-semibold tracking-wider uppercase text-[oklch(0.72_0.15_210)] bg-[oklch(0.65_0.18_240/10%)] neon-border mb-4">
            <BookOpen size={14} className="inline mr-1.5 -mt-0.5" />
            Tutoriels
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-3 sm:mb-4">
            Guides <span className="text-gradient-blue neon-text">d'installation IPTV</span>
          </h2>
          <p className="text-base sm:text-lg text-[oklch(0.65_0.03_250)] md:text-xl max-w-2xl mx-auto">
            Tutoriels vidéo pour installer et configurer votre abonnement IPTV BLCTV Store sur Android TV, Fire Stick, smartphone et ordinateur. Installation facile même pour les débutants.
          </p>
        </motion.div>

        {/* Featured tutorial — large video */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto mb-8 sm:mb-12"
        >
          <div className="glass-card rounded-xl sm:rounded-2xl overflow-hidden group">
            <div className="relative aspect-video overflow-hidden bg-[oklch(0.08_0.02_250)]">
              <video
                src={TUTO_VIDEO_URL}
                controls
                playsInline
                preload="metadata"
                className="w-full h-full object-contain"
                poster=""
              >
                Votre navigateur ne supporte pas la lecture vidéo.
              </video>
            </div>
            <div className="p-4 sm:p-6 space-y-2">
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider text-[oklch(0.90_0.10_140)] bg-[oklch(0.55_0.18_140/20%)]">
                  Nouveau
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider text-[oklch(0.72_0.15_210)] bg-[oklch(0.55_0.18_240/15%)]">
                  Essentiel
                </span>
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-white">
                {tutorials[0].title}
              </h3>
              <p className="text-sm sm:text-base text-[oklch(0.65_0.03_250)] leading-relaxed">
                {tutorials[0].description}
              </p>
            </div>
          </div>
        </motion.div>

        {/* Other tutorials */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 max-w-4xl mx-auto">
          {tutorials.slice(1).map((tuto, i) => (
            <motion.div
              key={tuto.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.15 }}
              className="glass-card rounded-xl sm:rounded-2xl overflow-hidden group"
            >
              <div className="relative aspect-video overflow-hidden bg-[oklch(0.10_0.02_250)]">
                {tuto.videoUrl ? (
                  <video
                    src={tuto.videoUrl}
                    controls
                    playsInline
                    preload="metadata"
                    className="w-full h-full object-contain"
                  >
                    Votre navigateur ne supporte pas la lecture vidéo.
                  </video>
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-[oklch(0.12_0.03_240)] to-[oklch(0.08_0.02_250)]">
                    <div className="text-center">
                      <PlayCircle size={36} className="text-[oklch(0.72_0.15_210)] opacity-50 mx-auto mb-2 sm:mb-3" />
                      <span className="text-sm sm:text-base text-[oklch(0.55_0.03_250)]">
                        Vidéo bientôt disponible
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <div className="p-4 sm:p-5 space-y-1.5 sm:space-y-2">
                <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-[oklch(0.72_0.15_210)] transition-colors">
                  {tuto.title}
                </h3>
                <p className="text-sm sm:text-base text-[oklch(0.60_0.03_250)] leading-relaxed">
                  {tuto.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
