/*
 * BLCTV Store — CSS/HTML Device Mockup
 * Pure CSS device frames with real app screenshots — no background residue
 */

const APP_HOME = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/Screenshot_20260304-004005_02753cc8.png";
const APP_BROWSE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/Screenshot_20260304-004020_ef5faba7.png";

export default function DevicesMockup() {
  return (
    <div className="relative w-full h-full flex items-center justify-center" style={{ minHeight: 460 }}>
      {/* === TV / Monitor — back center === */}
      <div
        className="absolute z-10"
        style={{ top: 0, left: "50%", transform: "translateX(-50%)" }}
      >
        <div
          className="relative rounded-lg overflow-hidden"
          style={{
            width: 380,
            border: "3px solid oklch(0.30 0.06 240)",
            boxShadow: "0 0 20px oklch(0.55 0.18 240 / 20%), 0 8px 32px rgba(0,0,0,0.5)",
            background: "oklch(0.08 0.02 250)",
          }}
        >
          {/* Screen */}
          <img
            src={APP_HOME}
            alt="BLCTV sur TV"
            className="w-full h-auto block"
            style={{ aspectRatio: "16/9", objectFit: "cover" }}
          />
          {/* Stand */}
          <div
            className="mx-auto"
            style={{
              width: 80,
              height: 4,
              background: "oklch(0.25 0.04 240)",
              borderRadius: "0 0 4px 4px",
            }}
          />
        </div>
        {/* TV Stand base */}
        <div
          className="mx-auto"
          style={{
            width: 120,
            height: 6,
            marginTop: 2,
            background: "linear-gradient(to right, transparent, oklch(0.30 0.06 240), transparent)",
            borderRadius: 4,
          }}
        />
      </div>

      {/* === Laptop — bottom left === */}
      <div
        className="absolute z-20"
        style={{ bottom: 0, left: 0 }}
      >
        <div
          className="relative rounded-t-lg overflow-hidden"
          style={{
            width: 260,
            border: "3px solid oklch(0.25 0.05 240)",
            borderBottom: "none",
            boxShadow: "0 0 15px oklch(0.55 0.18 240 / 15%), 0 8px 24px rgba(0,0,0,0.4)",
            background: "oklch(0.08 0.02 250)",
          }}
        >
          <img
            src={APP_BROWSE}
            alt="BLCTV sur Laptop"
            className="w-full h-auto block"
            style={{ aspectRatio: "16/10", objectFit: "cover" }}
          />
        </div>
        {/* Laptop base/keyboard */}
        <div
          style={{
            width: 290,
            height: 12,
            marginLeft: -15,
            background: "linear-gradient(to bottom, oklch(0.28 0.05 240), oklch(0.20 0.04 240))",
            borderRadius: "0 0 6px 6px",
            boxShadow: "0 2px 8px rgba(0,0,0,0.3)",
          }}
        >
          {/* Trackpad indicator */}
          <div
            className="mx-auto"
            style={{
              width: 50,
              height: 3,
              marginTop: 4,
              background: "oklch(0.35 0.04 240)",
              borderRadius: 2,
            }}
          />
        </div>
      </div>

      {/* === Tablet — bottom center-right === */}
      <div
        className="absolute z-30"
        style={{ bottom: 10, right: 80 }}
      >
        <div
          className="relative rounded-xl overflow-hidden"
          style={{
            width: 180,
            border: "3px solid oklch(0.25 0.05 240)",
            boxShadow: "0 0 15px oklch(0.55 0.18 240 / 15%), 0 8px 24px rgba(0,0,0,0.4)",
            background: "oklch(0.08 0.02 250)",
          }}
        >
          <img
            src={APP_BROWSE}
            alt="BLCTV sur Tablette"
            className="w-full h-auto block"
            style={{ aspectRatio: "4/3", objectFit: "cover" }}
          />
        </div>
      </div>

      {/* === Phone — bottom right === */}
      <div
        className="absolute z-40"
        style={{ bottom: 20, right: 15 }}
      >
        <div
          className="relative rounded-2xl overflow-hidden"
          style={{
            width: 90,
            border: "3px solid oklch(0.25 0.05 240)",
            boxShadow: "0 0 12px oklch(0.55 0.18 240 / 20%), 0 8px 20px rgba(0,0,0,0.4)",
            background: "oklch(0.08 0.02 250)",
          }}
        >
          {/* Notch */}
          <div
            className="mx-auto"
            style={{
              width: 30,
              height: 4,
              marginTop: 3,
              marginBottom: 2,
              background: "oklch(0.20 0.03 240)",
              borderRadius: 4,
            }}
          />
          <img
            src={APP_HOME}
            alt="BLCTV sur Smartphone"
            className="w-full h-auto block"
            style={{ aspectRatio: "9/16", objectFit: "cover" }}
          />
          {/* Home indicator */}
          <div
            className="mx-auto"
            style={{
              width: 30,
              height: 3,
              marginTop: 3,
              marginBottom: 4,
              background: "oklch(0.35 0.04 240)",
              borderRadius: 4,
            }}
          />
        </div>
      </div>
    </div>
  );
}
