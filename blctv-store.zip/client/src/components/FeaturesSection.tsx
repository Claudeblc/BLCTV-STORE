/*
 * BLCTV Store — Frosted Glass Tech Design
 * Features: glassmorphism cards showcasing IPTV service highlights
 * Responsive: stacked on mobile, grid on tablet/desktop
 */
import { motion } from "framer-motion";
import { Tv, Zap, Shield, Globe, Smartphone, Headphones } from "lucide-react";

const CHANNELS_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/feature-channels-new-ZN4ThCLDgh9BX2ujqhVwRk.webp";
const QUALITY_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/feature-films-new-XXBPBcZsjLTHWX2r7YmAap.webp";

const features = [
  {
    icon: Tv,
    title: "10 000+ Chaînes",
    description: "Accédez à plus de 10 000 chaînes TV du monde entier : sport, cinéma, divertissement, actualités, et bien plus encore.",
    image: CHANNELS_IMG,
  },
  {
    icon: Zap,
    title: "25 000+ Films & 7 000+ Séries",
    description: "Un catalogue VOD gigantesque avec plus de 25 000 films et 7 000 séries. Nouveautés ajoutées chaque semaine en qualité 4K.",
    image: QUALITY_IMG,
  },
  {
    icon: Smartphone,
    title: "Multi-Appareils",
    description: "Compatible avec Smart TV, Android, iOS, Fire Stick, PC et Mac. Regardez où vous voulez, quand vous voulez.",
  },
  {
    icon: Globe,
    title: "Contenu International",
    description: "Chaînes françaises, arabes, anglaises, espagnoles, portugaises et bien d'autres. Le monde entier à portée de main.",
  },
  {
    icon: Shield,
    title: "Connexion Sécurisée",
    description: "Votre vie privée est protégée. Streaming sécurisé avec des serveurs haute performance partout dans le monde.",
  },
  {
    icon: Headphones,
    title: "Support 24/7",
    description: "Notre équipe est disponible à tout moment pour vous aider avec l'installation, la configuration ou toute question.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.12 },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" as const } },
};

export default function FeaturesSection() {
  return (
    <section id="features" className="relative py-16 sm:py-24 overflow-hidden">
      {/* Subtle background orb */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] rounded-full bg-[oklch(0.55_0.15_240/4%)] blur-[120px] pointer-events-none" />

      <div className="container relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10 sm:mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-semibold tracking-wider uppercase text-[oklch(0.72_0.15_210)] bg-[oklch(0.65_0.18_240/10%)] neon-border mb-4">
            Fonctionnalités
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-3 sm:mb-4">
            Pourquoi choisir <span className="text-gradient-blue neon-text">BLCTV Store</span> pour votre IPTV ?
          </h2>
          <p className="text-base sm:text-lg text-[oklch(0.65_0.03_250)] md:text-xl max-w-2xl mx-auto">
            Le meilleur abonnement IPTV premium avec plus de 10 000 chaînes, 25 000 films et 7 000 séries en 4K Ultra HD. Streaming fluide en Guadeloupe, Martinique, Guyane et dans toute la France.
          </p>
        </motion.div>

        {/* Featured cards (first 2 with images) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 mb-4 sm:mb-6">
          {features.slice(0, 2).map((feat) => (
            <motion.div
              key={feat.title}
              variants={cardVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="glass-card rounded-xl sm:rounded-2xl overflow-hidden group"
            >
              {feat.image && (
                <div className="h-36 sm:h-48 overflow-hidden">
                  <img
                    src={feat.image}
                    alt={feat.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
              )}
              <div className="p-4 sm:p-6 space-y-2 sm:space-y-3">
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg bg-[oklch(0.55_0.18_240/15%)] flex items-center justify-center" style={{ boxShadow: '0 0 12px oklch(0.65 0.18 240 / 25%)' }}>
                  <feat.icon size={18} className="text-[oklch(0.72_0.15_210)]" />
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-white">{feat.title}</h3>
                <p className="text-sm sm:text-base text-[oklch(0.65_0.03_250)] leading-relaxed">{feat.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Smaller feature cards */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5"
        >
          {features.slice(2).map((feat) => (
            <motion.div
              key={feat.title}
              variants={cardVariants}
              className="glass-card rounded-xl sm:rounded-2xl p-4 sm:p-6 space-y-2 sm:space-y-3 group"
            >
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg bg-[oklch(0.55_0.18_240/15%)] flex items-center justify-center group-hover:bg-[oklch(0.55_0.18_240/25%)] transition-all" style={{ boxShadow: '0 0 12px oklch(0.65 0.18 240 / 25%)' }}>
                <feat.icon size={18} className="text-[oklch(0.72_0.15_210)]" />
              </div>
              <h3 className="text-base sm:text-lg font-bold text-white">{feat.title}</h3>
              <p className="text-sm sm:text-base text-[oklch(0.65_0.03_250)] leading-relaxed">{feat.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
