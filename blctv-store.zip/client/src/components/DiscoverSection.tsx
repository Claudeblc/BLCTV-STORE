/*
 * BLCTV Store — Frosted Glass Tech Design
 * Discover: "Découvrez BLCTV Store" section with promo video
 * Responsive: smaller play button and text on mobile
 */
import { motion } from "framer-motion";
import { Play } from "lucide-react";
import { useRef, useState } from "react";

const PROMO_VIDEO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/blctv-promo_58c8653b.mp4";

export default function DiscoverSection() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (isPlaying) {
      video.pause();
      setIsPlaying(false);
    } else {
      video.play();
      setIsPlaying(true);
    }
  };

  return (
    <section id="discover" className="relative py-16 sm:py-24 overflow-hidden">
      {/* Background accents */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[oklch(0.10_0.04_240/20%)] to-transparent pointer-events-none" />
      <div className="absolute top-1/3 right-0 w-[500px] h-[500px] rounded-full bg-[oklch(0.55_0.18_240/6%)] blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-[300px] h-[300px] rounded-full bg-[oklch(0.65_0.15_210/5%)] blur-[100px] pointer-events-none" />

      <div className="container relative z-10">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10 sm:mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-semibold tracking-wider uppercase text-[oklch(0.72_0.15_210)] bg-[oklch(0.65_0.18_240/10%)] neon-border mb-4">
            Présentation
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-3 sm:mb-4">
            Découvrez <span className="text-gradient-blue neon-text">BLCTV Store</span>
          </h2>
          <p className="text-base sm:text-lg text-[oklch(0.65_0.03_250)] md:text-xl max-w-2xl mx-auto leading-relaxed">
            Plongez dans l'univers BLCTV et découvrez pourquoi des milliers de clients nous font confiance pour leur divertissement quotidien.
          </p>
        </motion.div>

        {/* Video player */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="max-w-4xl mx-auto"
        >
          <div
            className="relative rounded-xl sm:rounded-2xl overflow-hidden glass-card group cursor-pointer"
            style={{ boxShadow: '0 0 40px oklch(0.55 0.18 240 / 20%), 0 0 80px oklch(0.55 0.18 240 / 10%)' }}
            onClick={handlePlay}
          >
            <video
              ref={videoRef}
              src={PROMO_VIDEO}
              playsInline
              className="w-full aspect-video object-cover"
              onEnded={() => setIsPlaying(false)}
            />

            {/* Play overlay */}
            {!isPlaying && (
              <div className="absolute inset-0 flex items-center justify-center bg-[oklch(0.06_0.02_250/40%)] transition-all duration-300 group-hover:bg-[oklch(0.06_0.02_250/20%)]">
                <div className="w-14 h-14 sm:w-20 sm:h-20 rounded-full bg-[oklch(0.55_0.18_240)] flex items-center justify-center glow-blue group-hover:scale-110 transition-transform duration-300">
                  <Play size={28} className="text-white ml-0.5 sm:ml-1" />
                </div>
              </div>
            )}

            {/* Neon border glow */}
            <div className="absolute inset-0 rounded-xl sm:rounded-2xl pointer-events-none" style={{ boxShadow: 'inset 0 0 1px oklch(0.65 0.18 240 / 30%)' }} />
          </div>

          <p className="text-center text-[oklch(0.55_0.03_250)] text-sm sm:text-base mt-3 sm:mt-4">
            Cliquez pour lancer la vidéo de présentation
          </p>
        </motion.div>
      </div>
    </section>
  );
}
