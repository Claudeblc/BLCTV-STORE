/*
 * BLCTV Store — Frosted Glass Tech Design
 * About: "Qui sommes-nous" + message Antillais
 * Responsive: stacked on mobile, side-by-side on desktop
 */
import { motion } from "framer-motion";
import { Award, Users, Globe, Clock, Heart, Palmtree } from "lucide-react";

const LOGO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/blctv_store_logo_nobg_c7deb4fe.png";

const milestones = [
  { icon: Clock, value: "10+", label: "Années d'expérience", desc: "Une décennie de passion et d'expertise dans l'IPTV" },
  { icon: Users, value: "5 000+", label: "Clients satisfaits", desc: "Une communauté fidèle qui grandit chaque jour" },
  { icon: Globe, value: "50+", label: "Pays desservis", desc: "Un service accessible partout dans le monde" },
  { icon: Award, value: "99.9%", label: "Disponibilité", desc: "Un service fiable et stable 24h/24, 7j/7" },
];

export default function AboutSection() {
  return (
    <section id="about" className="relative py-16 sm:py-24 overflow-hidden">
      {/* Background accents */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[oklch(0.10_0.04_240/15%)] to-transparent pointer-events-none" />
      <div className="absolute top-1/4 left-0 w-[400px] h-[400px] rounded-full bg-[oklch(0.55_0.18_240/5%)] blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-0 w-[350px] h-[350px] rounded-full bg-[oklch(0.65_0.15_210/5%)] blur-[100px] pointer-events-none" />

      <div className="container relative z-10">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10 sm:mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-semibold tracking-wider uppercase text-[oklch(0.72_0.15_210)] bg-[oklch(0.65_0.18_240/10%)] neon-border mb-4">
            Notre histoire
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-3 sm:mb-4">
            Qui sommes-<span className="text-gradient-blue neon-text">nous</span> ?
          </h2>
          <p className="text-base sm:text-lg text-[oklch(0.65_0.03_250)] md:text-xl max-w-3xl mx-auto leading-relaxed">
            Depuis plus de <strong className="text-white">10 ans</strong>, BLCTV Store est le spécialiste de l'abonnement IPTV premium pour les Antilles, la Guadeloupe, la Martinique, la Guyane et toute la France. Notre mission : vous offrir le meilleur service IPTV avec une qualité 4K irréprochable et un support client réactif.
          </p>
        </motion.div>

        {/* About content */}
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center mb-12 sm:mb-20">
          {/* Left: Logo + text */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-4 sm:space-y-6"
          >
            <img src={LOGO} alt="BLCTV Store" className="h-20 sm:h-28 w-auto object-contain mx-auto lg:mx-0" />
            <div className="space-y-3 sm:space-y-4">
              <p className="text-base sm:text-lg text-[oklch(0.70_0.03_250)] md:text-xl leading-relaxed">
                BLCTV Store est né de la passion de fournir un accès simple et abordable à des milliers de chaînes TV, films et séries du monde entier. Forts de <strong className="text-white">10 années d'expérience</strong> dans l'IPTV, nous avons perfectionné notre service pour offrir la meilleure expérience de streaming IPTV en Guadeloupe, Martinique et dans tous les DOM-TOM.
              </p>
              <p className="text-base sm:text-lg text-[oklch(0.70_0.03_250)] md:text-xl leading-relaxed">
                Notre équipe dédiée travaille sans relâche pour garantir la meilleure qualité d'image en 4K Ultra HD, un catalogue de plus de 10 000 chaînes TV toujours à jour, et un support technique réactif 24/7. Le meilleur abonnement IPTV pas cher et fiable pour les Antilles et la France.
              </p>
            </div>
          </motion.div>

          {/* Right: Milestones grid */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="grid grid-cols-2 gap-3 sm:gap-4"
          >
            {milestones.map((item, i) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.3 + i * 0.1 }}
                className="glass-card rounded-xl sm:rounded-2xl p-4 sm:p-6 text-center space-y-2 sm:space-y-3 group"
              >
                <div
                  className="w-10 h-10 sm:w-14 sm:h-14 mx-auto rounded-lg sm:rounded-xl bg-[oklch(0.55_0.18_240/12%)] flex items-center justify-center group-hover:bg-[oklch(0.55_0.18_240/20%)] transition-all"
                  style={{ boxShadow: '0 0 12px oklch(0.65 0.18 240 / 25%)' }}
                >
                  <item.icon size={22} className="text-[oklch(0.72_0.15_210)]" />
                </div>
                <div className="text-2xl sm:text-3xl font-bold text-gradient-blue neon-text">{item.value}</div>
                <h4 className="font-bold text-white text-sm sm:text-base">{item.label}</h4>
                <p className="text-xs sm:text-sm text-[oklch(0.55_0.03_250)]">{item.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Antillais section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="relative rounded-xl sm:rounded-2xl overflow-hidden"
        >
          {/* Gradient background with tropical feel */}
          <div className="absolute inset-0 bg-gradient-to-r from-[oklch(0.20_0.08_240)] via-[oklch(0.18_0.06_200)] to-[oklch(0.20_0.08_240)]" />
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-[oklch(0.70_0.20_160)] blur-[80px]" />
            <div className="absolute bottom-0 left-0 w-48 h-48 rounded-full bg-[oklch(0.65_0.18_240)] blur-[60px]" />
          </div>

          <div className="relative z-10 p-5 sm:p-8 md:p-12 lg:p-16">
            <div className="flex flex-col lg:flex-row items-center gap-6 sm:gap-8 lg:gap-12">
              {/* Left: Icon + Title */}
              <div className="flex-shrink-0 text-center lg:text-left">
                <div className="flex items-center gap-3 sm:gap-4 mb-3 sm:mb-4 justify-center lg:justify-start">
                  <div
                    className="w-12 h-12 sm:w-16 sm:h-16 rounded-xl sm:rounded-2xl bg-[oklch(0.55_0.18_240/15%)] flex items-center justify-center"
                    style={{ boxShadow: '0 0 20px oklch(0.65 0.18 240 / 30%)' }}
                  >
                    <Palmtree size={24} className="text-[oklch(0.72_0.15_180)]" />
                  </div>
                  <div
                    className="w-12 h-12 sm:w-16 sm:h-16 rounded-xl sm:rounded-2xl bg-[oklch(0.55_0.18_240/15%)] flex items-center justify-center"
                    style={{ boxShadow: '0 0 20px oklch(0.65 0.18 240 / 30%)' }}
                  >
                    <Heart size={24} className="text-[oklch(0.72_0.15_210)]" />
                  </div>
                </div>
                <h3 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-2">
                  Nou kontan (v)wè zot <span className="text-gradient-blue">!</span>
                </h3>
                <p className="text-[oklch(0.72_0.15_210)] font-semibold text-lg sm:text-xl">
                  Bienvenu à notre communauté antillaise
                </p>
              </div>

              {/* Right: Content */}
              <div className="space-y-3 sm:space-y-4 flex-1">
                <p className="text-base sm:text-lg text-[oklch(0.75_0.03_250)] md:text-xl leading-relaxed">
                  Chez BLCTV, nous sommes fiers de proposer <strong className="text-white">toutes les chaînes DOM-TOM</strong> pour que vous restiez connectés à votre culture, vos actualités et vos programmes préférés, où que vous soyez dans le monde.
                </p>
                <p className="text-base sm:text-lg text-[oklch(0.75_0.03_250)] md:text-xl leading-relaxed">
                  Et bonne nouvelle : <strong className="text-white">les chaînes françaises sont diffusées au bon fuseau horaire</strong> pour les Antilles ! Plus besoin de calculer le décalage — regardez vos émissions en direct comme si vous étiez sur place.
                </p>
                <div className="flex flex-wrap gap-2 sm:gap-3 pt-1 sm:pt-2">
                  {["Guadeloupe", "Martinique", "Guyane", "Réunion", "Mayotte", "Saint-Martin"].map((island) => (
                    <span
                      key={island}
                      className="px-3 sm:px-4 py-1.5 sm:py-2 rounded-full text-sm sm:text-base font-medium text-white bg-[oklch(0.55_0.18_240/20%)] border border-[oklch(0.55_0.18_240/30%)]"
                      style={{ boxShadow: '0 0 8px oklch(0.55 0.18 240 / 15%)' }}
                    >
                      {island}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Neon border */}
          <div className="absolute inset-0 rounded-xl sm:rounded-2xl pointer-events-none neon-border" />
        </motion.div>
      </div>
    </section>
  );
}
