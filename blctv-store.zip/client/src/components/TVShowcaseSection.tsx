/*
 * BLCTV Store — Frosted Glass Tech Design
 * TVShowcase: Grand écran TV avec visuel de l'app BLC TV + section "Connexion rapide" avec images
 * Inspiré de kartina.tv — même DA (frosted glass, neon blue)
 */
import { motion } from "framer-motion";
import { Tv, Smartphone, Monitor, Tablet } from "lucide-react";

const TV_SHOWCASE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/tv-showcase-v3-NFLF7TmpPPYNXDC9iAbyS4.webp";
const STEP1_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/step1-download-v2-Lm6kY7VRWEukfjNF94Fy3N.webp";
const STEP2_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/step2-login-v2-KeUecsxRQT7AWdKqLCJu8r.webp";
const STEP3_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/step3-enjoy-v2-RTwbEGNrwPymhH2KKATgZG.webp";

const steps = [
  {
    number: "01",
    title: "Téléchargez l'application",
    desc: "Installez BLC TV Player depuis le Play Store, l'App Store ou directement sur votre Smart TV / Fire Stick.",
    image: STEP1_IMG,
  },
  {
    number: "02",
    title: "Entrez vos identifiants",
    desc: "Connectez-vous avec le nom d'utilisateur et le mot de passe fournis après votre abonnement.",
    image: STEP2_IMG,
  },
  {
    number: "03",
    title: "Profitez du streaming",
    desc: "C'est prêt ! Accédez à plus de 10 000 chaînes, 25 000 films et 7 000 séries en qualité 4K.",
    image: STEP3_IMG,
  },
];

const devices = [
  { icon: Tv, label: "Smart TV" },
  { icon: Monitor, label: "PC / Mac" },
  { icon: Tablet, label: "Tablette" },
  { icon: Smartphone, label: "Smartphone" },
];

export default function TVShowcaseSection() {
  return (
    <section id="tv-showcase" className="relative py-16 sm:py-24 overflow-hidden">
      {/* Background accents */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[oklch(0.10_0.04_240/15%)] to-transparent pointer-events-none" />
      <div className="absolute top-1/3 left-0 w-[500px] h-[500px] rounded-full bg-[oklch(0.55_0.18_240/6%)] blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-0 w-[400px] h-[400px] rounded-full bg-[oklch(0.65_0.15_210/5%)] blur-[100px] pointer-events-none" />

      <div className="container relative z-10">
        {/* TV Grand écran */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10 sm:mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-semibold tracking-wider uppercase text-[oklch(0.72_0.15_210)] bg-[oklch(0.65_0.18_240/10%)] neon-border mb-4">
            Expérience grand écran
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-3 sm:mb-4">
            Films, Séries et TV en Direct sur <span className="text-gradient-blue neon-text">Votre Smart TV</span>
          </h2>
          <p className="text-base sm:text-lg text-[oklch(0.65_0.03_250)] md:text-xl max-w-3xl mx-auto leading-relaxed">
            L'application BLC TV Player est disponible sur Samsung, LG, Android TV, Amazon Fire TV, Apple TV et tous vos appareils connectés.
          </p>
        </motion.div>

        {/* TV Image — visuel réel de l'app */}
        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.95 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="max-w-5xl mx-auto mb-16 sm:mb-24"
        >
          <div
            className="relative rounded-xl sm:rounded-2xl overflow-hidden"
            style={{ boxShadow: '0 0 60px oklch(0.55 0.18 240 / 20%), 0 0 120px oklch(0.55 0.18 240 / 8%)' }}
          >
            <img
              src={TV_SHOWCASE}
              alt="Smart TV affichant l'interface BLC TV Player avec films, séries et chaînes TV en direct — IPTV Premium"
              className="w-full object-cover"
              loading="lazy"
            />
            {/* Neon border overlay */}
            <div className="absolute inset-0 rounded-xl sm:rounded-2xl pointer-events-none neon-border" />
          </div>

          {/* Devices row */}
          <div className="flex justify-center gap-6 sm:gap-10 mt-6 sm:mt-8">
            {devices.map((device, i) => (
              <motion.div
                key={device.label}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.4 + i * 0.1 }}
                className="flex flex-col items-center gap-2 text-center"
              >
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-[oklch(0.55_0.18_240/12%)] flex items-center justify-center" style={{ boxShadow: '0 0 12px oklch(0.65 0.18 240 / 25%)' }}>
                  <device.icon size={22} className="text-[oklch(0.72_0.15_210)]" />
                </div>
                <span className="text-xs sm:text-sm text-[oklch(0.65_0.03_250)] font-medium">{device.label}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Connexion rapide */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10 sm:mb-14"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-semibold tracking-wider uppercase text-[oklch(0.72_0.15_210)] bg-[oklch(0.65_0.18_240/10%)] neon-border mb-4">
            Simple et rapide
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-3 sm:mb-4">
            Connexion <span className="text-gradient-blue neon-text">rapide</span>
          </h2>
          <p className="text-base sm:text-lg text-[oklch(0.65_0.03_250)] md:text-xl max-w-2xl mx-auto leading-relaxed">
            En 3 étapes simples, accédez à tout le catalogue BLCTV Store sur n'importe quel appareil.
          </p>
        </motion.div>

        {/* Steps with images */}
        <div className="grid md:grid-cols-3 gap-6 sm:gap-8 max-w-5xl mx-auto">
          {steps.map((step, i) => (
            <motion.div
              key={step.number}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 + i * 0.15 }}
              className="relative glass-card rounded-xl sm:rounded-2xl overflow-hidden text-center group"
            >
              {/* Step image */}
              <div className="relative w-full h-48 sm:h-56 overflow-hidden">
                <img
                  src={step.image}
                  alt={step.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
                {/* Gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.08_0.02_250)] via-[oklch(0.08_0.02_250/50%)] to-transparent" />
                {/* Step number badge */}
                <div
                  className="absolute top-4 left-4 w-10 h-10 rounded-full bg-[oklch(0.55_0.18_240)] flex items-center justify-center text-white text-sm font-bold"
                  style={{ boxShadow: '0 0 16px oklch(0.55 0.18 240 / 50%)' }}
                >
                  {step.number}
                </div>
              </div>

              {/* Text content */}
              <div className="p-5 sm:p-6">
                <h3 className="text-lg sm:text-xl font-bold text-white mb-2 sm:mb-3">{step.title}</h3>
                <p className="text-sm sm:text-base text-[oklch(0.60_0.03_250)] leading-relaxed">{step.desc}</p>
              </div>

              {/* Connector line (not on last) */}
              {i < steps.length - 1 && (
                <div className="hidden md:block absolute top-1/2 -right-4 w-8 h-px bg-gradient-to-r from-[oklch(0.55_0.18_240/60%)] to-[oklch(0.55_0.18_240/10%)]" />
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
