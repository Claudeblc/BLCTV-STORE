/*
 * BLCTV Store — Frosted Glass Tech Design
 * Navbar: sticky glassmorphism navigation with animated logo
 * Logo starts large at left in hero area and smoothly shrinks into the navbar on scroll
 * Responsive: smaller logo on mobile, hamburger menu
 * Navigation uses native anchor links + CSS scroll-behavior for maximum mobile compatibility
 */
import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/blctv_store_logo_nobg_c7deb4fe.png";

const navLinks = [
  { label: "Accueil", href: "#hero" },
  { label: "Découvrez-nous", href: "#discover" },
  { label: "Qui sommes-nous", href: "#about" },
  { label: "Fonctionnalités", href: "#features" },
  { label: "Chaînes TV", href: "#channels" },
  { label: "Abonnements", href: "#pricing" },
  { label: "Application", href: "#download" },
  { label: "Tutoriels", href: "#tutorials" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [scrollProgress, setScrollProgress] = useState(0);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [heroLogoRect, setHeroLogoRect] = useState<DOMRect | null>(null);
  const [navLogoRect, setNavLogoRect] = useState<DOMRect | null>(null);
  const [isMobile, setIsMobile] = useState(false);
  const navLogoRef = useRef<HTMLImageElement>(null);

  // Detect mobile
  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 1024);
    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  // Measure positions of both logo targets
  const measurePositions = useCallback(() => {
    const heroAnchor = document.getElementById("hero-logo-anchor");
    if (heroAnchor) {
      setHeroLogoRect(heroAnchor.getBoundingClientRect());
    }
    if (navLogoRef.current) {
      setNavLogoRect(navLogoRef.current.getBoundingClientRect());
    }
  }, []);

  useEffect(() => {
    const timer = setTimeout(measurePositions, 100);
    const onScroll = () => {
      const progress = Math.min(window.scrollY / 250, 1);
      setScrollProgress(progress);
      measurePositions();
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", measurePositions);
    return () => {
      clearTimeout(timer);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", measurePositions);
    };
  }, [measurePositions]);

  // Handle mobile link click: close menu, then scroll after a delay
  const handleMobileClick = (href: string) => {
    setMobileOpen(false);
    // Wait for menu to close, then scroll
    setTimeout(() => {
      const id = href.replace("#", "");
      const el = document.getElementById(id);
      if (el) {
        const navbarHeight = 70;
        const top = el.getBoundingClientRect().top + window.scrollY - navbarHeight;
        window.scrollTo({ top, behavior: "smooth" });
      }
    }, 300);
  };

  // Handle desktop link click
  const handleDesktopClick = (e: React.MouseEvent, href: string) => {
    e.preventDefault();
    const id = href.replace("#", "");
    const el = document.getElementById(id);
    if (el) {
      const navbarHeight = 70;
      const top = el.getBoundingClientRect().top + window.scrollY - navbarHeight;
      window.scrollTo({ top, behavior: "smooth" });
    }
  };

  const isScrolled = scrollProgress > 0.1;
  const p = scrollProgress;

  // Interpolate logo position
  const heroTop = heroLogoRect ? heroLogoRect.top + window.scrollY : 160;
  const heroLeft = heroLogoRect ? heroLogoRect.left : 16;
  const heroHeight = isMobile ? 128 : 224;
  const navTop = navLogoRect ? navLogoRect.top + window.scrollY : 8;
  const navLeft = navLogoRect ? navLogoRect.left : 16;
  const navHeight = isMobile ? 36 : 48;
  const ease = p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2;
  const currentTop = heroTop + (navTop - heroTop) * ease - window.scrollY;
  const currentLeft = heroLeft + (navLeft - heroLeft) * ease;
  const currentHeight = heroHeight + (navHeight - heroHeight) * ease;

  return (
    <>
      {/* Animated floating logo */}
      <div
        className="fixed pointer-events-none"
        style={{
          zIndex: 60,
          top: `${currentTop}px`,
          left: `${currentLeft}px`,
          height: `${currentHeight}px`,
          willChange: "top, left, height",
        }}
      >
        <img
          src={LOGO_URL}
          alt="BLCTV Store"
          className="h-full w-auto object-contain"
          style={{
            filter: p > 0.8
              ? `drop-shadow(0 0 15px oklch(0.55 0.18 240 / ${(1 - p) * 2}))`
              : `drop-shadow(0 0 40px oklch(0.55 0.18 240 / 50%)) drop-shadow(0 0 80px oklch(0.55 0.18 240 / 25%))`,
            animation: p < 0.5 ? 'logoGlow 3s ease-in-out infinite' : 'none',
          }}
        />
      </div>

      {/* Main nav bar */}
      <nav
        className="fixed top-0 left-0 right-0 transition-all duration-300"
        style={{ zIndex: 50 }}
      >
        <div
          className={`transition-all duration-300 ${
            isScrolled
              ? "py-1.5 sm:py-2 bg-[oklch(0.10_0.02_250/80%)] backdrop-blur-xl border-b border-[oklch(0.50_0.10_240/15%)] shadow-[0_2px_20px_oklch(0.65_0.18_240/10%)]"
              : "py-2 sm:py-4 bg-transparent"
          }`}
        >
          <div className="container flex items-center justify-between">
            {/* Invisible navbar logo — measurement target */}
            <a
              href="#hero"
              onClick={(e) => handleDesktopClick(e, "#hero")}
              className="flex items-center gap-2 shrink-0"
              style={{ pointerEvents: p > 0.5 ? "auto" : "none" }}
            >
              <img
                ref={navLogoRef}
                src={LOGO_URL}
                alt="BLCTV Store"
                className="h-9 lg:h-12 w-auto object-contain"
                style={{ opacity: 0 }}
              />
            </a>

            {/* Desktop links */}
            <div className="hidden lg:flex items-center gap-2 xl:gap-4">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => handleDesktopClick(e, link.href)}
                  className="text-xs xl:text-sm font-medium text-[oklch(0.75_0.03_250)] hover:text-white transition-colors duration-300 relative group whitespace-nowrap cursor-pointer"
                >
                  {link.label}
                  <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[oklch(0.65_0.18_240)] group-hover:w-full transition-all duration-300" />
                </a>
              ))}
              <a
                href="#pricing"
                onClick={(e) => handleDesktopClick(e, "#pricing")}
                className="ml-2 px-4 py-2 rounded-lg text-sm font-semibold text-white bg-[oklch(0.55_0.18_240)] hover:bg-[oklch(0.60_0.20_240)] transition-all duration-300 glow-blue-hover whitespace-nowrap cursor-pointer"
              >
                S'abonner
              </a>
            </div>

            {/* Mobile hamburger toggle */}
            <button
              className="lg:hidden text-white p-3 -mr-2 touch-manipulation"
              onClick={() => setMobileOpen((prev) => !prev)}
              aria-label="Menu"
              type="button"
            >
              {mobileOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>

        {/* Mobile menu dropdown */}
        <AnimatePresence>
          {mobileOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.25 }}
              className="lg:hidden overflow-hidden"
            >
              <div className="mx-3 sm:mx-4 mt-2 rounded-xl bg-[oklch(0.12_0.025_250/98%)] backdrop-blur-xl border border-[oklch(0.50_0.10_240/20%)] p-3 sm:p-4 space-y-1 shadow-2xl">
                {navLinks.map((link) => (
                  <button
                    key={link.href}
                    type="button"
                    onClick={() => handleMobileClick(link.href)}
                    className="block w-full text-left text-lg font-medium text-[oklch(0.80_0.03_250)] hover:text-white py-3.5 px-4 rounded-lg hover:bg-[oklch(0.20_0.03_250/50%)] transition-all cursor-pointer active:bg-[oklch(0.25_0.05_240/60%)]"
                  >
                    {link.label}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => handleMobileClick("#pricing")}
                  className="block w-full mt-3 px-5 py-3.5 rounded-lg text-lg font-semibold text-white text-center bg-[oklch(0.55_0.18_240)] hover:bg-[oklch(0.60_0.20_240)] transition-all cursor-pointer active:bg-[oklch(0.50_0.16_240)]"
                >
                  S'abonner
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Overlay to close mobile menu when tapping outside */}
      {mobileOpen && (
        <div
          className="fixed inset-0 lg:hidden"
          style={{ zIndex: 45 }}
          onClick={() => setMobileOpen(false)}
          aria-hidden="true"
        />
      )}
    </>
  );
}
