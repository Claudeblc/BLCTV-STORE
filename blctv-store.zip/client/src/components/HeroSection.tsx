/*
 * BLCTV Store — Frosted Glass Tech Design
 * Hero: immersive full-screen section with video background, logo, tagline, and CTA
 * Responsive: stacked layout on mobile, side-by-side on desktop
 */
import { motion } from "framer-motion";
import { Play, ChevronDown } from "lucide-react";

const HERO_VIDEO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/aces_e73c76bc.mp4";
const HERO_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/hero_bg-fQzyZ8uoT7wpLVceAt6PdX.webp";
const DEVICES_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/hero_devices_greenscreen-JCrFwVKtAgfYXBNdACokeA.png";

export default function HeroSection() {
  const scrollTo = (id: string) => {
    document.querySelector(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="hero"
      className="relative min-h-[85vh] lg:min-h-screen flex items-center overflow-hidden"
    >
      {/* Video Background */}
      <div className="absolute inset-0 z-0">
        <video
          autoPlay
          muted
          loop
          playsInline
          poster={HERO_BG}
          className="w-full h-full object-cover"
        >
          <source src={HERO_VIDEO} type="video/mp4" />
        </video>
        {/* Dark overlay gradient to keep text readable */}
        <div className="absolute inset-0 bg-gradient-to-b from-[oklch(0.06_0.02_250/80%)] via-[oklch(0.08_0.02_250/70%)] to-[oklch(0.12_0.02_250/95%)]" />
        <div className="absolute inset-0 bg-gradient-to-r from-[oklch(0.06_0.02_250/60%)] via-transparent to-transparent" />
      </div>

      {/* Animated orbs — hidden on very small screens for performance */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none hidden sm:block">
        <div className="absolute top-1/4 left-1/6 w-72 h-72 rounded-full bg-[oklch(0.55_0.18_240/12%)] blur-[80px] animate-pulse" />
        <div className="absolute bottom-1/3 right-1/5 w-[28rem] h-[28rem] rounded-full bg-[oklch(0.65_0.15_210/10%)] blur-[100px] animate-pulse" style={{ animationDelay: "1s" }} />
        <div className="absolute top-1/2 left-1/2 w-56 h-56 rounded-full bg-[oklch(0.72_0.12_220/8%)] blur-[60px] animate-pulse" style={{ animationDelay: "2s" }} />
      </div>

      <div className="container relative z-10 pt-16 sm:pt-20 pb-12 sm:pb-16">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Left content */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="space-y-6 sm:space-y-8"
          >
            {/* Logo placeholder — invisible, reserves space for the animated logo overlay */}
            <div id="hero-logo-anchor" className="h-32 sm:h-44 md:h-56" />

            <div className="space-y-3 sm:space-y-4">
              <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight">
                <span className="text-white">Le meilleur de la </span>
                <span className="text-gradient-blue neon-text-accent">télévision</span>
                <br />
                <span className="text-white">en illimité</span>
              </h1>
              <p className="text-lg sm:text-xl md:text-2xl text-[oklch(0.70_0.03_250)] max-w-lg leading-relaxed">
                Abonnement IPTV premium avec plus de 10 000 chaînes TV, 25 000 films et 7 000 séries en qualité 4K Ultra HD. Disponible en Guadeloupe, Martinique, Guyane et dans toute la France. Streaming fluide 24/7.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
              <button
                onClick={() => scrollTo("#pricing")}
                className="group flex items-center justify-center gap-2 px-6 sm:px-8 py-3.5 sm:py-4 rounded-xl text-base sm:text-lg font-semibold text-white bg-[oklch(0.55_0.18_240)] hover:bg-[oklch(0.60_0.20_240)] transition-all duration-300 glow-blue hover:shadow-[0_0_30px_oklch(0.65_0.18_240/50%),0_0_80px_oklch(0.65_0.18_240/25%)]"
              >
                <Play size={18} className="group-hover:scale-110 transition-transform" />
                Voir les offres
              </button>
              <button
                onClick={() => scrollTo("#download")}
                className="flex items-center justify-center gap-2 px-6 sm:px-8 py-3.5 sm:py-4 rounded-xl text-base sm:text-lg font-semibold text-[oklch(0.80_0.10_240)] neon-border transition-all duration-300"
              >
                Télécharger l'app
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-4 sm:gap-6 md:gap-8 pt-2 sm:pt-4">
              {[
                { value: "10 000+", label: "Chaînes" },
                { value: "25 000+", label: "Films" },
                { value: "7 000+", label: "Séries" },
                { value: "4K", label: "Ultra HD" },
                { value: "24/7", label: "Support" },
              ].map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.6 + i * 0.15 }}
                  className={`text-center sm:text-left ${i >= 3 ? "hidden sm:block" : ""}`}
                >
                  <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-gradient-blue neon-text">{stat.value}</div>
                  <div className="text-sm sm:text-base text-[oklch(0.60_0.03_250)]">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right: devices mockup — hidden on mobile */}
          <motion.div
            initial={{ opacity: 0, x: 40, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.9, delay: 0.3, ease: "easeOut" }}
            className="hidden lg:block relative"
          >
            <img
              src={DEVICES_IMG}
              alt="BLCTV Player sur TV, laptop, tablette et smartphone"
              className="w-full max-w-2xl mx-auto drop-shadow-[0_0_30px_oklch(0.55_0.18_240/30%)]"
            />
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.button
        onClick={() => scrollTo("#features")}
        className="absolute bottom-6 sm:bottom-8 left-1/2 -translate-x-1/2 z-10 text-[oklch(0.60_0.10_240)] hover:text-white transition-colors"
        animate={{ y: [0, 8, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
      >
        <ChevronDown size={28} />
      </motion.button>
    </section>
  );
}
