/*
 * BLCTV Store — Frosted Glass Tech Design
 * Download: APK download section with direct links for Mobile & Android TV
 * Includes Downloader app code for Fire TV / Android TV
 * Includes Web Player access with username verification
 * Responsive: stacked layout on mobile, code digits scale down
 */
import { motion } from "framer-motion";
import { Download, Smartphone, Monitor, Tablet, Tv, Copy, Check, Globe, ArrowRight, Loader2, AlertCircle, CheckCircle2 } from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";

const APK_MOBILE_URL = "/api/download/mobile";
const APK_TV_URL = "/api/download/tv";

// Code Downloader à 6 chiffres pour l'app TV
const DOWNLOADER_CODE_TV = "853291";

const WEB_PLAYER_URL = "https://www.blctvplayer.vip";

const devices = [
  { icon: Smartphone, label: "Android", desc: "Téléphone & Tablette" },
  { icon: Tv, label: "Smart TV", desc: "Android TV / Fire TV" },
  { icon: Tablet, label: "Fire Stick", desc: "Amazon Fire Stick" },
  { icon: Monitor, label: "PC / Mac", desc: "Via navigateur web" },
];

export default function DownloadSection() {
  const [copied, setCopied] = useState(false);
  const [webUsername, setWebUsername] = useState("");
  const [webPassword, setWebPassword] = useState("");
  const [webStatus, setWebStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [webMessage, setWebMessage] = useState("");

  const verifyClient = trpc.verifyClient.useMutation({
    onSuccess: (data) => {
      if (data.valid) {
        setWebStatus("success");
        setWebMessage("Accès autorisé ! Redirection vers BLC TV Player...");
        // Redirect after a short delay
        setTimeout(() => {
          window.open(WEB_PLAYER_URL, "_blank");
        }, 1500);
      } else {
        setWebStatus("error");
        setWebMessage(data.message);
      }
    },
    onError: () => {
      setWebStatus("error");
      setWebMessage("Erreur de connexion. Veuillez réessayer.");
    },
  });

  const handleWebAccess = (e: React.FormEvent) => {
    e.preventDefault();
    if (!webUsername.trim() || !webPassword.trim()) return;
    setWebStatus("loading");
    setWebMessage("");
    verifyClient.mutate({ username: webUsername.trim(), password: webPassword.trim() });
  };

  const copyCode = () => {
    navigator.clipboard.writeText(DOWNLOADER_CODE_TV);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="download" className="relative py-16 sm:py-24 overflow-hidden">
      {/* Background gradient accent */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[oklch(0.10_0.03_240/30%)] to-transparent pointer-events-none" />
      <div className="absolute top-1/2 left-0 w-[400px] h-[400px] rounded-full bg-[oklch(0.55_0.18_240/5%)] blur-[120px] pointer-events-none" />

      <div className="container relative z-10">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Left: info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-6 sm:space-y-8"
          >
            <div>
              <span className="inline-block px-4 py-1.5 rounded-full text-sm font-semibold tracking-wider uppercase text-[oklch(0.72_0.15_210)] bg-[oklch(0.65_0.18_240/10%)] neon-border mb-4">
                Application
              </span>
              <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-3 sm:mb-4">
                Téléchargez <span className="text-gradient-blue neon-text">l'application IPTV</span>
              </h2>
              <p className="text-[oklch(0.65_0.03_250)] text-lg sm:text-xl max-w-lg leading-relaxed">
                Installez l'application BLCTV Player sur Android TV, Fire TV Stick, smartphone ou tablette. Compatible avec tous les appareils, même aux Antilles et en DOM-TOM. Simple, rapide et gratuit.
              </p>
            </div>

            {/* Download buttons */}
            <div className="flex flex-col gap-3 sm:gap-4">
              <a
                href={APK_MOBILE_URL}
                download
                className="group flex items-center gap-3 px-5 sm:px-8 py-3 sm:py-4 rounded-2xl font-bold text-white bg-[oklch(0.55_0.18_240)] hover:bg-[oklch(0.60_0.20_240)] transition-all duration-300 glow-blue"
              >
                <Smartphone size={20} className="group-hover:translate-y-0.5 transition-transform shrink-0" />
                <div className="text-left">
                  <div className="text-[10px] sm:text-xs font-normal opacity-80">Télécharger pour</div>
                  <div className="text-lg sm:text-xl">Mobile / Tablette</div>
                </div>
              </a>

              <a
                href={APK_TV_URL}
                download
                className="group flex items-center gap-3 px-5 sm:px-8 py-3 sm:py-4 rounded-2xl font-bold text-white bg-[oklch(0.20_0.05_240)] border border-[oklch(0.55_0.18_240/40%)] hover:bg-[oklch(0.25_0.08_240)] hover:border-[oklch(0.55_0.18_240/60%)] transition-all duration-300"
                style={{ boxShadow: '0 0 15px oklch(0.55 0.18 240 / 15%)' }}
              >
                <Tv size={20} className="text-[oklch(0.72_0.15_210)] group-hover:translate-y-0.5 transition-transform shrink-0" />
                <div className="text-left">
                  <div className="text-[10px] sm:text-xs font-normal opacity-80">Télécharger pour</div>
                  <div className="text-lg sm:text-xl">Android TV / Fire TV</div>
                </div>
              </a>
            </div>

            {/* Web Player Access Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="glass-card rounded-2xl p-4 sm:p-6 space-y-4"
              style={{ boxShadow: '0 0 25px oklch(0.45 0.20 160 / 12%)' }}
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[oklch(0.45_0.18_160/15%)] flex items-center justify-center shrink-0" style={{ boxShadow: '0 0 12px oklch(0.45 0.18 160 / 25%)' }}>
                  <Globe size={18} className="text-[oklch(0.72_0.15_160)]" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-lg sm:text-xl">Version Web</h3>
                  <p className="text-xs sm:text-sm text-[oklch(0.55_0.03_250)]">Regardez directement depuis votre navigateur</p>
                </div>
              </div>

              <p className="text-sm sm:text-base text-[oklch(0.70_0.03_250)] leading-relaxed">
                Vous préférez regarder sur votre <strong className="text-white">ordinateur</strong> ou <strong className="text-white">navigateur web</strong> ? 
                Accédez à <strong className="text-[oklch(0.72_0.15_160)]">BLC TV Player version web</strong> directement, 
                sans rien installer. Entrez vos identifiants IPTV (nom d'utilisateur et mot de passe) pour accéder à votre contenu.
              </p>

              <form onSubmit={handleWebAccess} className="space-y-3">
                <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
                  <input
                    type="text"
                    value={webUsername}
                    onChange={(e) => {
                      setWebUsername(e.target.value);
                      if (webStatus !== "idle") {
                        setWebStatus("idle");
                        setWebMessage("");
                      }
                    }}
                    placeholder="Nom d'utilisateur"
                    className="flex-1 px-4 py-2.5 sm:py-3 rounded-xl bg-[oklch(0.08_0.02_250)] border border-[oklch(0.55_0.18_240/30%)] text-white placeholder:text-[oklch(0.40_0.03_250)] text-sm sm:text-base focus:outline-none focus:border-[oklch(0.55_0.18_160/60%)] focus:ring-1 focus:ring-[oklch(0.55_0.18_160/30%)] transition-all"
                  />
                  <input
                    type="password"
                    value={webPassword}
                    onChange={(e) => {
                      setWebPassword(e.target.value);
                      if (webStatus !== "idle") {
                        setWebStatus("idle");
                        setWebMessage("");
                      }
                    }}
                    placeholder="Mot de passe"
                    className="flex-1 px-4 py-2.5 sm:py-3 rounded-xl bg-[oklch(0.08_0.02_250)] border border-[oklch(0.55_0.18_240/30%)] text-white placeholder:text-[oklch(0.40_0.03_250)] text-sm sm:text-base focus:outline-none focus:border-[oklch(0.55_0.18_160/60%)] focus:ring-1 focus:ring-[oklch(0.55_0.18_160/30%)] transition-all"
                  />
                  <button
                    type="submit"
                    disabled={!webUsername.trim() || !webPassword.trim() || webStatus === "loading"}
                    className="flex items-center justify-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 rounded-xl text-sm sm:text-base font-semibold text-white bg-[oklch(0.45_0.18_160)] hover:bg-[oklch(0.50_0.20_160)] disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 shrink-0"
                    style={{ boxShadow: '0 0 12px oklch(0.45 0.18 160 / 25%)' }}
                  >
                    {webStatus === "loading" ? (
                      <Loader2 size={16} className="animate-spin" />
                    ) : (
                      <ArrowRight size={16} />
                    )}
                    <span className="hidden sm:inline">Accéder</span>
                  </button>
                </div>

                {/* Status message */}
                {webMessage && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex items-center gap-2 text-sm sm:text-base px-3 py-2 rounded-lg ${
                      webStatus === "success"
                        ? "bg-[oklch(0.45_0.18_160/10%)] text-[oklch(0.72_0.15_160)]"
                        : "bg-[oklch(0.50_0.20_30/10%)] text-[oklch(0.72_0.15_30)]"
                    }`}
                  >
                    {webStatus === "success" ? (
                      <CheckCircle2 size={16} className="shrink-0" />
                    ) : (
                      <AlertCircle size={16} className="shrink-0" />
                    )}
                    <span>{webMessage}</span>
                  </motion.div>
                )}
              </form>

              <p className="text-xs text-[oklch(0.45_0.03_250)]">
                Pas encore abonné ? <a href="#pricing" className="text-[oklch(0.72_0.15_160)] hover:underline">Souscrivez à un abonnement</a> pour obtenir vos identifiants.
              </p>
            </motion.div>

            {/* Downloader Code Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="glass-card rounded-2xl p-4 sm:p-6 space-y-4"
              style={{ boxShadow: '0 0 25px oklch(0.55 0.18 240 / 12%)' }}
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[oklch(0.55_0.18_240/15%)] flex items-center justify-center shrink-0" style={{ boxShadow: '0 0 12px oklch(0.65 0.18 240 / 25%)' }}>
                  <Download size={18} className="text-[oklch(0.72_0.15_210)]" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-lg sm:text-xl">Code Downloader TV</h3>
                  <p className="text-xs sm:text-sm text-[oklch(0.55_0.03_250)]">Pour l'app Downloader sur Fire TV / Android TV</p>
                </div>
              </div>

              <div className="flex items-center gap-3 sm:gap-4">
                <div className="flex-1 flex items-center justify-center gap-1.5 sm:gap-2 py-3 sm:py-4 rounded-xl bg-[oklch(0.08_0.02_250)] border border-[oklch(0.55_0.18_240/30%)]">
                  {DOWNLOADER_CODE_TV.split("").map((digit, i) => (
                    <span
                      key={i}
                      className="inline-flex items-center justify-center w-8 h-10 sm:w-11 sm:h-14 rounded-md sm:rounded-lg text-lg sm:text-2xl font-bold text-white bg-[oklch(0.15_0.03_240)] border border-[oklch(0.55_0.18_240/25%)]"
                      style={{ 
                        fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
                        textShadow: '0 0 10px oklch(0.65 0.18 240 / 50%)',
                        boxShadow: '0 0 8px oklch(0.55 0.18 240 / 15%)',
                      }}
                    >
                      {digit}
                    </span>
                  ))}
                </div>
                <button
                  onClick={copyCode}
                  className="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2.5 sm:py-3 rounded-xl text-xs sm:text-sm font-semibold text-white bg-[oklch(0.55_0.18_240)] hover:bg-[oklch(0.60_0.20_240)] transition-all duration-300 shrink-0"
                  style={{ boxShadow: '0 0 12px oklch(0.55 0.18 240 / 25%)' }}
                >
                  {copied ? <Check size={14} /> : <Copy size={14} />}
                  <span className="hidden sm:inline">{copied ? "Copié !" : "Copier"}</span>
                </button>
              </div>

              <div className="space-y-2 pt-1 sm:pt-2">
                <p className="text-sm sm:text-base font-semibold text-[oklch(0.80_0.03_250)]">Comment utiliser ce code :</p>
                <div className="space-y-1.5">
                  {[
                    "Ouvrez l'app Downloader sur votre Fire TV / Android TV",
                    "Entrez le code ci-dessus dans le champ URL",
                    "L'application BLCTV Player se télécharge automatiquement",
                  ].map((step, i) => (
                    <div key={i} className="flex items-start gap-2 sm:gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-[oklch(0.55_0.18_240/20%)] flex items-center justify-center shrink-0 text-[10px] font-bold text-[oklch(0.72_0.15_210)] mt-0.5">
                        {i + 1}
                      </span>
                      <p className="text-sm sm:text-base text-[oklch(0.65_0.03_250)]">{step}</p>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Steps */}
            <div className="space-y-3 sm:space-y-4">
              <h3 className="text-lg sm:text-xl font-semibold text-white">Installation en 3 étapes :</h3>
              {[
                "Téléchargez le fichier APK correspondant à votre appareil",
                "Autorisez l'installation depuis des sources inconnues dans vos paramètres",
                "Installez l'application et entrez votre code d'activation",
              ].map((step, i) => (
                <div key={i} className="flex items-start gap-3 sm:gap-4">
                  <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-[oklch(0.55_0.18_240/15%)] flex items-center justify-center shrink-0 text-xs sm:text-sm font-bold text-[oklch(0.72_0.15_210)]">
                    {i + 1}
                  </div>
                  <p className="text-base sm:text-lg text-[oklch(0.70_0.03_250)] pt-0.5 sm:pt-1">{step}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Right: compatible devices */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="grid grid-cols-2 gap-3 sm:gap-4"
          >
            {devices.map((device, i) => (
              <motion.div
                key={device.label}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.3 + i * 0.1 }}
                className="glass-card rounded-xl sm:rounded-2xl p-4 sm:p-6 text-center space-y-2 sm:space-y-3 group"
              >
                <div className="w-10 h-10 sm:w-14 sm:h-14 mx-auto rounded-lg sm:rounded-xl bg-[oklch(0.55_0.18_240/12%)] flex items-center justify-center group-hover:bg-[oklch(0.55_0.18_240/20%)] transition-all" style={{ boxShadow: '0 0 12px oklch(0.65 0.18 240 / 25%)' }}>
                  <device.icon size={22} className="text-[oklch(0.72_0.15_210)]" />
                </div>
                <h4 className="font-bold text-white text-base sm:text-lg">{device.label}</h4>
                <p className="text-xs sm:text-sm text-[oklch(0.55_0.03_250)]">{device.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
