/*
 * BLCTV Store — Frosted Glass Tech Design
 * Footer: contact info, links, and branding
 * Responsive: stacked on mobile, grid on tablet/desktop
 */
import { Mail, MessageCircle, Instagram, Send } from "lucide-react";

const LOGO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/blctv_store_logo_nobg_c7deb4fe.png";

const footerLinks = [
  { label: "Accueil", href: "#hero" },
  { label: "Fonctionnalités", href: "#features" },
  { label: "Abonnements", href: "#pricing" },
  { label: "Application", href: "#download" },
  { label: "Tutoriels", href: "#tutorials" },
];

export default function FooterSection() {
  const scrollTo = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      {/* Contact section */}
      <section id="contact" className="relative py-16 sm:py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[oklch(0.08_0.02_250)] pointer-events-none" />

        <div className="container relative z-10">
          <div className="text-center mb-8 sm:mb-12">
            <span className="inline-block px-4 py-1.5 rounded-full text-sm font-semibold tracking-wider uppercase text-[oklch(0.72_0.15_210)] bg-[oklch(0.65_0.18_240/10%)] neon-border mb-4">
              Contact
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-3 sm:mb-4">
              Une question ? <span className="text-gradient-blue neon-text">Contactez-nous</span>
            </h2>
            <p className="text-base sm:text-lg text-[oklch(0.65_0.03_250)] md:text-xl max-w-xl mx-auto">
              Notre équipe est disponible pour répondre à toutes vos questions et vous accompagner.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-5 max-w-3xl mx-auto">
            {[
              { icon: MessageCircle, label: "WhatsApp", value: "Nous contacter", href: "#" },
              { icon: Mail, label: "Email", value: "contact@blctv.store", href: "mailto:contact@blctv.store" },
              { icon: Instagram, label: "Instagram", value: "@blctvstore", href: "#" },
            ].map((contact) => (
              <a
                key={contact.label}
                href={contact.href}
                className="glass-card rounded-xl sm:rounded-2xl p-4 sm:p-6 text-center space-y-2 sm:space-y-3 group block"
              >
                <div className="w-10 h-10 sm:w-12 sm:h-12 mx-auto rounded-lg sm:rounded-xl bg-[oklch(0.55_0.18_240/12%)] flex items-center justify-center group-hover:bg-[oklch(0.55_0.18_240/20%)] transition-all" style={{ boxShadow: '0 0 12px oklch(0.65 0.18 240 / 25%)' }}>
                  <contact.icon size={20} className="text-[oklch(0.72_0.15_210)]" />
                </div>
                <h4 className="font-bold text-white text-base sm:text-lg">{contact.label}</h4>
                <p className="text-sm sm:text-base text-[oklch(0.60_0.03_250)]">{contact.value}</p>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      {/* Neon line separator */}
      <div className="neon-line mx-auto w-full" />
      <footer className="relative bg-[oklch(0.08_0.02_250)]">
        <div className="container py-8 sm:py-12">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 sm:gap-8 items-start">
            {/* Logo & description */}
            <div className="space-y-3 sm:space-y-4 text-center sm:text-left">
              <img src={LOGO} alt="BLCTV Store" className="h-10 sm:h-12 w-auto mx-auto sm:mx-0" />
              <p className="text-sm sm:text-base text-[oklch(0.55_0.03_250)] leading-relaxed max-w-xs mx-auto sm:mx-0">
                BLCTV Store — votre fournisseur d'abonnement IPTV premium en 4K Ultra HD. Spécialiste IPTV Antilles, Guadeloupe, Martinique, Guyane et DOM-TOM. Le meilleur du divertissement sur tous vos écrans.
              </p>
            </div>

            {/* Links */}
            <div className="text-center sm:text-left">
              <h4 className="font-semibold text-white mb-3 sm:mb-4 text-base sm:text-lg">Navigation</h4>
              <ul className="space-y-1.5 sm:space-y-2">
                {footerLinks.map((link) => (
                  <li key={link.href}>
                    <button
                      onClick={() => scrollTo(link.href)}
                      className="text-sm sm:text-base text-[oklch(0.55_0.03_250)] hover:text-[oklch(0.72_0.15_210)] transition-colors"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Newsletter-style CTA */}
            <div className="text-center sm:text-left">
              <h4 className="font-semibold text-white mb-3 sm:mb-4 text-base sm:text-lg">Restez informé</h4>
              <p className="text-sm sm:text-base text-[oklch(0.55_0.03_250)] mb-3 sm:mb-4">
                Recevez nos offres et promotions exclusives.
              </p>
              <div className="flex gap-2 max-w-xs mx-auto sm:mx-0">
                <input
                  type="email"
                  placeholder="Votre email"
                  className="flex-1 min-w-0 px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg text-sm sm:text-base bg-[oklch(0.15_0.025_250/60%)] border border-[oklch(0.30_0.04_250/40%)] text-white placeholder:text-[oklch(0.45_0.03_250)] focus:outline-none focus:border-[oklch(0.55_0.15_240/60%)] transition-colors"
                />
                <button className="px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg bg-[oklch(0.55_0.18_240)] hover:bg-[oklch(0.60_0.20_240)] transition-colors shrink-0">
                  <Send size={14} className="text-white" />
                </button>
              </div>
            </div>
          </div>

          {/* SEO content block */}
          <div className="mt-8 sm:mt-10 pt-4 sm:pt-6 border-t border-[oklch(0.25_0.03_250/30%)]">
            <p className="text-xs text-[oklch(0.40_0.02_250)] leading-relaxed max-w-4xl mx-auto text-center mb-4">
              BLCTV Store est le meilleur service d'abonnement IPTV premium disponible en France métropolitaine et dans les DOM-TOM (Guadeloupe, Martinique, Guyane, Réunion, Mayotte). Notre service IPTV propose plus de 10 000 chaînes TV en direct incluant toutes les chaînes françaises (TF1, France 2, M6, Canal+, beIN Sports, RMC Sport), les chaînes antillaises (Guadeloupe 1ère, Martinique 1ère), ainsi que 25 000 films et 7 000 séries en qualité 4K Ultra HD. Compatible Android TV, Amazon Fire TV Stick, smartphones, tablettes et ordinateurs. Essai gratuit 48h sans engagement.
            </p>
          </div>

          <div className="mt-4 pt-4 border-t border-[oklch(0.25_0.03_250/30%)] flex flex-col sm:flex-row justify-between items-center gap-3 sm:gap-4">
            <p className="text-xs sm:text-sm text-[oklch(0.45_0.03_250)]">
              &copy; {new Date().getFullYear()} BLCTV Store — Abonnement IPTV Premium 4K. Tous droits réservés.
            </p>
            <div className="flex gap-3 sm:gap-4 text-xs sm:text-sm text-[oklch(0.45_0.03_250)]">
              <button className="hover:text-[oklch(0.72_0.15_210)] transition-colors">Mentions légales</button>
              <button className="hover:text-[oklch(0.72_0.15_210)] transition-colors">CGV</button>
              <button className="hover:text-[oklch(0.72_0.15_210)] transition-colors">Confidentialité</button>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}
