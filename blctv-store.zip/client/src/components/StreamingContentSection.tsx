/*
 * BLCTV Store — Frosted Glass Tech Design
 * StreamingContent: "Vos contenus préférés au même endroit"
 * Carrousels de jaquettes films/séries + logos plateformes streaming
 * Même DA (frosted glass, neon blue)
 */
import { motion } from "framer-motion";
import { Film, Clapperboard, Popcorn, ChevronLeft, ChevronRight } from "lucide-react";
import { useRef, useState, useCallback, useEffect } from "react";

const CDN = "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri";

/* ── Films populaires ── */
const movies = [
  { title: "Dune: Part Two", img: `${CDN}/movie-dune-part-two_2c2c7a8b.jpg` },
  { title: "Deadpool & Wolverine", img: `${CDN}/movie-deadpool-wolverine_482430cc.jpg` },
  { title: "Vice-versa 2", img: `${CDN}/movie-inside-out-2_4ab0b06e.jpg` },
  { title: "Godzilla x Kong", img: `${CDN}/movie-godzilla-x-kong_48ccbff3.jpg` },
  { title: "Moi, moche et méchant 4", img: `${CDN}/movie-despicable-me-4_e7770efa.jpg` },
  { title: "Vaiana 2", img: `${CDN}/movie-moana-2_571fc2ec.jpg` },
  { title: "Civil War", img: `${CDN}/movie-civil-war_851385ce.jpg` },
  { title: "Monkey Man", img: `${CDN}/movie-monkey-man_fbcbe773.jpg` },
  { title: "The Watchers", img: `${CDN}/movie-the-watchers_2e4dc158.jpg` },
  { title: "Nosferatu", img: `${CDN}/movie-nosferatu_34a43e88.jpg` },
  { title: "Furiosa", img: `${CDN}/movie-furiosa_9d608221.jpg` },
  { title: "La Planète des Singes", img: `${CDN}/movie-kingdom-planet-apes_325ce116.jpg` },
  { title: "The Fall Guy", img: `${CDN}/movie-the-fall-guy_c5b7e880.jpg` },
  { title: "The Beekeeper", img: `${CDN}/movie-the-beekeeper_7b1f5106.jpg` },
  { title: "Madame Web", img: `${CDN}/movie-madame-web_e50d9c3f.jpg` },
  { title: "Argylle", img: `${CDN}/movie-argylle_eb624066.jpg` },
  { title: "Sans un bruit : Jour 1", img: `${CDN}/movie-a-quiet-place-day-one_edda0f45.jpg` },
  { title: "Alien: Romulus", img: `${CDN}/movie-alien-romulus_de0158fe.jpg` },
  { title: "Bad Boys: Ride or Die", img: `${CDN}/movie-bad-boys-ride-or-die_db430823.jpg` },
  { title: "Ministry of War", img: `${CDN}/movie-ministry-ungentlemanly-warfare_7ce16224.jpg` },
];

/* ── Séries tendances ── */
const series = [
  { title: "Stranger Things", img: `${CDN}/series-stranger-things_d4fc062d.jpg` },
  { title: "True Detective", img: `${CDN}/series-true-detective_fa73c4be.jpg` },
  { title: "The Gentlemen", img: `${CDN}/series-the-gentlemen_e96452d2.jpg` },
  { title: "Fallout", img: `${CDN}/series-fallout_554f6be7.jpg` },
  { title: "Shōgun", img: `${CDN}/series-shogun_7c9be26b.jpg` },
  { title: "3 Body Problem", img: `${CDN}/series-3-body-problem_ac033c05.jpg` },
  { title: "The Penguin", img: `${CDN}/series-the-penguin_032c56cf.jpg` },
  { title: "House of the Dragon", img: `${CDN}/series-house-of-the-dragon_7e910516.jpg` },
  { title: "The Boys", img: `${CDN}/series-the-boys_cab7a7b3.jpg` },
  { title: "Bridgerton", img: `${CDN}/series-bridgerton_3ef67451.jpg` },
  { title: "The Last of Us", img: `${CDN}/series-the-last-of-us_6d3c8f9f.jpg` },
  { title: "Avatar", img: `${CDN}/series-avatar-last-airbender_894a6462.jpg` },
  { title: "Masters of the Air", img: `${CDN}/series-masters-of-the-air_6b176177.jpg` },
  { title: "Echo", img: `${CDN}/series-echo_eb2cea9a.jpg` },
  { title: "Percy Jackson", img: `${CDN}/series-percy-jackson_86bd753d.jpg` },
  { title: "Griselda", img: `${CDN}/series-griselda_3024b7d9.jpg` },
  { title: "Mr. & Mrs. Smith", img: `${CDN}/series-mr-mrs-smith_e478aee8.jpg` },
  { title: "Baby Reindeer", img: `${CDN}/series-baby-reindeer_2c5fa934.jpg` },
  { title: "Dark Matter", img: `${CDN}/series-dark-matter_e1fec9f2.jpg` },
  { title: "Ripley", img: `${CDN}/series-ripley_922ecd75.jpg` },
  { title: "The Acolyte", img: `${CDN}/series-the-acolyte_d648680f.jpg` },
];

/* ── Logos plateformes ── */
const platforms = [
  { name: "Netflix", logo: `${CDN}/netflix_de8bf0f3.png`, rounded: false },
  { name: "Disney+", logo: `${CDN}/disney-plus_9f8d37bb.png`, rounded: false },
  { name: "Amazon Prime", logo: `${CDN}/prime-video_d1917f90.png`, rounded: false },
  { name: "Canal+", logo: `${CDN}/canal-plus_129968db.png`, rounded: false },
  { name: "HBO Max", logo: `${CDN}/hbo-max_9d01bc6d.png`, rounded: false },
  { name: "Apple TV+", logo: `${CDN}/apple-tv-plus_847c2b03.png`, rounded: false },
  { name: "Paramount+", logo: `${CDN}/paramount-plus-blue_e6d5a77e.png`, rounded: false },
  { name: "Hulu", logo: `${CDN}/hulu_685d1830.png`, rounded: false },
  { name: "Crunchyroll", logo: `${CDN}/crunchyroll_720d4cdf.png`, rounded: false },
  { name: "beIN Sports", logo: `${CDN}/bein-sports_dedeb430.png`, rounded: false },
  { name: "OCS", logo: `${CDN}/ocs-streaming_37ad160d.png`, rounded: false },
  { name: "RMC Sport", logo: `${CDN}/rmc-sport-blue_8abb27d8.png`, rounded: true },
];

const categories = [
  { icon: Film, label: "25 000+ Films", desc: "Blockbusters, classiques, films d'auteur" },
  { icon: Clapperboard, label: "7 000+ Séries", desc: "Séries originales Netflix, Disney+, HBO..." },
  { icon: Popcorn, label: "Nouveautés", desc: "Ajouts quotidiens de contenus récents" },
];

/* ── Carousel component ── */
function Carousel({ items, label }: { items: { title: string; img: string }[]; label: string }) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const checkScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    setCanScrollLeft(el.scrollLeft > 5);
    setCanScrollRight(el.scrollLeft < el.scrollWidth - el.clientWidth - 5);
  }, []);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    checkScroll();
    el.addEventListener("scroll", checkScroll, { passive: true });
    window.addEventListener("resize", checkScroll);
    return () => {
      el.removeEventListener("scroll", checkScroll);
      window.removeEventListener("resize", checkScroll);
    };
  }, [checkScroll]);

  const scroll = (dir: "left" | "right") => {
    const el = scrollRef.current;
    if (!el) return;
    const amount = el.clientWidth * 0.7;
    el.scrollBy({ left: dir === "left" ? -amount : amount, behavior: "smooth" });
  };

  return (
    <div className="relative group/carousel">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 sm:mb-5">
        <h3 className="text-xl sm:text-2xl md:text-3xl font-bold text-white">{label}</h3>
        <div className="flex gap-2">
          <button
            onClick={() => scroll("left")}
            disabled={!canScrollLeft}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-full glass-card flex items-center justify-center text-white hover:bg-[oklch(0.55_0.18_240/20%)] transition-all disabled:opacity-30 disabled:cursor-not-allowed"
            aria-label={`Défiler ${label} vers la gauche`}
          >
            <ChevronLeft size={20} />
          </button>
          <button
            onClick={() => scroll("right")}
            disabled={!canScrollRight}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-full glass-card flex items-center justify-center text-white hover:bg-[oklch(0.55_0.18_240/20%)] transition-all disabled:opacity-30 disabled:cursor-not-allowed"
            aria-label={`Défiler ${label} vers la droite`}
          >
            <ChevronRight size={20} />
          </button>
        </div>
      </div>

      {/* Scrollable row */}
      <div
        ref={scrollRef}
        className="flex gap-3 sm:gap-4 overflow-x-auto scrollbar-hide pb-2"
        style={{ scrollSnapType: "x mandatory", WebkitOverflowScrolling: "touch" }}
      >
        {items.map((item, i) => (
          <motion.div
            key={item.title}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.3, delay: Math.min(i * 0.03, 0.3) }}
            className="flex-shrink-0 w-[130px] sm:w-[155px] md:w-[170px] group/card cursor-default"
            style={{ scrollSnapAlign: "start" }}
          >
            <div className="relative aspect-[2/3] rounded-lg sm:rounded-xl overflow-hidden mb-2">
              <img
                src={item.img}
                alt={item.title}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-400 group-hover/card:scale-110"
              />
              {/* Hover overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.08_0.02_250/90%)] via-transparent to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity duration-300" />
              {/* Neon border on hover */}
              <div className="absolute inset-0 rounded-lg sm:rounded-xl border-2 border-transparent group-hover/card:border-[oklch(0.72_0.15_210/60%)] transition-all duration-300" style={{ boxShadow: 'none' }} />
            </div>
            <p className="text-xs sm:text-sm text-[oklch(0.70_0.03_250)] font-medium truncate px-0.5 group-hover/card:text-white transition-colors">
              {item.title}
            </p>
          </motion.div>
        ))}
      </div>

      {/* Edge fade left */}
      {canScrollLeft && (
        <div className="absolute left-0 top-[3.5rem] bottom-0 w-12 bg-gradient-to-r from-[oklch(0.08_0.02_250)] to-transparent pointer-events-none z-10" />
      )}
      {/* Edge fade right */}
      {canScrollRight && (
        <div className="absolute right-0 top-[3.5rem] bottom-0 w-12 bg-gradient-to-l from-[oklch(0.08_0.02_250)] to-transparent pointer-events-none z-10" />
      )}
    </div>
  );
}

export default function StreamingContentSection() {
  return (
    <section id="streaming-content" className="relative py-16 sm:py-24 overflow-hidden">
      {/* Background accents */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[oklch(0.10_0.04_240/20%)] to-transparent pointer-events-none" />
      <div className="absolute top-1/4 right-0 w-[500px] h-[500px] rounded-full bg-[oklch(0.55_0.18_240/6%)] blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-[350px] h-[350px] rounded-full bg-[oklch(0.65_0.15_210/5%)] blur-[100px] pointer-events-none" />

      <div className="container relative z-10">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10 sm:mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-semibold tracking-wider uppercase text-[oklch(0.72_0.15_210)] bg-[oklch(0.65_0.18_240/10%)] neon-border mb-4">
            Catalogue illimité
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-3 sm:mb-4">
            Vos contenus préférés <span className="text-gradient-blue neon-text">au même endroit</span>
          </h2>
          <p className="text-base sm:text-lg text-[oklch(0.65_0.03_250)] md:text-xl max-w-3xl mx-auto leading-relaxed">
            Retrouvez les films et séries de toutes les grandes plateformes de streaming dans un seul abonnement. Plus besoin de jongler entre Netflix, Disney+, Amazon Prime et les autres.
          </p>
        </motion.div>

        {/* Films carousel */}
        <div className="mb-10 sm:mb-14">
          <Carousel items={movies} label="Films populaires" />
        </div>

        {/* Séries carousel */}
        <div className="mb-12 sm:mb-16">
          <Carousel items={series} label="Séries tendances" />
        </div>

        {/* Categories stats */}
        <div className="grid sm:grid-cols-3 gap-4 sm:gap-6 mb-12 sm:mb-16">
          {categories.map((cat, i) => (
            <motion.div
              key={cat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: 0.1 + i * 0.1 }}
              className="glass-card rounded-xl sm:rounded-2xl p-5 sm:p-6 flex items-center gap-4 group"
            >
              <div
                className="w-12 h-12 sm:w-14 sm:h-14 flex-shrink-0 rounded-xl bg-[oklch(0.55_0.18_240/12%)] flex items-center justify-center group-hover:bg-[oklch(0.55_0.18_240/20%)] transition-all"
                style={{ boxShadow: '0 0 12px oklch(0.65 0.18 240 / 25%)' }}
              >
                <cat.icon size={22} className="text-[oklch(0.72_0.15_210)]" />
              </div>
              <div>
                <div className="text-lg sm:text-xl font-bold text-white">{cat.label}</div>
                <div className="text-sm text-[oklch(0.55_0.03_250)]">{cat.desc}</div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Streaming platforms */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-6 sm:mb-8"
        >
          <h3 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-2">
            Toutes les plateformes en <span className="text-gradient-blue">1 abonnement</span>
          </h3>
          <p className="text-sm sm:text-base text-[oklch(0.55_0.03_250)]">
            Contenus de toutes ces plateformes et bien plus encore
          </p>
        </motion.div>

        {/* Platform logos */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-wrap justify-center gap-4 sm:gap-6 max-w-5xl mx-auto"
        >
          {platforms.map((platform, i) => (
            <motion.div
              key={platform.name}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.3, delay: 0.3 + i * 0.05 }}
              className="w-[120px] sm:w-[140px] md:w-[160px] h-[70px] sm:h-[80px] md:h-[90px] rounded-xl bg-white/95 flex items-center justify-center p-2 sm:p-2.5 hover:scale-110 hover:bg-white transition-all duration-300 cursor-default overflow-hidden shadow-lg shadow-[oklch(0.55_0.18_240/15%)]"
            >
              <img
                src={platform.logo}
                alt={platform.name}
                loading="lazy"
                className={`max-w-full max-h-full object-contain ${platform.rounded ? 'rounded-lg' : ''}`}
              />
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Hide scrollbar CSS */}
      <style>{`
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </section>
  );
}
