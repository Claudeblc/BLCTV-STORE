/*
 * BLCTV Store — Anonymous Chat Widget
 * Floating chat bubble that connects to Telegram via backend
 * Fully responsive: full-screen on mobile, floating panel on desktop
 */
import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X, Send, User } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { nanoid } from "nanoid";

function getSessionId(): string {
  let id = localStorage.getItem("blctv_chat_session");
  if (!id) {
    id = nanoid(16);
    localStorage.setItem("blctv_chat_session", id);
  }
  return id;
}

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [sessionId] = useState(getSessionId);
  const [visitorName, setVisitorName] = useState("");
  const [nameSet, setNameSet] = useState(false);
  const [pendingPreMessage, setPendingPreMessage] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Listen for custom event to open chat with pre-filled message
  useEffect(() => {
    const handler = (e: CustomEvent<{ message: string }>) => {
      setPendingPreMessage(e.detail.message);
      setOpen(true);
    };
    window.addEventListener("open-chat-with-message", handler as EventListener);
    return () => window.removeEventListener("open-chat-with-message", handler as EventListener);
  }, []);

  // When name is set and there's a pending pre-message, fill the input
  useEffect(() => {
    if (nameSet && pendingPreMessage) {
      setMessage(pendingPreMessage);
      setPendingPreMessage(null);
    }
  }, [nameSet, pendingPreMessage]);

  const { data: messages, refetch } = trpc.chat.getMessages.useQuery(
    { sessionId },
    { enabled: open && nameSet, refetchInterval: open ? 5000 : false }
  );

  const sendMutation = trpc.chat.sendMessage.useMutation({
    onSuccess: () => {
      setMessage("");
      refetch();
    },
  });

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    if (messages) scrollToBottom();
  }, [messages, scrollToBottom]);

  const handleSend = () => {
    if (!message.trim()) return;
    sendMutation.mutate({
      sessionId,
      message: message.trim(),
      visitorName: visitorName || "Visiteur anonyme",
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSetName = () => {
    if (visitorName.trim()) {
      setNameSet(true);
    }
  };

  return (
    <>
      {/* Floating button */}
      <motion.button
        onClick={() => setOpen(!open)}
        className="chat-trigger-btn fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-[oklch(0.55_0.18_240)] text-white flex items-center justify-center shadow-lg hover:bg-[oklch(0.60_0.20_240)] transition-colors"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
      >
        {open ? <X size={22} /> : <MessageCircle size={22} />}
      </motion.button>

      {/* Chat panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed z-50 
              inset-0 sm:inset-auto
              sm:bottom-20 sm:right-4 md:right-6
              sm:w-[360px] sm:max-h-[500px] 
              sm:rounded-2xl overflow-hidden flex flex-col"
            style={{
              background: "oklch(0.12 0.02 250 / 98%)",
              border: "1px solid oklch(0.30 0.04 250 / 40%)",
              backdropFilter: "blur(20px)",
              boxShadow: "0 20px 60px oklch(0 0 0 / 50%)",
            }}
          >
            {/* Header */}
            <div className="px-4 sm:px-5 py-3 sm:py-4 border-b border-[oklch(0.25_0.03_250/30%)] flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[oklch(0.55_0.18_240/20%)] flex items-center justify-center">
                <MessageCircle size={18} className="text-[oklch(0.72_0.15_210)]" />
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-white text-base">Support BLCTV</h4>
                <p className="text-xs text-[oklch(0.55_0.03_250)]">
                  Nous répondons rapidement
                </p>
              </div>
              {/* Close button visible on mobile */}
              <button
                onClick={() => setOpen(false)}
                className="sm:hidden w-8 h-8 rounded-full bg-[oklch(0.20_0.03_250/60%)] flex items-center justify-center text-white"
              >
                <X size={18} />
              </button>
            </div>

            {!nameSet ? (
              /* Name input step */
              <div className="flex-1 flex flex-col items-center justify-center p-5 sm:p-6 gap-4">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[oklch(0.55_0.18_240/15%)] flex items-center justify-center">
                  <User size={24} className="text-[oklch(0.72_0.15_210)]" />
                </div>
                <p className="text-base text-[oklch(0.70_0.03_250)] text-center">
                  Choisissez un pseudo pour commencer la conversation (vous restez anonyme).
                </p>
                <input
                  type="text"
                  value={visitorName}
                  onChange={(e) => setVisitorName(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSetName()}
                  placeholder="Votre pseudo..."
                  className="w-full px-4 py-3 rounded-lg text-base bg-[oklch(0.15_0.025_250/60%)] border border-[oklch(0.30_0.04_250/40%)] text-white placeholder:text-[oklch(0.45_0.03_250)] focus:outline-none focus:border-[oklch(0.55_0.15_240/60%)] transition-colors"
                />
                <button
                  onClick={handleSetName}
                  disabled={!visitorName.trim()}
                  className="w-full py-3 rounded-lg text-base font-semibold text-white bg-[oklch(0.55_0.18_240)] hover:bg-[oklch(0.60_0.20_240)] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                >
                  Commencer le chat
                </button>
              </div>
            ) : (
              <>
                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3 min-h-0">
                  {/* Welcome message */}
                  <div className="flex gap-2">
                    <div className="w-7 h-7 rounded-full bg-[oklch(0.55_0.18_240/20%)] flex items-center justify-center shrink-0 mt-0.5">
                      <MessageCircle size={12} className="text-[oklch(0.72_0.15_210)]" />
                    </div>
                    <div className="bg-[oklch(0.18_0.025_250/60%)] rounded-2xl rounded-tl-sm px-3 sm:px-3.5 py-2 sm:py-2.5 max-w-[85%] sm:max-w-[80%]">
                      <p className="text-base text-[oklch(0.80_0.03_250)]">
                        Bonjour {visitorName} ! Comment pouvons-nous vous aider ?
                      </p>
                    </div>
                  </div>

                  {messages?.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex gap-2 ${msg.isFromVisitor ? "flex-row-reverse" : ""}`}
                    >
                      {!msg.isFromVisitor && (
                        <div className="w-7 h-7 rounded-full bg-[oklch(0.55_0.18_240/20%)] flex items-center justify-center shrink-0 mt-0.5">
                          <MessageCircle size={12} className="text-[oklch(0.72_0.15_210)]" />
                        </div>
                      )}
                      <div
                        className={`rounded-2xl px-3 sm:px-3.5 py-2 sm:py-2.5 max-w-[85%] sm:max-w-[80%] ${
                          msg.isFromVisitor
                            ? "bg-[oklch(0.55_0.18_240)] rounded-tr-sm"
                            : "bg-[oklch(0.18_0.025_250/60%)] rounded-tl-sm"
                        }`}
                      >
                        <p className="text-base text-white break-words">{msg.message}</p>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <div className="p-3 border-t border-[oklch(0.25_0.03_250/30%)] safe-area-bottom">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder="Votre message..."
                      className="flex-1 px-3 sm:px-3.5 py-3 rounded-lg text-base bg-[oklch(0.15_0.025_250/60%)] border border-[oklch(0.30_0.04_250/40%)] text-white placeholder:text-[oklch(0.45_0.03_250)] focus:outline-none focus:border-[oklch(0.55_0.15_240/60%)] transition-colors"
                    />
                    <button
                      onClick={handleSend}
                      disabled={!message.trim() || sendMutation.isPending}
                      className="px-3 sm:px-3.5 py-2.5 rounded-lg bg-[oklch(0.55_0.18_240)] hover:bg-[oklch(0.60_0.20_240)] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                    >
                      <Send size={16} className="text-white" />
                    </button>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
