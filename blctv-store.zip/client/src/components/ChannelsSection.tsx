/*
 * BLCTV Store — Frosted Glass Tech Design
 * Channels: liste complète des chaînes TV par catégorie avec logos et filtre adulte
 * Données récupérées directement du panel IPTV (12 000+ chaînes)
 */
import { useState, useMemo, useCallback } from "react";
import { motion } from "framer-motion";
import { Tv, Search, Eye, EyeOff, ChevronDown, ChevronUp } from "lucide-react";
import { channelCategories, type Channel } from "@/data/channels";

const ITEMS_PER_PAGE = 200;

// Helper to extract clean initials from channel name (ignore prefixes like "(FR)")
function getInitials(name: string): string {
  // Remove country prefix like "(FR) " or "FR | "
  let clean = name.replace(/^\([A-Z]{2,4}\)\s*/i, '').replace(/^[A-Z]{2,4}\s*\|\s*/i, '').trim();
  // Get first 2 meaningful chars
  const letters = clean.replace(/[^A-Za-z0-9]/g, '');
  return letters.slice(0, 2).toUpperCase() || 'TV';
}

export default function ChannelsSection() {
  const [selectedCategory, setSelectedCategory] = useState(() => {
    // Default to FRANCE UHD/FHD/HD category
    const found = channelCategories.find(c => c.name.includes('FRANCE UHD'));
    return found ? found.name : "Toutes";
  });
  const [showAdult, setShowAdult] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showAllCategories, setShowAllCategories] = useState(false);
  const [visibleCount, setVisibleCount] = useState(ITEMS_PER_PAGE);

  // Build visible categories — France TV first, then other TV, then radios last
  const visibleCats = useMemo(() => {
    let cats = channelCategories;
    if (!showAdult) {
      cats = cats.filter((c) => !c.isAdult);
    }
    // Sort: France TV categories first, radios last, then alphabetical
    const franceTvCats = cats.filter(c => {
      const upper = c.name.toUpperCase();
      return upper.includes('FRANCE') && !upper.includes('RADIO');
    });
    const radioCats = cats.filter(c => c.name.toUpperCase().includes('RADIO'));
    const otherCats = cats.filter(c => {
      const upper = c.name.toUpperCase();
      return !upper.includes('FRANCE') && !upper.includes('RADIO');
    });
    return [...franceTvCats, ...otherCats, ...radioCats];
  }, [showAdult]);

  // Category names for the selector
  const categoryNames = useMemo(() => {
    return ["Toutes", ...visibleCats.map((c) => c.name)];
  }, [visibleCats]);

  // Show first 15 categories + "Voir plus" button
  const displayedCategoryNames = useMemo(() => {
    if (showAllCategories) return categoryNames;
    return categoryNames.slice(0, 16);
  }, [categoryNames, showAllCategories]);

  // Total channel count
  const totalChannelCount = useMemo(() => {
    return visibleCats.reduce((sum, cat) => sum + cat.channels.length, 0);
  }, [visibleCats]);

  // Filtered channels
  const filteredChannels = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const results: { name: string; logo?: string; category: string; isAdult: boolean }[] = [];

    for (const cat of visibleCats) {
      if (selectedCategory !== "Toutes" && cat.name !== selectedCategory) continue;

      for (const ch of cat.channels) {
        if (query && !ch.name.toLowerCase().includes(query)) continue;
        results.push({ name: ch.name, logo: ch.logo, category: cat.name, isAdult: !!cat.isAdult });
      }
    }

    return results;
  }, [visibleCats, selectedCategory, searchQuery]);

  // Paginated channels for performance
  const displayedChannels = useMemo(() => {
    return filteredChannels.slice(0, visibleCount);
  }, [filteredChannels, visibleCount]);

  const hasMore = filteredChannels.length > visibleCount;

  // Reset visible count when filters change
  const handleCategoryChange = useCallback((cat: string) => {
    setSelectedCategory(cat);
    setVisibleCount(ITEMS_PER_PAGE);
  }, []);

  const handleSearchChange = useCallback((value: string) => {
    setSearchQuery(value);
    setVisibleCount(ITEMS_PER_PAGE);
  }, []);

  // Count per category
  const countForCategory = useCallback(
    (catName: string) => {
      const cat = visibleCats.find((c) => c.name === catName);
      return cat ? cat.channels.length : 0;
    },
    [visibleCats]
  );

  return (
    <section id="channels" className="relative py-16 sm:py-24 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[oklch(0.10_0.025_250)] via-[oklch(0.08_0.02_250)] to-[oklch(0.10_0.025_250)]" />
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: "radial-gradient(oklch(0.65 0.18 240) 1px, transparent 1px)",
          backgroundSize: "30px 30px",
        }}
      />

      <div className="container relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10 sm:mb-14"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-semibold tracking-wider uppercase text-[oklch(0.72_0.15_210)] bg-[oklch(0.65_0.18_240/10%)] neon-border mb-4">
            <Tv size={14} className="inline mr-1.5 -mt-0.5" />
            Catalogue
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-3 sm:mb-4">
            Nos <span className="text-gradient-blue neon-text">Chaînes TV</span>
          </h2>
          <p className="text-base sm:text-lg text-[oklch(0.65_0.03_250)] md:text-xl max-w-2xl mx-auto leading-relaxed">
            Plus de{" "}
            <strong className="text-white">{totalChannelCount.toLocaleString("fr-FR")} chaînes</strong>{" "}
            disponibles dans votre abonnement. Explorez notre catalogue complet par catégorie.
          </p>
        </motion.div>

        {/* Search + Adult toggle */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="flex flex-col sm:flex-row items-center gap-4 mb-6 sm:mb-8 max-w-2xl mx-auto"
        >
          {/* Search */}
          <div className="relative flex-1 w-full">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-[oklch(0.50_0.03_250)]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => handleSearchChange(e.target.value)}
              placeholder="Rechercher une chaîne..."
              className="w-full pl-10 pr-4 py-3 rounded-xl text-base bg-[oklch(0.12_0.025_250/80%)] border border-[oklch(0.30_0.04_250/40%)] text-white placeholder:text-[oklch(0.45_0.03_250)] focus:outline-none focus:border-[oklch(0.55_0.15_240/60%)] transition-colors"
              style={{ backdropFilter: "blur(12px)" }}
            />
          </div>

          {/* Adult toggle */}
          <label
            className="flex items-center gap-2.5 cursor-pointer select-none shrink-0 px-4 py-3 rounded-xl bg-[oklch(0.12_0.025_250/80%)] border border-[oklch(0.30_0.04_250/40%)]"
            style={{ backdropFilter: "blur(12px)" }}
          >
            <input
              type="checkbox"
              checked={showAdult}
              onChange={(e) => {
                setShowAdult(e.target.checked);
                if (!e.target.checked && selectedCategory === "Adulte") {
                  setSelectedCategory("Toutes");
                }
              }}
              className="sr-only"
            />
            <div
              className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
                showAdult
                  ? "bg-[oklch(0.55_0.18_240)] border-[oklch(0.55_0.18_240)]"
                  : "border-[oklch(0.40_0.04_250)] bg-transparent"
              }`}
            >
              {showAdult && (
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                  <path d="M2 6L5 9L10 3" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              )}
            </div>
            {showAdult ? (
              <Eye size={16} className="text-[oklch(0.72_0.15_210)]" />
            ) : (
              <EyeOff size={16} className="text-[oklch(0.50_0.03_250)]" />
            )}
            <span className="text-sm text-[oklch(0.65_0.03_250)]">+18</span>
          </label>
        </motion.div>

        {/* Category selector */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-8 sm:mb-10"
        >
          <div className="flex flex-wrap justify-center gap-2 sm:gap-2.5">
            {displayedCategoryNames.map((cat) => {
              const isAdultCat = visibleCats.some(c => c.name === cat && c.isAdult);
              return (
              <button
                key={cat}
                onClick={() => handleCategoryChange(cat)}
                className={`px-3 py-1.5 sm:px-4 sm:py-2 rounded-full text-xs sm:text-sm font-medium transition-all duration-300 ${
                  isAdultCat
                    ? selectedCategory === cat
                      ? "bg-[oklch(0.65_0.25_350)] text-white shadow-lg animate-pulse-slow"
                      : "bg-[oklch(0.25_0.12_350/60%)] text-[oklch(0.80_0.18_350)] border border-[oklch(0.55_0.20_350/50%)] hover:bg-[oklch(0.35_0.18_350/60%)] hover:text-white hover:border-[oklch(0.65_0.25_350/70%)]"
                    : selectedCategory === cat
                    ? "bg-[oklch(0.55_0.18_240)] text-white shadow-lg"
                    : "bg-[oklch(0.15_0.025_250/60%)] text-[oklch(0.65_0.03_250)] border border-[oklch(0.30_0.04_250/30%)] hover:border-[oklch(0.55_0.15_240/50%)] hover:text-white"
                }`}
                style={
                  isAdultCat
                    ? selectedCategory === cat
                      ? { boxShadow: "0 0 25px oklch(0.65 0.25 350 / 50%), 0 0 50px oklch(0.55 0.20 350 / 20%)" }
                      : { boxShadow: "0 0 15px oklch(0.55 0.20 350 / 25%)", animation: "playboy-glow 2s ease-in-out infinite" }
                    : selectedCategory === cat ? { boxShadow: "0 0 20px oklch(0.55 0.18 240 / 40%)" } : {}
                }
              >
                {isAdultCat && <span className="mr-1">🔞</span>}
                {cat}
                {cat !== "Toutes" && (
                  <span className="ml-1 text-xs opacity-70">({countForCategory(cat)})</span>
                )}
              </button>
              );
            })}
          </div>
          {categoryNames.length > 16 && (
            <div className="text-center mt-3">
              <button
                onClick={() => setShowAllCategories(!showAllCategories)}
                className="inline-flex items-center gap-1 text-sm text-[oklch(0.65_0.12_240)] hover:text-[oklch(0.75_0.15_240)] transition-colors"
              >
                {showAllCategories ? (
                  <>
                    Voir moins <ChevronUp size={16} />
                  </>
                ) : (
                  <>
                    Voir les {categoryNames.length - 16} autres catégories <ChevronDown size={16} />
                  </>
                )}
              </button>
            </div>
          )}
        </motion.div>

        {/* Channel count */}
        <div className="text-center mb-6">
          <p className="text-sm text-[oklch(0.55_0.03_250)]">
            {filteredChannels.length.toLocaleString("fr-FR")} chaîne
            {filteredChannels.length !== 1 ? "s" : ""}{" "}
            {selectedCategory !== "Toutes" ? `dans ${selectedCategory}` : "au total"}
          </p>
        </div>

        {/* Channels grid — with logos */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2 sm:gap-2.5">
          {displayedChannels.map((channel, idx) => (
            <div
              key={`${channel.category}-${channel.name}-${idx}`}
              className={`group relative flex flex-col items-center px-3 py-3 sm:px-3.5 sm:py-4 rounded-xl text-center transition-all duration-300 ${
                channel.isAdult
                  ? "bg-[oklch(0.15_0.06_350/60%)] border border-[oklch(0.40_0.12_350/30%)] hover:border-[oklch(0.50_0.15_350/50%)]"
                  : "bg-[oklch(0.14_0.025_250/60%)] border border-[oklch(0.28_0.04_250/30%)] hover:border-[oklch(0.55_0.15_240/50%)]"
              }`}
              style={{ backdropFilter: "blur(8px)" }}
            >
              {/* Channel logo */}
              {channel.logo ? (
                <div className="w-10 h-10 sm:w-12 sm:h-12 mb-2 rounded-lg overflow-hidden bg-[oklch(0.18_0.02_250)] flex items-center justify-center shrink-0">
                  <img
                    src={channel.logo}
                    alt={channel.name}
                    className="w-full h-full object-contain"
                    loading="lazy"
                    onError={(e) => {
                      // Hide broken images, show initials fallback
                      const target = e.currentTarget;
                      target.style.display = "none";
                      const fallback = target.nextElementSibling as HTMLElement;
                      if (fallback) fallback.style.display = "flex";
                    }}
                  />
                  <div className="hidden items-center justify-center w-full h-full text-xs font-bold text-[oklch(0.55_0.12_240)]">
                    {getInitials(channel.name)}
                  </div>
                </div>
              ) : (
                <div className="w-10 h-10 sm:w-12 sm:h-12 mb-2 rounded-lg bg-gradient-to-br from-[oklch(0.20_0.04_240)] to-[oklch(0.15_0.03_260)] flex items-center justify-center shrink-0 border border-[oklch(0.28_0.04_250/40%)]">
                  <span className="text-xs font-bold text-[oklch(0.55_0.12_240)]">
                    {getInitials(channel.name)}
                  </span>
                </div>
              )}

              <p
                className={`text-xs sm:text-sm font-medium truncate w-full ${
                  channel.isAdult
                    ? "text-[oklch(0.75_0.08_350)] group-hover:text-[oklch(0.85_0.10_350)]"
                    : "text-[oklch(0.80_0.03_250)] group-hover:text-white"
                } transition-colors`}
              >
                {channel.name}
              </p>
              <p className="text-[10px] sm:text-xs text-[oklch(0.45_0.03_250)] mt-0.5 truncate w-full">
                {channel.category}
              </p>
            </div>
          ))}
        </div>

        {/* Load more button */}
        {hasMore && (
          <div className="text-center mt-6">
            <button
              onClick={() => setVisibleCount((prev) => prev + ITEMS_PER_PAGE)}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-base font-medium bg-[oklch(0.55_0.18_240)] text-white hover:bg-[oklch(0.60_0.18_240)] transition-colors shadow-lg"
              style={{ boxShadow: "0 0 20px oklch(0.55 0.18 240 / 30%)" }}
            >
              <ChevronDown size={18} />
              Afficher plus ({(filteredChannels.length - visibleCount).toLocaleString("fr-FR")} restantes)
            </button>
          </div>
        )}

        {/* Empty state */}
        {filteredChannels.length === 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-12">
            <Tv size={48} className="mx-auto text-[oklch(0.35_0.03_250)] mb-4" />
            <p className="text-lg text-[oklch(0.50_0.03_250)]">Aucune chaîne trouvée</p>
            <p className="text-sm text-[oklch(0.40_0.03_250)] mt-1">
              Essayez une autre recherche ou catégorie
            </p>
          </motion.div>
        )}

        {/* Note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-center text-sm text-[oklch(0.45_0.03_250)] mt-8 sm:mt-10 max-w-xl mx-auto"
        >
          Cette liste représente notre catalogue complet. De nouvelles chaînes sont ajoutées régulièrement.
        </motion.p>
      </div>
    </section>
  );
}
