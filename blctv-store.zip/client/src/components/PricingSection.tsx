/**
 * BLCTV Store — Frosted Glass Tech Design
 * Pricing: Full Pack (sans adulte) et Golden Pack (avec adulte)
 * Durées: 1 mois, 3 mois, 6 mois, 12 mois, 24 mois + Test gratuit 48h
 * Paiement via Stripe — Vérification client en temps réel via API panel
 * Responsive: tabs pour basculer entre Full Pack et Golden Pack
 */
import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Check,
  Crown,
  Gem,
  ShieldCheck,
  Gift,
  Zap,
  Film,
  UserCheck,
  Loader2,
  CheckCircle2,
  XCircle,
  ExternalLink,
  CreditCard,
  Clock,
  Star,
  Sparkles,
} from "lucide-react";
import { trpc } from "@/lib/trpc";

/* ── Stripe Payment Links ── */
const STRIPE_LINKS: Record<string, string> = {
  // Full Pack (sans adulte)
  full_1m: "https://buy.stripe.com/fZubJ09xscZn29TbB64gg04",
  full_3m: "https://buy.stripe.com/cNi5kC2507F34i1bB64gg05",
  full_6m: "https://buy.stripe.com/bJe14meRMe3reWF48E4gg06",
  full_12m: "https://buy.stripe.com/5kQfZgdNI6AZ15PgVq4gg07",
  full_12m_renew: "https://buy.stripe.com/9B65kCfVQ1gF29Tax24gg00",
  full_24m: "https://buy.stripe.com/9B6bJ09xs3oNbKteNi4gg08",
  // Golden Pack (avec adulte)
  golden_1m: "https://buy.stripe.com/bJe7sKdNIaRf15P5cI4gg09",
  golden_3m: "https://buy.stripe.com/bJe8wO9xs4sReWFbB64gg0a",
  golden_6m: "https://buy.stripe.com/bJe9AScJEf7vcOxbB64gg0b",
  golden_12m: "https://buy.stripe.com/9B6aEWdNI1gFg0J48E4gg0c",
  golden_24m: "https://buy.stripe.com/7sY4gy7pkf7vaGp9sY4gg0d",
};

interface PlanDuration {
  key: string;
  label: string;
  period: string;
  fullPrice: string;
  fullPriceNum: number;
  goldenPrice: string;
  goldenPriceNum: number;
  perMonth?: string;
  goldenPerMonth?: string;
  popular?: boolean;
  badge?: string;
  icon: typeof Clock;
  features: string[];
  goldenFeatures: string[];
  stripeKeyFull: string;
  stripeKeyGolden: string;
  hasRenewal?: boolean;
  renewalPrice?: string;
  stripeKeyRenewal?: string;
}

const durations: PlanDuration[] = [
  {
    key: "1m",
    label: "1 Mois",
    period: "/ mois",
    fullPrice: "19,99€",
    fullPriceNum: 19.99,
    goldenPrice: "39,99€",
    goldenPriceNum: 39.99,
    icon: Clock,
    badge: "Découverte",
    features: [
      "Accès complet 1 mois",
      "10 000+ chaînes TV en direct",
      "25 000+ films à la demande",
      "7 000+ séries disponibles",
      "Qualité 4K Ultra HD",
      "1 appareil connecté",
      "Support par chat",
    ],
    goldenFeatures: [
      "Accès complet 1 mois",
      "10 000+ chaînes TV en direct",
      "25 000+ films à la demande",
      "7 000+ séries disponibles",
      "Qualité 4K Ultra HD",
      "1 appareil connecté",
      "Chaînes adultes incluses",
      "Support par chat",
    ],
    stripeKeyFull: "full_1m",
    stripeKeyGolden: "golden_1m",
  },
  {
    key: "3m",
    label: "3 Mois",
    period: "/ 3 mois",
    fullPrice: "49,99€",
    fullPriceNum: 49.99,
    goldenPrice: "59,99€",
    goldenPriceNum: 59.99,
    perMonth: "16,66€/mois",
    goldenPerMonth: "20,00€/mois",
    icon: Zap,
    features: [
      "Accès complet 3 mois",
      "10 000+ chaînes TV en direct",
      "25 000+ films à la demande",
      "7 000+ séries disponibles",
      "Qualité 4K Ultra HD",
      "1 appareil connecté",
      "Support par chat",
    ],
    goldenFeatures: [
      "Accès complet 3 mois",
      "10 000+ chaînes TV en direct",
      "25 000+ films à la demande",
      "7 000+ séries disponibles",
      "Qualité 4K Ultra HD",
      "1 appareil connecté",
      "Chaînes adultes incluses",
      "Support par chat",
    ],
    stripeKeyFull: "full_3m",
    stripeKeyGolden: "golden_3m",
  },
  {
    key: "6m",
    label: "6 Mois",
    period: "/ 6 mois",
    fullPrice: "79,99€",
    fullPriceNum: 79.99,
    goldenPrice: "89,99€",
    goldenPriceNum: 89.99,
    perMonth: "13,33€/mois",
    goldenPerMonth: "15,00€/mois",
    icon: Star,
    features: [
      "Accès complet 6 mois",
      "10 000+ chaînes TV en direct",
      "25 000+ films à la demande",
      "7 000+ séries disponibles",
      "Qualité 4K Ultra HD",
      "1 appareil connecté",
      "Support prioritaire",
    ],
    goldenFeatures: [
      "Accès complet 6 mois",
      "10 000+ chaînes TV en direct",
      "25 000+ films à la demande",
      "7 000+ séries disponibles",
      "Qualité 4K Ultra HD",
      "1 appareil connecté",
      "Chaînes adultes incluses",
      "Support prioritaire",
    ],
    stripeKeyFull: "full_6m",
    stripeKeyGolden: "golden_6m",
  },
  {
    key: "12m",
    label: "12 Mois",
    period: "/ an",
    fullPrice: "149,99€",
    fullPriceNum: 149.99,
    goldenPrice: "189,99€",
    goldenPriceNum: 189.99,
    perMonth: "12,50€/mois",
    goldenPerMonth: "15,83€/mois",
    popular: true,
    badge: "Populaire",
    icon: Crown,
    features: [
      "Accès illimité 12 mois",
      "10 000+ chaînes TV en direct",
      "25 000+ films à la demande",
      "7 000+ séries disponibles",
      "Qualité 4K Ultra HD",
      "1 appareil connecté",
      "Support prioritaire 24/7",
      "Mises à jour automatiques",
    ],
    goldenFeatures: [
      "Accès illimité 12 mois",
      "10 000+ chaînes TV en direct",
      "25 000+ films à la demande",
      "7 000+ séries disponibles",
      "Qualité 4K Ultra HD",
      "1 appareil connecté",
      "Chaînes adultes incluses",
      "Support prioritaire 24/7",
      "Mises à jour automatiques",
    ],
    stripeKeyFull: "full_12m",
    stripeKeyGolden: "golden_12m",
    hasRenewal: true,
    renewalPrice: "100€",
    stripeKeyRenewal: "full_12m_renew",
  },

];

/* ── Main Pricing Section ── */
export default function PricingSection() {
  const [packType, setPackType] = useState<"full" | "golden">("full");
  const [renewalOpen, setRenewalOpen] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [verified, setVerified] = useState(false);
  const [verifyMessage, setVerifyMessage] = useState("");
  const [verifyError, setVerifyError] = useState("");

  const verifyMutation = trpc.verifyClient.useMutation({
    onSuccess: (data) => {
      if (data.valid) {
        setVerified(true);
        setVerifyMessage(data.message);
        setVerifyError("");
      } else {
        setVerified(false);
        setVerifyMessage("");
        setVerifyError(data.message);
      }
    },
    onError: () => {
      setVerifyError("Erreur de connexion. Veuillez réessayer.");
    },
  });

  const openChatWithMessage = (msg: string) => {
    window.dispatchEvent(
      new CustomEvent("open-chat-with-message", { detail: { message: msg } })
    );
  };

  const handleSubscribe = (dur: PlanDuration) => {
    const stripeKey = packType === "golden" ? dur.stripeKeyGolden : dur.stripeKeyFull;
    const link = STRIPE_LINKS[stripeKey];
    if (link && !link.includes("PLACEHOLDER")) {
      window.open(link, "_blank");
    } else {
      openChatWithMessage(
        `Bonjour, je souhaite souscrire à l'abonnement ${packType === "golden" ? "Golden Pack" : "Full Pack"} ${dur.label}. Pouvez-vous m'aider ?`
      );
    }
  };

  const handleVerify = () => {
    if (!username.trim()) {
      setVerifyError("Veuillez entrer votre nom d'utilisateur.");
      return;
    }
    if (!password.trim()) {
      setVerifyError("Veuillez entrer votre mot de passe.");
      return;
    }
    setVerifyError("");
    setVerifyMessage("");
    verifyMutation.mutate({
      username: username.trim(),
      password: password.trim(),
    });
  };

  const handleRenewalPay = () => {
    window.open(STRIPE_LINKS["full_12m_renew"], "_blank");
    resetRenewalDialog();
  };

  const resetRenewalDialog = () => {
    setRenewalOpen(false);
    setUsername("");
    setPassword("");
    setVerified(false);
    setVerifyMessage("");
    setVerifyError("");
  };

  return (
    <>
      {/* Renewal Dialog */}
      <Dialog
        open={renewalOpen}
        onOpenChange={(open) => {
          if (!open) resetRenewalDialog();
          else setRenewalOpen(true);
        }}
      >
        <DialogContent className="max-w-[calc(100vw-2rem)] sm:max-w-md bg-[oklch(0.14_0.02_250/98%)] border-[oklch(0.30_0.04_250/40%)] text-white backdrop-blur-xl">
          <DialogHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div
                className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center bg-[oklch(0.55_0.18_240/15%)]"
                style={{
                  boxShadow: "0 0 25px oklch(0.65 0.18 240 / 30%)",
                }}
              >
                <UserCheck
                  size={28}
                  className="text-[oklch(0.72_0.15_210)]"
                />
              </div>
            </div>
            <DialogTitle className="text-lg sm:text-xl font-bold text-white text-center">
              Renouvellement Client
            </DialogTitle>
            <DialogDescription className="text-xs sm:text-sm text-[oklch(0.65_0.03_250)] text-center">
              Entrez vos identifiants IPTV pour vérifier votre compte et
              bénéficier du tarif renouvellement à{" "}
              <span className="text-[oklch(0.72_0.15_210)] font-bold">
                100€/an
              </span>{" "}
              au lieu de 149,99€.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 mt-4">
            {!verified ? (
              <>
                <div>
                  <label className="text-xs text-[oklch(0.55_0.03_250)] mb-1 block">
                    Nom d'utilisateur
                  </label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => {
                      setUsername(e.target.value);
                      setVerifyError("");
                    }}
                    placeholder="Votre nom d'utilisateur IPTV"
                    className="w-full px-3 sm:px-4 py-2.5 sm:py-3 rounded-xl text-sm bg-[oklch(0.10_0.015_250/80%)] border border-[oklch(0.30_0.04_250/40%)] text-white placeholder:text-[oklch(0.45_0.03_250)] focus:outline-none focus:border-[oklch(0.55_0.15_240/60%)] transition-colors"
                  />
                </div>
                <div>
                  <label className="text-xs text-[oklch(0.55_0.03_250)] mb-1 block">
                    Mot de passe
                  </label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setVerifyError("");
                    }}
                    onKeyDown={(e) => e.key === "Enter" && handleVerify()}
                    placeholder="Votre mot de passe IPTV"
                    className="w-full px-3 sm:px-4 py-2.5 sm:py-3 rounded-xl text-sm bg-[oklch(0.10_0.015_250/80%)] border border-[oklch(0.30_0.04_250/40%)] text-white placeholder:text-[oklch(0.45_0.03_250)] focus:outline-none focus:border-[oklch(0.55_0.15_240/60%)] transition-colors"
                  />
                </div>

                {verifyError && (
                  <div className="flex items-center gap-2 text-red-400 text-xs">
                    <XCircle size={14} />
                    {verifyError}
                  </div>
                )}

                <button
                  onClick={handleVerify}
                  disabled={verifyMutation.isPending}
                  className="w-full py-2.5 sm:py-3 rounded-xl font-semibold text-sm text-white bg-[oklch(0.55_0.18_240)] hover:bg-[oklch(0.60_0.20_240)] transition-all duration-300 flex items-center justify-center gap-2 glow-blue-hover disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {verifyMutation.isPending ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      Vérification en cours...
                    </>
                  ) : (
                    <>
                      <UserCheck size={16} />
                      Vérifier mon compte
                    </>
                  )}
                </button>

                <button
                  onClick={() => {
                    resetRenewalDialog();
                    window.open(STRIPE_LINKS["full_12m"], "_blank");
                  }}
                  className="w-full py-2 text-center text-xs text-[oklch(0.55_0.03_250)] hover:text-white transition-colors"
                >
                  Je suis nouveau client → 149,99€
                </button>
              </>
            ) : (
              <>
                <div className="flex items-center gap-3 p-3 sm:p-4 rounded-xl bg-[oklch(0.20_0.05_150/30%)] border border-[oklch(0.50_0.15_150/30%)]">
                  <CheckCircle2
                    size={22}
                    className="text-[oklch(0.70_0.15_150)] shrink-0"
                  />
                  <div>
                    <p className="text-sm font-semibold text-[oklch(0.85_0.10_150)]">
                      Compte vérifié !
                    </p>
                    <p className="text-xs text-[oklch(0.65_0.05_150)]">
                      {verifyMessage}
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleRenewalPay}
                  className="w-full py-2.5 sm:py-3 rounded-xl font-semibold text-sm text-white bg-[oklch(0.55_0.18_240)] hover:bg-[oklch(0.60_0.20_240)] transition-all duration-300 flex items-center justify-center gap-2 glow-blue-hover"
                >
                  <CreditCard size={16} />
                  Renouveler — 100€
                  <ExternalLink size={12} />
                </button>

                <p className="text-center text-[10px] text-[oklch(0.50_0.03_250)]">
                  Vous économisez 49,99€ par rapport au tarif nouveau client
                </p>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <section id="pricing" className="relative py-16 sm:py-24 overflow-hidden">
        {/* Background orbs */}
        <div className="absolute bottom-0 left-1/4 w-[600px] h-[600px] rounded-full bg-[oklch(0.55_0.18_240/5%)] blur-[150px] pointer-events-none" />
        <div className="absolute top-1/4 right-0 w-[400px] h-[400px] rounded-full bg-[oklch(0.72_0.12_210/4%)] blur-[100px] pointer-events-none" />

        <div className="container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-10 sm:mb-16"
          >
            <span className="inline-block px-4 py-1.5 rounded-full text-sm font-semibold tracking-wider uppercase text-[oklch(0.72_0.15_210)] bg-[oklch(0.65_0.18_240/10%)] neon-border mb-4">
              Nos Offres
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-3 sm:mb-4">
              Choisissez votre{" "}
              <span className="text-gradient-blue neon-text">abonnement IPTV</span>
            </h2>
            <p className="text-base sm:text-lg text-[oklch(0.65_0.03_250)] md:text-xl max-w-2xl mx-auto">
              Abonnement IPTV pas cher avec essai gratuit 48h. Le meilleur rapport qualité-prix pour votre IPTV en Guadeloupe, Martinique et DOM-TOM. Paiement sécurisé par carte bancaire.
            </p>
          </motion.div>

          {/* Pack Type Toggle */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4 }}
            className="flex justify-center mb-8 sm:mb-10"
          >
            <div className="inline-flex rounded-2xl p-1.5 bg-[oklch(0.12_0.015_250/80%)] border border-[oklch(0.25_0.03_250/40%)] backdrop-blur-md">
              <button
                onClick={() => setPackType("full")}
                className={`px-5 sm:px-8 py-2.5 sm:py-3 rounded-xl text-sm sm:text-base font-semibold transition-all duration-300 flex items-center gap-2 ${
                  packType === "full"
                    ? "bg-[oklch(0.55_0.18_240)] text-white shadow-lg"
                    : "text-[oklch(0.60_0.03_250)] hover:text-white"
                }`}
                style={packType === "full" ? { boxShadow: "0 0 20px oklch(0.55 0.18 240 / 40%)" } : {}}
              >
                <Crown size={16} />
                Full Pack
              </button>
              <button
                onClick={() => setPackType("golden")}
                className={`px-5 sm:px-8 py-2.5 sm:py-3 rounded-xl text-sm sm:text-base font-semibold transition-all duration-300 flex items-center gap-2 ${
                  packType === "golden"
                    ? "bg-gradient-to-r from-[oklch(0.65_0.18_80)] to-[oklch(0.55_0.18_50)] text-white shadow-lg"
                    : "text-[oklch(0.60_0.03_250)] hover:text-white"
                }`}
                style={packType === "golden" ? { boxShadow: "0 0 20px oklch(0.60 0.18 60 / 40%)" } : {}}
              >
                <Sparkles size={16} />
                Golden Pack
                <span className="text-[10px] opacity-80">(+18)</span>
              </button>
            </div>
          </motion.div>

          {/* Free trial card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4 }}
            className="max-w-md mx-auto mb-6 sm:mb-8"
          >
            <div className="glass-card rounded-2xl p-4 sm:p-5 flex items-center gap-4">
              <div
                className="w-11 h-11 rounded-xl flex items-center justify-center bg-[oklch(0.50_0.15_160/15%)] shrink-0"
                style={{ boxShadow: "0 0 15px oklch(0.50 0.15 160 / 30%)" }}
              >
                <Gift size={20} className="text-[oklch(0.70_0.15_160)]" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-white text-base">Essai gratuit 48h</h4>
                <p className="text-xs text-[oklch(0.60_0.03_250)]">
                  Testez notre service sans engagement, accès complet
                </p>
              </div>
              <button
                onClick={() =>
                  openChatWithMessage(
                    "Bonjour, je souhaite tester votre abonnement, puis-je avoir des identifiants gratuits pour 48h svp ?"
                  )
                }
                className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-[oklch(0.50_0.15_160)] hover:bg-[oklch(0.55_0.17_160)] transition-colors whitespace-nowrap"
              >
                Essai gratuit
              </button>
            </div>
          </motion.div>

          {/* Plans grid */}
          <AnimatePresence mode="wait">
            <motion.div
              key={packType}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 max-w-5xl mx-auto"
            >
              {durations.map((dur, i) => {
                const price = packType === "golden" ? dur.goldenPrice : dur.fullPrice;
                const perMonth = packType === "golden" ? dur.goldenPerMonth : dur.perMonth;
                const features = packType === "golden" ? dur.goldenFeatures : dur.features;
                const isGolden = packType === "golden";

                return (
                  <motion.div
                    key={dur.key}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: i * 0.08 }}
                    className={`relative glass-card rounded-2xl p-4 sm:p-5 flex flex-col ${
                      dur.popular
                        ? isGolden
                          ? "border-[oklch(0.65_0.18_60/50%)] sm:scale-[1.02] lg:scale-105 lg:z-10"
                          : "border-[oklch(0.65_0.18_240/40%)] sm:scale-[1.02] lg:scale-105 lg:z-10"
                        : ""
                    }`}
                  >
                    {dur.badge && (
                      <div
                        className={`absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-[10px] font-bold text-white whitespace-nowrap ${
                          dur.popular
                            ? isGolden
                              ? "bg-gradient-to-r from-[oklch(0.65_0.18_80)] to-[oklch(0.55_0.18_50)]"
                              : "bg-[oklch(0.55_0.18_240)] glow-blue"
                            : "bg-[oklch(0.45_0.12_210)]"
                        }`}
                      >
                        {dur.badge}
                      </div>
                    )}

                    <div className="space-y-2 mb-4">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                          isGolden
                            ? "bg-[oklch(0.60_0.18_60/15%)]"
                            : "bg-[oklch(0.55_0.18_240/15%)]"
                        }`}
                        style={{
                          boxShadow: isGolden
                            ? "0 0 15px oklch(0.60 0.18 60 / 30%)"
                            : "0 0 15px oklch(0.65 0.18 240 / 30%)",
                        }}
                      >
                        <dur.icon
                          size={18}
                          className={
                            isGolden
                              ? "text-[oklch(0.75_0.15_60)]"
                              : "text-[oklch(0.72_0.15_210)]"
                          }
                        />
                      </div>
                      <h3 className="text-lg sm:text-xl font-bold text-white">
                        {dur.label}
                      </h3>
                      <div>
                        <div className="flex items-baseline gap-1">
                          <span
                            className={`text-3xl sm:text-4xl font-bold text-white ${
                              isGolden ? "" : "neon-text"
                            }`}
                          >
                            {price}
                          </span>
                          <span className="text-[oklch(0.55_0.03_250)] text-xs">
                            {dur.period}
                          </span>
                        </div>
                        {perMonth && (
                          <p
                            className={`text-xs mt-1 ${
                              isGolden
                                ? "text-[oklch(0.70_0.12_60)]"
                                : "text-[oklch(0.72_0.15_210)]"
                            }`}
                          >
                            soit {perMonth}
                          </p>
                        )}
                        {dur.hasRenewal && packType === "full" && (
                          <button
                            onClick={() => setRenewalOpen(true)}
                            className="text-[10px] text-[oklch(0.72_0.15_210)] mt-1.5 underline underline-offset-2 hover:text-white transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <UserCheck size={10} />
                            Déjà client ? Renouvelez à {dur.renewalPrice}/an
                          </button>
                        )}
                      </div>
                    </div>

                    <ul className="space-y-1.5 mb-4 flex-1">
                      {features.map((feat) => (
                        <li key={feat} className="flex items-start gap-2">
                          <Check
                            size={13}
                            className={`mt-0.5 shrink-0 ${
                              feat.includes("adulte")
                                ? "text-[oklch(0.70_0.18_350)]"
                                : isGolden
                                ? "text-[oklch(0.75_0.15_60)]"
                                : "text-[oklch(0.72_0.15_210)]"
                            }`}
                          />
                          <span
                            className={`text-xs ${
                              feat.includes("adulte")
                                ? "text-[oklch(0.75_0.15_350)] font-semibold"
                                : "text-[oklch(0.75_0.03_250)]"
                            }`}
                          >
                            {feat}
                          </span>
                        </li>
                      ))}
                    </ul>

                    <button
                      onClick={() => handleSubscribe(dur)}
                      className={`w-full py-2.5 sm:py-3 rounded-xl font-semibold text-sm transition-all duration-300 flex items-center justify-center gap-2 ${
                        dur.popular
                          ? isGolden
                            ? "text-white bg-gradient-to-r from-[oklch(0.65_0.18_80)] to-[oklch(0.55_0.18_50)] hover:opacity-90"
                            : "text-white bg-[oklch(0.55_0.18_240)] hover:bg-[oklch(0.60_0.20_240)] glow-blue-hover"
                          : isGolden
                          ? "text-[oklch(0.80_0.12_60)] border border-[oklch(0.55_0.15_60/40%)] hover:bg-[oklch(0.20_0.05_60/30%)]"
                          : "text-[oklch(0.80_0.10_240)] border border-[oklch(0.50_0.15_240/40%)] hover:bg-[oklch(0.20_0.03_250/40%)]"
                      }`}
                    >
                      <CreditCard size={14} className="shrink-0" />
                      <span>Souscrire : {price}</span>
                      <ExternalLink size={12} className="shrink-0" />
                    </button>
                  </motion.div>
                );
              })}
            </motion.div>
          </AnimatePresence>

          {/* Trust badges */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="flex flex-col sm:flex-row flex-wrap justify-center gap-3 sm:gap-6 mt-8 sm:mt-12 text-xs sm:text-sm text-[oklch(0.55_0.03_250)]"
          >
            {[
              { icon: ShieldCheck, text: "Paiement sécurisé Stripe" },
              { icon: CreditCard, text: "Visa, Mastercard, Apple Pay" },
              { icon: Check, text: "Activation instantanée" },
            ].map((item) => (
              <div key={item.text} className="flex items-center justify-center gap-2">
                <item.icon
                  size={14}
                  className="text-[oklch(0.72_0.15_210)]"
                />
                {item.text}
              </div>
            ))}
          </motion.div>
        </div>
      </section>
    </>
  );
}
