import { describe, it, expect } from "vitest";

describe("Stripe Webhook Secret", () => {
  it("should have STRIPE_WHSEC environment variable set", () => {
    const secret = process.env.STRIPE_WHSEC;
    expect(secret).toBeDefined();
    expect(secret).not.toBe("");
    expect(secret?.startsWith("whsec_")).toBe(true);
  });
});
