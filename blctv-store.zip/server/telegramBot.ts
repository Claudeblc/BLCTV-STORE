/**
 * Telegram Bot — Interface cliquable pour la gestion des comptes IPTV
 * 
 * Commandes:
 * /start — Affiche le menu principal
 * /creer — Lance la création d'un compte
 * /aide — Affiche l'aide
 * 
 * Flow de création:
 * 1. Entrer le username
 * 2. Choisir la durée (48h gratuit, 1/3/6/12/24 mois)
 * 3. Choisir le nombre d'appareils (1 ou 2)
 * 4. Choisir l'option adulte (oui/non)
 * 5. Confirmation → Création automatique → Envoi des identifiants
 * 
 * Après création:
 * - Les identifiants sont affichés directement dans le chat Telegram
 * - Bouton "Copier les identifiants" pour copier facilement
 */
import { ENV } from "./_core/env";
import { createIPTVAccount, PACKAGES, type PackageKey } from "./iptvPanel";
// Email retiré — les identifiants sont envoyés directement via le chat Telegram

const BOT_TOKEN = ENV.telegramBotToken;
const ADMIN_CHAT_ID = ENV.telegramChatId;

/** Telegram API helper */
async function telegramAPI(method: string, body: Record<string, unknown>) {
  const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return res.json();
}

/** Send a message with optional inline keyboard */
export async function sendMessage(
  chatId: string | number,
  text: string,
  keyboard?: InlineKeyboard
) {
  return telegramAPI("sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    ...(keyboard ? { reply_markup: { inline_keyboard: keyboard } } : {}),
  });
}

/** Edit an existing message */
async function editMessage(
  chatId: string | number,
  messageId: number,
  text: string,
  keyboard?: InlineKeyboard
) {
  return telegramAPI("editMessageText", {
    chat_id: chatId,
    message_id: messageId,
    text,
    parse_mode: "HTML",
    ...(keyboard ? { reply_markup: { inline_keyboard: keyboard } } : {}),
  });
}

/** Answer callback query (removes loading spinner) */
async function answerCallback(callbackQueryId: string, text?: string) {
  return telegramAPI("answerCallbackQuery", {
    callback_query_id: callbackQueryId,
    text: text || "",
  });
}

type InlineKeyboard = Array<Array<{ text: string; callback_data: string }>>;

/** User session for account creation flow */
interface UserSession {
  step: "username" | "duration" | "devices" | "adult" | "confirm";
  username: string;
  duration: string;
  devices: number;
  adult: boolean;
  packageKey?: PackageKey;
  // After account creation, store credentials for sending
  createdCredentials?: {
    username: string;
    password: string;
    packageLabel: string;
    connections: number;
    expireDate?: string;
  };
}

// In-memory sessions (per chat)
const sessions = new Map<string, UserSession>();

// Store credentials waiting to be sent (keyed by a unique ID)
const pendingCredentials = new Map<string, {
  username: string;
  password: string;
  packageLabel: string;
  connections: number;
  expireDate?: string;
  chatSessionId?: string;
}>();

/** Handle incoming Telegram updates. Returns true if the bot handled the message (creation flow, commands, etc.) */
export async function handleTelegramUpdate(update: any): Promise<boolean> {
  // Handle callback queries (button clicks)
  if (update.callback_query) {
    await handleCallbackQuery(update.callback_query);
    return true;
  }

  // Handle text messages
  const message = update.message;
  if (!message?.text) return false;

  const chatId = String(message.chat.id);
  const text = message.text.trim();

  // Only respond to admin
  if (chatId !== ADMIN_CHAT_ID) return false;

  // Handle commands
  if (text === "/start" || text === "/menu") {
    await showMainMenu(chatId);
    return true;
  }

  if (text === "/creer" || text === "/create") {
    await startCreateFlow(chatId);
    return true;
  }

  if (text === "/aide" || text === "/help") {
    await sendMessage(
      chatId,
      "🤖 <b>Bot BLCTV Store</b>\n\n" +
        "Commandes disponibles:\n" +
        "• /start — Menu principal\n" +
        "• /creer — Créer un compte IPTV\n" +
        "• /aide — Afficher cette aide\n\n" +
        "Vous pouvez aussi utiliser les boutons du menu."
    );
    return true;
  }

  // Check if we're waiting for username input
  const session = sessions.get(chatId);
  if (session && session.step === "username") {
    session.username = text;
    session.step = "duration";
    await showDurationChoice(chatId);
    return true;
  }



  // If it's a reply to a visitor message, don't process as bot command
  if (message.reply_to_message) return false;

  // Message not handled by bot
  return false;
}

/** Show the main menu */
async function showMainMenu(chatId: string) {
  await sendMessage(
    chatId,
    "🏠 <b>Menu Principal — BLCTV Store</b>\n\n" +
      "Que souhaitez-vous faire ?",
    [
      [{ text: "➕ Créer un compte", callback_data: "create_start" }],
      [{ text: "📊 Voir les crédits", callback_data: "check_credits" }],
      [{ text: "ℹ️ Aide", callback_data: "help" }],
    ]
  );
}

/** Start the account creation flow */
async function startCreateFlow(chatId: string) {
  sessions.set(chatId, {
    step: "username",
    username: "",
    duration: "12m",
    devices: 1,
    adult: false,
  });

  await sendMessage(
    chatId,
    "➕ <b>Création de compte IPTV</b>\n\n" +
      "📝 <b>Étape 1/4:</b> Entrez le <b>nom d'utilisateur</b> pour le client.\n\n" +
      "<i>Tapez le username ci-dessous ou cliquez sur le bouton pour en générer un automatiquement.</i>",
    [
      [{ text: "🎲 Générer automatiquement", callback_data: "username_auto" }],
      [{ text: "❌ Annuler", callback_data: "cancel" }],
    ]
  );
}

/** Show duration choice */
async function showDurationChoice(chatId: string) {
  const session = sessions.get(chatId);
  if (!session) return;

  const usernameDisplay = session.username || "Auto-généré";

  await sendMessage(
    chatId,
    `➕ <b>Création de compte IPTV</b>\n\n` +
      `👤 Username: <code>${usernameDisplay}</code>\n\n` +
      `📝 <b>Étape 2/4:</b> Choisissez la <b>durée</b> de l'abonnement:`,
    [
      [
        { text: "48h gratuit (test)", callback_data: "dur_48h" },
        { text: "1 mois", callback_data: "dur_1m" },
      ],
      [
        { text: "3 mois", callback_data: "dur_3m" },
        { text: "6 mois", callback_data: "dur_6m" },
      ],
      [
        { text: "⭐ 12 mois (1 an)", callback_data: "dur_12m" },
        { text: "24 mois (2 ans)", callback_data: "dur_24m" },
      ],
      [{ text: "❌ Annuler", callback_data: "cancel" }],
    ]
  );
}

/** Show device count choice */
async function showDeviceChoice(chatId: string) {
  const session = sessions.get(chatId);
  if (!session) return;

  const usernameDisplay = session.username || "Auto-généré";
  const durationLabels: Record<string, string> = {
    "48h": "48h gratuit",
    "1m": "1 mois",
    "3m": "3 mois",
    "6m": "6 mois",
    "12m": "12 mois",
    "24m": "24 mois",
  };

  await sendMessage(
    chatId,
    `➕ <b>Création de compte IPTV</b>\n\n` +
      `👤 Username: <code>${usernameDisplay}</code>\n` +
      `⏱ Durée: ${durationLabels[session.duration] || session.duration}\n\n` +
      `📝 <b>Étape 3/4:</b> Nombre d'<b>appareils</b> simultanés:`,
    [
      [
        { text: "📱 1 appareil", callback_data: "dev_1" },
        { text: "📱📱 2 appareils", callback_data: "dev_2" },
      ],
      [{ text: "❌ Annuler", callback_data: "cancel" }],
    ]
  );
}

/** Show adult option choice */
async function showAdultChoice(chatId: string) {
  const session = sessions.get(chatId);
  if (!session) return;

  const usernameDisplay = session.username || "Auto-généré";
  const durationLabels: Record<string, string> = {
    "48h": "48h gratuit",
    "1m": "1 mois",
    "3m": "3 mois",
    "6m": "6 mois",
    "12m": "12 mois",
    "24m": "24 mois",
  };

  await sendMessage(
    chatId,
    `➕ <b>Création de compte IPTV</b>\n\n` +
      `👤 Username: <code>${usernameDisplay}</code>\n` +
      `⏱ Durée: ${durationLabels[session.duration] || session.duration}\n` +
      `📱 Appareils: ${session.devices}\n\n` +
      `📝 <b>Étape 4/4:</b> Choisissez le <b>type de pack</b>:\n\n` +
      `👑 <b>Full Pack</b> — Sans chaînes adultes\n` +
      `✨ <b>Golden Pack</b> — Avec chaînes adultes (+18)`,
    [
      [
        { text: "✨ Golden Pack (+18)", callback_data: "adult_yes" },
        { text: "👑 Full Pack", callback_data: "adult_no" },
      ],
      [{ text: "❌ Annuler", callback_data: "cancel" }],
    ]
  );
}

/** Show confirmation before creating */
async function showConfirmation(chatId: string) {
  const session = sessions.get(chatId);
  if (!session) return;

  const usernameDisplay = session.username || "Auto-généré";
  const durationLabels: Record<string, string> = {
    "48h": "48h gratuit",
    "1m": "1 mois",
    "3m": "3 mois",
    "6m": "6 mois",
    "12m": "12 mois",
    "24m": "24 mois",
  };

  // Determine the package key
  // If adult is selected, use Golden Pack (includes adult channels)
  // Otherwise use Full Pack
  let packageKey: PackageKey;
  if (session.adult) {
    packageKey = `golden_${session.duration}` as PackageKey;
  } else if (session.devices === 2) {
    packageKey = `full2_${session.duration}` as PackageKey;
  } else {
    packageKey = `full_${session.duration}` as PackageKey;
  }
  session.packageKey = packageKey;

  const pkg = PACKAGES[packageKey];
  if (!pkg) {
    await sendMessage(chatId, `❌ Package non disponible pour cette combinaison (${packageKey}). Veuillez réessayer.`);
    sessions.delete(chatId);
    return;
  }

  await sendMessage(
    chatId,
    `✅ <b>Confirmation de création</b>\n\n` +
      `👤 Username: <code>${usernameDisplay}</code>\n` +
      `⏱ Durée: ${durationLabels[session.duration] || session.duration}\n` +
      `📱 Appareils: ${session.devices}\n` +
      `🔞 Pack: ${session.adult ? "✨ Golden Pack (+18)" : "👑 Full Pack"}\n` +
      `📦 Package: ${pkg.label}\n\n` +
      `<b>Confirmer la création ?</b>`,
    [
      [{ text: "✅ Confirmer et créer", callback_data: "confirm_create" }],
      [{ text: "🔄 Recommencer", callback_data: "create_start" }],
      [{ text: "❌ Annuler", callback_data: "cancel" }],
    ]
  );
}



/** Handle callback queries (button clicks) */
async function handleCallbackQuery(query: any) {
  const chatId = String(query.message.chat.id);
  const messageId = query.message.message_id;
  const data = query.data;

  // Only respond to admin
  if (chatId !== ADMIN_CHAT_ID) {
    await answerCallback(query.id, "Non autorisé");
    return;
  }

  await answerCallback(query.id);

  // Main menu actions
  if (data === "create_start") {
    sessions.set(chatId, {
      step: "username",
      username: "",
      duration: "12m",
      devices: 1,
      adult: false,
    });
    await sendMessage(
      chatId,
      "➕ <b>Création de compte IPTV</b>\n\n" +
        "📝 <b>Étape 1/4:</b> Entrez le <b>nom d'utilisateur</b> pour le client.\n\n" +
        "<i>Tapez le username ci-dessous ou cliquez sur le bouton pour en générer un automatiquement.</i>",
      [
        [{ text: "🎲 Générer automatiquement", callback_data: "username_auto" }],
        [{ text: "❌ Annuler", callback_data: "cancel" }],
      ]
    );
    return;
  }

  if (data === "check_credits") {
    await sendMessage(chatId, "📊 Vérification des crédits en cours...");
    await sendMessage(
      chatId,
      "📊 <b>Crédits disponibles</b>\n\nConsultez votre panel pour le solde exact:\n" +
        `<a href="${ENV.iptvPanelUrl}">Ouvrir le panel</a>`,
      [[{ text: "🏠 Menu principal", callback_data: "main_menu" }]]
    );
    return;
  }

  if (data === "help") {
    await sendMessage(
      chatId,
      "🤖 <b>Bot BLCTV Store</b>\n\n" +
        "Ce bot vous permet de:\n" +
        "• ➕ Créer des comptes IPTV (Full Pack ou Golden Pack)\n" +
        "• 📊 Vérifier vos crédits\n" +
        "• 💬 Recevoir les messages des clients\n\n" +
        "Pour créer un compte, suivez les étapes:\n" +
        "1. Entrez le username\n" +
        "2. Choisissez la durée (48h, 1/3/6/12/24 mois)\n" +
        "3. Choisissez le nombre d'appareils\n" +
        "4. Full Pack ou Golden Pack (adulte)\n" +
        "5. Confirmez et copiez les identifiants !",
      [[{ text: "🏠 Menu principal", callback_data: "main_menu" }]]
    );
    return;
  }

  if (data === "main_menu") {
    await showMainMenu(chatId);
    return;
  }

  if (data === "cancel") {
    sessions.delete(chatId);
    await sendMessage(
      chatId,
      "❌ Création annulée.",
      [[{ text: "🏠 Menu principal", callback_data: "main_menu" }]]
    );
    return;
  }

  // Username auto-generate
  if (data === "username_auto") {
    const session = sessions.get(chatId);
    if (!session) return;
    session.username = ""; // Empty = panel auto-generates
    session.step = "duration";
    await showDurationChoice(chatId);
    return;
  }

  // Duration selection
  if (data.startsWith("dur_")) {
    const session = sessions.get(chatId);
    if (!session) return;
    session.duration = data.replace("dur_", "");
    session.step = "devices";
    await showDeviceChoice(chatId);
    return;
  }

  // Device count selection
  if (data.startsWith("dev_")) {
    const session = sessions.get(chatId);
    if (!session) return;
    session.devices = parseInt(data.replace("dev_", ""));
    session.step = "adult";
    await showAdultChoice(chatId);
    return;
  }

  // Adult option
  if (data === "adult_yes" || data === "adult_no") {
    const session = sessions.get(chatId);
    if (!session) return;
    session.adult = data === "adult_yes";
    session.step = "confirm";
    await showConfirmation(chatId);
    return;
  }

  // Confirm and create
  if (data === "confirm_create") {
    const session = sessions.get(chatId);
    if (!session || !session.packageKey) return;

    await sendMessage(chatId, "⏳ <b>Création du compte en cours...</b>\n\nVeuillez patienter...");

    const result = await createIPTVAccount({
      username: session.username || undefined,
      packageKey: session.packageKey,
      maxConnections: session.devices,
      description: `Bot Telegram - ${new Date().toLocaleDateString("fr-FR")}`,
    });

    if (result.success) {
      // Store credentials in session for sending later
      session.createdCredentials = {
        username: result.username!,
        password: result.password!,
        packageLabel: result.packageLabel!,
        connections: result.connections!,
        expireDate: result.expireDate,
      };

      let successMsg =
        `✅ <b>Compte créé avec succès !</b>\n\n` +
        `👤 <b>Username:</b> <code>${result.username}</code>\n` +
        `🔑 <b>Password:</b> <code>${result.password}</code>\n` +
        `📦 <b>Package:</b> ${result.packageLabel}\n` +
        `📱 <b>Connexions:</b> ${result.connections}\n\n` +
        `🌐 <b>URL serveur:</b> <code>http://ipro2.pro2-ott.com:80</code>\n`;

      // Golden Pack already includes adult channels, no need for separate ABDO package
      if (session.adult) {
        successMsg += "\n🔞 <b>Chaînes adultes incluses (Golden Pack)</b>";
      }

      successMsg += "\n\n<i>Copiez les identifiants ci-dessus et envoyez-les au client via le chat.</i>";

      await sendMessage(chatId, successMsg, [
        [{ text: "📋 Copier les identifiants", callback_data: "copy_credentials" }],
        [{ text: "➕ Créer un autre compte", callback_data: "create_start" }],
        [{ text: "🏠 Menu principal", callback_data: "main_menu" }],
      ]);
    } else {
      await sendMessage(
        chatId,
        `❌ <b>Erreur de création</b>\n\n${result.error}`,
        [
          [{ text: "🔄 Réessayer", callback_data: "confirm_create" }],
          [{ text: "🏠 Menu principal", callback_data: "main_menu" }],
        ]
      );
      sessions.delete(chatId);
    }

    return;
  }

  // Copy credentials — send a clean text block that's easy to copy-paste
  if (data === "copy_credentials") {
    const session = sessions.get(chatId);
    if (!session?.createdCredentials) {
      await sendMessage(chatId, "❌ Aucun identifiant en attente. Créez d'abord un compte.", [
        [{ text: "➕ Créer un compte", callback_data: "create_start" }],
      ]);
      return;
    }

    const creds = session.createdCredentials;
    const copyText =
      `🔐 Vos identifiants BLCTV Store\n\n` +
      `👤 Username: ${creds.username}\n` +
      `🔑 Password: ${creds.password}\n` +
      `🌐 URL: http://ipro2.pro2-ott.com:80\n` +
      `📦 Package: ${creds.packageLabel}\n` +
      `📱 Connexions: ${creds.connections}\n` +
      (creds.expireDate ? `📅 Expiration: ${creds.expireDate}\n` : "") +
      `\n📥 Téléchargez l'app: https://blctvshop.vip/#application`;

    await sendMessage(chatId, copyText, [
      [{ text: "➕ Créer un autre compte", callback_data: "create_start" }],
      [{ text: "🏠 Menu principal", callback_data: "main_menu" }],
    ]);
    return;
  }

  // Handle send_credentials from Stripe payment notification
  if (data.startsWith("send_creds_stripe_")) {
    // Extract payment info and start create flow
    sessions.set(chatId, {
      step: "username",
      username: "",
      duration: "12m",
      devices: 1,
      adult: false,
    });
    await sendMessage(
      chatId,
      "➕ <b>Création de compte pour le client</b>\n\n" +
        "📝 <b>Étape 1/4:</b> Entrez le <b>nom d'utilisateur</b> pour le client.\n\n" +
        "<i>Tapez le username ci-dessous ou cliquez sur le bouton pour en générer un automatiquement.</i>",
      [
        [{ text: "🎲 Générer automatiquement", callback_data: "username_auto" }],
        [{ text: "❌ Annuler", callback_data: "cancel" }],
      ]
    );
    return;
  }
}
