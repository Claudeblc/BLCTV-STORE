import { describe, it, expect } from "vitest";
import { PACKAGES } from "./iptvPanel";

describe("IPTV Panel Module", () => {
  it("should have all expected package keys", () => {
    expect(PACKAGES.full_12m).toBeDefined();
    expect(PACKAGES.full_12m.id).toBe("685");
    expect(PACKAGES.full_24m).toBeDefined();
    expect(PACKAGES.full_24m.id).toBe("825");
    expect(PACKAGES.full_1w).toBeDefined();
    expect(PACKAGES.full_1w.id).toBe("834");
  });

  it("should have correct connection counts", () => {
    expect(PACKAGES.full_12m.connections).toBe(1);
    expect(PACKAGES.full2_12m.connections).toBe(2);
    expect(PACKAGES.full2_6m.connections).toBe(2);
  });

  it("should have adult packages", () => {
    expect(PACKAGES.abdo_12m).toBeDefined();
    expect(PACKAGES.abdo_12m.id).toBe("836");
    expect(PACKAGES.abdo_6m).toBeDefined();
    expect(PACKAGES.abdo_3m).toBeDefined();
    expect(PACKAGES.abdo_1m).toBeDefined();
  });

  it("should have golden packages", () => {
    expect(PACKAGES.golden_12m).toBeDefined();
    expect(PACKAGES.golden_12m.id).toBe("815");
    expect(PACKAGES.golden_6m).toBeDefined();
    expect(PACKAGES.golden_3m).toBeDefined();
    expect(PACKAGES.golden_1m).toBeDefined();
  });

  it("should have 2-connection packages for all durations", () => {
    expect(PACKAGES.full2_1m).toBeDefined();
    expect(PACKAGES.full2_3m).toBeDefined();
    expect(PACKAGES.full2_6m).toBeDefined();
    expect(PACKAGES.full2_12m).toBeDefined();
  });
});

describe("Telegram Bot Configuration", () => {
  it("should have bot token configured", () => {
    expect(process.env.TELEGRAM_BOT_TOKEN).toBeTruthy();
  });

  it("should have chat ID configured", () => {
    expect(process.env.TELEGRAM_CHAT_ID).toBeTruthy();
  });

  it("should have IPTV panel credentials configured", () => {
    expect(process.env.IPTV_PANEL_URL).toBeTruthy();
    expect(process.env.IPTV_PANEL_USERNAME).toBeTruthy();
    expect(process.env.IPTV_PANEL_PASSWORD).toBeTruthy();
  });
});
