import { describe, it, expect } from "vitest";

const BASE = "http://localhost:3000";

describe("Stripe Webhook", () => {
  it("should accept a valid checkout.session.completed event", async () => {
    const res = await fetch(`${BASE}/api/stripe-webhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        type: "checkout.session.completed",
        data: {
          object: {
            id: "cs_test_vitest",
            amount_total: 15000,
            currency: "eur",
            payment_status: "paid",
            payment_intent: "pi_test_vitest",
            customer_details: {
              name: "Vitest User",
              email: "vitest@test.com",
            },
          },
        },
      }),
    });
    expect(res.status).toBe(200);
    const data = await res.json();
    expect(data.received).toBe(true);
  });

  it("should handle payment_intent.succeeded event", async () => {
    const res = await fetch(`${BASE}/api/stripe-webhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        type: "payment_intent.succeeded",
        data: {
          object: {
            id: "pi_test_vitest2",
            amount: 10000,
            currency: "eur",
            status: "succeeded",
          },
        },
      }),
    });
    expect(res.status).toBe(200);
    const data = await res.json();
    expect(data.received).toBe(true);
  });

  it("should handle unknown event types gracefully", async () => {
    const res = await fetch(`${BASE}/api/stripe-webhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        type: "customer.created",
        data: { object: { id: "cus_test" } },
      }),
    });
    expect(res.status).toBe(200);
    const data = await res.json();
    expect(data.received).toBe(true);
  });

  it("should correctly identify product from amount", async () => {
    // Test 1€
    const res1 = await fetch(`${BASE}/api/stripe-webhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        type: "checkout.session.completed",
        data: {
          object: {
            id: "cs_test_1eur",
            amount_total: 100,
            currency: "eur",
            payment_status: "paid",
            payment_intent: "pi_1eur",
            customer_details: { name: "Test 1€", email: "test1@test.com" },
          },
        },
      }),
    });
    expect(res1.status).toBe(200);

    // Test 200€
    const res200 = await fetch(`${BASE}/api/stripe-webhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        type: "checkout.session.completed",
        data: {
          object: {
            id: "cs_test_200eur",
            amount_total: 20000,
            currency: "eur",
            payment_status: "paid",
            payment_intent: "pi_200eur",
            customer_details: { name: "Test 200€", email: "test200@test.com" },
          },
        },
      }),
    });
    expect(res200.status).toBe(200);
  });
});
