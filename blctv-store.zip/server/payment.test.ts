import { describe, it, expect, vi } from "vitest";

describe("Payment routes", () => {
  it("should have NOWPAYMENTS_API_KEY set", () => {
    const key = process.env.NOWPAYMENTS_API_KEY;
    expect(key).toBeDefined();
    expect(key).not.toBe("");
  });

  it("should create an invoice via NowPayments API", async () => {
    const key = process.env.NOWPAYMENTS_API_KEY;
    const response = await fetch("https://api.nowpayments.io/v1/invoice", {
      method: "POST",
      headers: {
        "x-api-key": key!,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        price_amount: 6,
        price_currency: "eur",
        order_id: `test-vitest-${Date.now()}`,
        order_description: "BLCTV Store — Test vitest",
        success_url: "https://example.com/success",
        cancel_url: "https://example.com/cancel",
      }),
    });

    const data = await response.json();
    expect(data.id).toBeDefined();
    expect(data.invoice_url).toBeDefined();
    expect(data.invoice_url).toContain("nowpayments.io");
  });

  it("should return correct plan definitions", () => {
    const PLANS: Record<string, { name: string; amount: number }> = {
      test6: { name: "Test 7 jours", amount: 6 },
      "12mois_new": { name: "Abonnement 12 Mois", amount: 150 },
      "12mois_renew": { name: "Renouvellement 12 Mois", amount: 100 },
      "24mois": { name: "Abonnement 24 Mois", amount: 200 },
      adultes: { name: "Option Chaînes Adultes", amount: 50 },
    };

    expect(PLANS.test6.amount).toBe(6);
    expect(PLANS["12mois_new"].amount).toBe(150);
    expect(PLANS["12mois_renew"].amount).toBe(100);
    expect(PLANS["24mois"].amount).toBe(200);
    expect(PLANS.adultes.amount).toBe(50);
  });

  it("should check NowPayments API status", async () => {
    const key = process.env.NOWPAYMENTS_API_KEY;
    const response = await fetch("https://api.nowpayments.io/v1/status", {
      headers: { "x-api-key": key! },
    });
    const data = await response.json();
    expect(data.message).toBe("OK");
  });
});
