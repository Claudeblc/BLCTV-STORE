import { describe, it, expect } from "vitest";

describe("Downloader Code System", () => {
  const BASE_URL = "http://localhost:3000";

  it("should redirect to Android TV APK for code 853291", async () => {
    const res = await fetch(`${BASE_URL}/dl/853291`, { redirect: "manual" });
    expect(res.status).toBe(302);
    const location = res.headers.get("location");
    expect(location).toContain("BLC-TV-Player-AndroidTV");
  });

  it("should redirect to Mobile APK for code 427156", async () => {
    const res = await fetch(`${BASE_URL}/dl/427156`, { redirect: "manual" });
    expect(res.status).toBe(302);
    const location = res.headers.get("location");
    expect(location).toContain("BLC-TV-Player-Mobile");
  });

  it("should return 404 for invalid code", async () => {
    const res = await fetch(`${BASE_URL}/dl/000000`);
    expect(res.status).toBe(404);
  });
});
