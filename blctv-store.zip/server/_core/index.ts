import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { handleTelegramUpdate, sendMessage } from "../telegramBot";
import { lastActiveVisitorSession } from "../routers";
import Stripe from "stripe";
import { ENV } from "./env";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Stripe webhook needs raw body — MUST be registered BEFORE json parser
  app.post("/api/stripe-webhook", express.raw({ type: "application/json" }), async (req, res) => {
    try {
      const sig = req.headers["stripe-signature"] as string;
      const webhookSecret = ENV.stripeWebhookSecret;

      let event: Stripe.Event;

      if (webhookSecret && sig) {
        // Verify signature with Stripe
        const stripe = new Stripe(webhookSecret); // We only need it for webhook verification
        try {
          event = Stripe.webhooks.constructEvent(
            req.body,
            sig,
            webhookSecret
          ) as Stripe.Event;
          console.log("[Stripe Webhook] Signature verified successfully");
        } catch (err: any) {
          console.error("[Stripe Webhook] Signature verification failed:", err.message);
          return res.status(400).json({ error: "Invalid signature" });
        }
      } else {
        // Fallback: parse without verification (dev mode)
        event = typeof req.body === "string" ? JSON.parse(req.body) : JSON.parse(req.body.toString());
        console.log("[Stripe Webhook] No signature verification (dev mode)");
      }

      console.log("[Stripe Webhook] Event received:", event.type);

      // Handle checkout.session.completed (payment successful)
      if (event.type === "checkout.session.completed" || event.type === "payment_intent.succeeded") {
        const session = event.data?.object as any;
        const amount = session.amount_total
          ? (session.amount_total / 100).toFixed(2)
          : session.amount
            ? (session.amount / 100).toFixed(2)
            : "?";
        const currency = (session.currency || "eur").toUpperCase();
        const email = session.customer_details?.email || session.customer_email || "Non renseigné";
        const name = session.customer_details?.name || "Non renseigné";
        const paymentStatus = session.payment_status || session.status || "completed";
        const paymentId = session.payment_intent || session.id || "N/A";

        // Determine product from amount
        let product = "Inconnu";
        const amountNum = parseFloat(amount);
        if (amountNum === 1) product = "🧪 Test 1€";
        else if (amountNum === 100) product = "🔄 Renouvellement 1 an";
        else if (amountNum === 150) product = "⭐ Abonnement 1 an";
        else if (amountNum === 200) product = "👑 Abonnement 2 ans + Assistance";
        else product = `Paiement ${amount}${currency}`;

        const telegramMsg =
          `💰 <b>NOUVEAU PAIEMENT STRIPE !</b>\n\n` +
          `📦 <b>Produit:</b> ${product}\n` +
          `💶 <b>Montant:</b> ${amount} ${currency}\n` +
          `👤 <b>Client:</b> ${name}\n` +
          `📧 <b>Email:</b> ${email}\n` +
          `✅ <b>Statut:</b> ${paymentStatus}\n` +
          `🔑 <b>ID:</b> <code>${paymentId}</code>\n\n` +
          `<i>Créez le compte IPTV puis envoyez les identifiants au client !</i>`;

        // Send Telegram notification with create account button
        const BOT_TOKEN = ENV.telegramBotToken;
        const CHAT_ID = ENV.telegramChatId;
        if (BOT_TOKEN && CHAT_ID) {
          await sendMessage(CHAT_ID, telegramMsg, [
            [{ text: "➕ Créer le compte IPTV", callback_data: "create_start" }],
          ]);
          console.log("[Stripe Webhook] Telegram notification sent");
        }
      }

      res.json({ received: true });
    } catch (err) {
      console.error("[Stripe Webhook] Error:", err);
      res.status(400).json({ error: "Webhook error" });
    }
  });

  // Downloader code redirect — /dl/:code redirects to APK download
  const DOWNLOADER_CODES: Record<string, { url: string; name: string }> = {
    "853291": {
      url: "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/BLC-TV-Player-AndroidTV-v16_7c565be0.bin",
      name: "BLC-TV-Player-AndroidTV.apk",
    },
    "427156": {
      url: "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/BLC-TV-Player-Mobile_5a3cfc6a.bin",
      name: "BLC-TV-Player-Mobile.apk",
    },
  };

  app.get("/dl/:code", (req, res) => {
    const code = req.params.code;
    const entry = DOWNLOADER_CODES[code];
    if (entry) {
      console.log(`[Downloader] Code ${code} -> Redirecting to ${entry.name}`);
      return res.redirect(302, entry.url);
    }
    console.log(`[Downloader] Invalid code: ${code}`);
    res.status(404).send("Code invalide. Verifiez votre code a 6 chiffres.");
  });

  // APK download proxy — serves CDN files with correct .apk filename and content-type
  const APK_FILES: Record<string, { cdnUrl: string; filename: string }> = {
    mobile: {
      cdnUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/BLC-TV-Player-Mobile_5a3cfc6a.bin",
      filename: "BLC-TV-Player-Mobile.apk",
    },
    tv: {
      cdnUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663338588002/jRNjUovY5pthEcHP2wipri/BLC-TV-Player-AndroidTV-v16_7c565be0.bin",
      filename: "BLC-TV-Player-AndroidTV.apk",
    },
  };

  app.get("/api/download/:type", async (req, res) => {
    const apk = APK_FILES[req.params.type];
    if (!apk) return res.status(404).send("Fichier non trouvé");
    try {
      const response = await fetch(apk.cdnUrl);
      if (!response.ok) throw new Error(`CDN returned ${response.status}`);
      res.setHeader("Content-Type", "application/vnd.android.package-archive");
      res.setHeader("Content-Disposition", `attachment; filename="${apk.filename}"`);
      const contentLength = response.headers.get("content-length");
      if (contentLength) res.setHeader("Content-Length", contentLength);
      const reader = response.body?.getReader();
      if (!reader) throw new Error("No body");
      const pump = async () => {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          res.write(Buffer.from(value));
        }
        res.end();
      };
      await pump();
    } catch (err) {
      console.error("[APK Download] Error:", err);
      // Fallback: redirect to CDN
      res.redirect(302, apk.cdnUrl);
    }
  });

  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // OAuth callback under /api/oauth/callback
  registerOAuthRoutes(app);

  // Telegram webhook — handles both bot commands and chat replies
  app.post("/api/telegram-webhook", async (req, res) => {
    try {
      const update = req.body;
      console.log("[Telegram Webhook] Received update:", JSON.stringify(update).slice(0, 500));

      // First, try to handle as bot command/callback (account creation flow)
      const message = update?.message;
      const callbackQuery = update?.callback_query;

      // Handle callback queries (inline button clicks) — always goes to bot
      if (callbackQuery) {
        await handleTelegramUpdate(update);
        return res.json({ ok: true });
      }

      // Handle text messages
      if (message?.text) {
        const text = message.text.trim();

        // Bot commands always go to the bot handler
        if (text.startsWith("/")) {
          await handleTelegramUpdate(update);
          return res.json({ ok: true });
        }

        // Helper to save admin reply to a chat session
        const saveAdminReply = async (sessionId: string, replyText: string) => {
          const { createChatMessage } = await import("../db");
          await createChatMessage({
            sessionId,
            message: replyText,
            isFromVisitor: false,
            visitorName: "Support BLCTV",
          });
          console.log(`[Telegram Webhook] Admin reply saved for session ${sessionId}`);

          // Confirm to admin that the message was sent
          await sendMessage(
            String(message.chat.id),
            `✅ Message envoyé au client (session: ${sessionId.slice(0, 8)}...)`,
          );
        };

        // Check if it's a reply to a visitor message (chat) or a bot interaction
        const replyTo = message.reply_to_message;
        if (replyTo) {
          // Check if it's a reply to a chat message (contains Session: ID)
          const originalText = (replyTo.text || "") + " " + (replyTo.caption || "");
          const sessionMatch = originalText.match(/Session:\s*([a-zA-Z0-9_-]+)/);

          if (sessionMatch) {
            const sessionId = sessionMatch[1];
            await saveAdminReply(sessionId, message.text);
            return res.json({ ok: true });
          }
        }

        // Check if bot is in a creation/email flow — pass to bot handler
        const botHandled = await handleTelegramUpdate(update);
        if (botHandled) {
          return res.json({ ok: true });
        }

        // Not a bot command and not a reply — try to send to last active visitor session
        if (lastActiveVisitorSession) {
          const ageMinutes = (Date.now() - lastActiveVisitorSession.timestamp) / 60000;
          if (ageMinutes < 120) {
            // Session is less than 2 hours old — send reply there
            await saveAdminReply(lastActiveVisitorSession.sessionId, message.text);
            return res.json({ ok: true });
          } else {
            // Session too old
            await sendMessage(
              String(message.chat.id),
              "⚠️ La dernière conversation client date de plus de 2h. Répondez directement au message du client (swipe à droite) pour cibler la bonne conversation.",
            );
          }
        } else {
          await sendMessage(
            String(message.chat.id),
            "⚠️ Aucune conversation client active. Attendez qu'un client écrive, ou répondez directement à son message (swipe à droite).",
          );
        }

        return res.json({ ok: true });
      }

      res.json({ ok: true });
    } catch (err) {
      console.error("[Telegram Webhook] Error:", err);
      res.json({ ok: true });
    }
  });

  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
