import { describe, it, expect } from "vitest";

describe("NowPayments API key validation", () => {
  it("should have NOWPAYMENTS_API_KEY set", () => {
    const key = process.env.NOWPAYMENTS_API_KEY;
    expect(key).toBeDefined();
    expect(key).not.toBe("");
  });

  it("should successfully connect to NowPayments API", async () => {
    const key = process.env.NOWPAYMENTS_API_KEY;
    const response = await fetch("https://api.nowpayments.io/v1/status", {
      headers: { "x-api-key": key! },
    });
    const data = await response.json();
    expect(data.message).toBe("OK");
  });

  it("should be able to list currencies", async () => {
    const key = process.env.NOWPAYMENTS_API_KEY;
    const response = await fetch("https://api.nowpayments.io/v1/currencies", {
      headers: { "x-api-key": key! },
    });
    const data = await response.json();
    expect(data.currencies).toBeDefined();
    expect(data.currencies.length).toBeGreaterThan(0);
  });
});
