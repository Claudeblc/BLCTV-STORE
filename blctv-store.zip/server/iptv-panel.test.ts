import { describe, it, expect } from "vitest";

const PANEL_URL = process.env.IPTV_PANEL_URL || "";
const PANEL_USERNAME = process.env.IPTV_PANEL_USERNAME || "";
const PANEL_PASSWORD = process.env.IPTV_PANEL_PASSWORD || "";

describe("IPTV Panel Credentials", () => {
  it("should have panel URL configured", () => {
    expect(PANEL_URL).toBeTruthy();
    expect(PANEL_URL).toContain("https://");
  });

  it("should have panel username configured", () => {
    expect(PANEL_USERNAME).toBeTruthy();
  });

  it("should have panel password configured", () => {
    expect(PANEL_PASSWORD).toBeTruthy();
  });

  it("should be able to login to the panel", async () => {
    // First, get the login page to obtain CSRF token
    const loginPageRes = await fetch(`${PANEL_URL}/`, {
      redirect: "manual",
    });
    expect(loginPageRes.status).toBeLessThan(500);
  }, 15000);
});
