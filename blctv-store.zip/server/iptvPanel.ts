/**
 * IPTV Panel Automation — PRO2-OTT
 * Automates user account creation via the web panel.
 * Uses session cookies + CSRF token + AJAX endpoint for bouquets.
 * 
 * Supports two creation modes:
 * - Normal: /lines/create/0 (regular paid accounts)
 * - Trial:  /lines/create/1 (trial/test accounts, 0 credits)
 * 
 * The panel uses jQuery pro-ajax for form submission:
 * - Requires X-Requested-With: XMLHttpRequest header
 * - Returns JSON: { redirect: "..." } on success, { type: "danger", message: "..." } on error
 */
import { ENV } from "./_core/env";

const PANEL_URL = ENV.iptvPanelUrl;
const PANEL_USER = ENV.iptvPanelUsername;
const PANEL_PASS = ENV.iptvPanelPassword;

/** Package IDs from the panel (verified 2026-03-05) */
export const PACKAGES = {
  // FULL PACK — 1 connexion
  "full_1m": { id: "689", label: "FULL PACK | 1 MOIS", connections: 1, trial: false },
  "full_3m": { id: "688", label: "FULL PACK | 3 MOIS", connections: 1, trial: false },
  "full_6m": { id: "686", label: "FULL PACK | 6 MOIS", connections: 1, trial: false },
  "full_12m": { id: "685", label: "FULL PACK | 12 MOIS", connections: 1, trial: false },
  "full_24m": { id: "825", label: "FULL PACK | 24 MOIS", connections: 1, trial: false },
  "full_1w": { id: "834", label: "FULL PACK | 1 WEEK", connections: 1, trial: false },
  "full_48h": { id: "687", label: "FULL PACK | TEST 48H", connections: 1, trial: true },

  // FULL PACK — 2 connexions
  "full2_1m": { id: "791", label: "FULL PACK | 2 CONNEXION | 1 MOIS", connections: 2, trial: false },
  "full2_3m": { id: "790", label: "FULL PACK | 2 CONNEXION | 3 MOIS", connections: 2, trial: false },
  "full2_6m": { id: "789", label: "FULL PACK | 2 CONNEXION | 6 MOIS", connections: 2, trial: false },
  "full2_12m": { id: "788", label: "FULL PACK | 2 CONNEXION | 12 MOIS", connections: 2, trial: false },

  // GOLDEN PACK
  "golden_48h": { id: "817", label: "GOLDEN PACK | TEST 48H", connections: 1, trial: true },
  "golden_1m": { id: "819", label: "GOLDEN PACK | 1 MOIS", connections: 1, trial: false },
  "golden_3m": { id: "818", label: "GOLDEN PACK | 3 MOIS", connections: 1, trial: false },
  "golden_6m": { id: "816", label: "GOLDEN PACK | 6 MOIS", connections: 1, trial: false },
  "golden_12m": { id: "815", label: "GOLDEN PACK | 12 MOIS", connections: 1, trial: false },

  // PACK ABDO (adulte)
  "abdo_48h": { id: "839", label: "PACK ABDO | 48H", connections: 1, trial: true },
  "abdo_1m": { id: "843", label: "PACK ABDO | 1 MOIS", connections: 1, trial: false },
  "abdo_3m": { id: "842", label: "PACK ABDO | 3 MOIS", connections: 1, trial: false },
  "abdo_6m": { id: "841", label: "PACK ABDO | 6 MOIS", connections: 1, trial: false },
  "abdo_12m": { id: "836", label: "PACK ABDO | 12 MOIS", connections: 1, trial: false },

  // SMALL PACK
  "small_48h": { id: "767", label: "SMALL PACK | TEST 48H", connections: 1, trial: true },
  "small_1m": { id: "769", label: "SMALL PACK | 1 MOIS", connections: 1, trial: false },
  "small_3m": { id: "770", label: "SMALL PACK | 3 MOIS", connections: 1, trial: false },
  "small_6m": { id: "771", label: "SMALL PACK | 6 MOIS", connections: 1, trial: false },
  "small_12m": { id: "772", label: "SMALL PACK | 12 MOIS", connections: 1, trial: false },

  // Extensions
  "extend_golden": { id: "820", label: "EXTEND TO GOLDEN PACK", connections: 1, trial: false },
  "extend_full": { id: "822", label: "EXTEND TO FULL PACK", connections: 1, trial: false },
} as const;

export type PackageKey = keyof typeof PACKAGES;

/** Session state for panel authentication */
let sessionCookies: string[] = [];

/** Login to the panel and store session cookies */
async function loginToPanel(): Promise<boolean> {
  try {
    // Step 1: GET login page to get CSRF token and session cookie
    const loginPageRes = await fetch(`${PANEL_URL}/`, {
      redirect: "manual",
      headers: { "User-Agent": "Mozilla/5.0" },
    });

    const setCookies = loginPageRes.headers.getSetCookie?.() || [];
    sessionCookies = setCookies.map((c) => c.split(";")[0]);

    const loginPageHtml = await loginPageRes.text();
    const tokenMatch = loginPageHtml.match(/name="_token"\s+value="([^"]+)"/);
    if (!tokenMatch) {
      console.error("[IPTV Panel] Could not find CSRF token on login page");
      return false;
    }

    // Step 2: POST login credentials
    const formBody = new URLSearchParams({
      _token: tokenMatch[1],
      username: PANEL_USER,
      password: PANEL_PASS,
    });

    const loginRes = await fetch(`${PANEL_URL}/`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Cookie: sessionCookies.join("; "),
        "User-Agent": "Mozilla/5.0",
      },
      body: formBody.toString(),
      redirect: "manual",
    });

    // Update cookies from login response
    const loginSetCookies = loginRes.headers.getSetCookie?.() || [];
    for (const c of loginSetCookies) {
      const cookiePart = c.split(";")[0];
      const cookieName = cookiePart.split("=")[0];
      sessionCookies = sessionCookies.filter(
        (sc) => !sc.startsWith(cookieName + "=")
      );
      sessionCookies.push(cookiePart);
    }

    if (loginRes.status === 302 || loginRes.status === 301) {
      console.log("[IPTV Panel] Login successful");
      return true;
    }

    console.error("[IPTV Panel] Login failed, status:", loginRes.status);
    return false;
  } catch (err) {
    console.error("[IPTV Panel] Login error:", err);
    return false;
  }
}

/** Ensure we have a valid session */
async function ensureLoggedIn(): Promise<boolean> {
  if (sessionCookies.length === 0) {
    return loginToPanel();
  }
  // Quick check: try to access a page
  const res = await fetch(`${PANEL_URL}/lines/create/0/line`, {
    headers: { Cookie: sessionCookies.join("; "), "User-Agent": "Mozilla/5.0" },
    redirect: "manual",
  });
  if (res.status === 302) {
    // Session expired, re-login
    console.log("[IPTV Panel] Session expired, re-logging in...");
    return loginToPanel();
  }
  return true;
}

/**
 * Get CSRF token from the create page, then fetch bouquets via AJAX endpoint.
 * @param packageId - The package ID to fetch bouquets for
 * @param isTrial - Whether this is a trial account (uses /lines/create/1 instead of /lines/create/0)
 */
async function getCreateData(packageId: string, isTrial: boolean = false): Promise<{
  token: string;
  bouquetIds: number[];
  maxConnections: number;
  expireDate: string;
} | null> {
  try {
    if (!(await ensureLoggedIn())) return null;

    // Trial accounts use /lines/create/1, normal accounts use /lines/create/0
    const createMode = isTrial ? "1" : "0";

    // Step 1: GET create page for CSRF token
    const createRes = await fetch(`${PANEL_URL}/lines/create/${createMode}/line`, {
      headers: { Cookie: sessionCookies.join("; "), "User-Agent": "Mozilla/5.0" },
    });
    const createHtml = await createRes.text();
    const tokenMatch = createHtml.match(/name="_token"\s+value="([^"]+)"/);
    if (!tokenMatch) {
      console.error("[IPTV Panel] No CSRF token on create page");
      return null;
    }
    const token = tokenMatch[1];

    // Step 2: Call the AJAX endpoint to get bouquets for this package
    // Trial packages need trial=1 in the request
    const trialParam = isTrial ? "1" : "0";
    const pkgRes = await fetch(`${PANEL_URL}/lines/packages`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Cookie: sessionCookies.join("; "),
        "User-Agent": "Mozilla/5.0",
        "X-Requested-With": "XMLHttpRequest",
        "X-CSRF-TOKEN": token,
      },
      body: `package_id=${packageId}&trial=${trialParam}`,
    });

    if (!pkgRes.ok) {
      console.error("[IPTV Panel] Package endpoint failed:", pkgRes.status);
      return null;
    }

    const pkgData = await pkgRes.json();
    if (!pkgData.result) {
      console.error("[IPTV Panel] Package endpoint returned error:", pkgData);
      return null;
    }

    const bouquetIds = pkgData.bouquets.map((b: { id: number }) => b.id);
    const maxConnections = pkgData.data?.max_connections || 1;
    const expireDate = pkgData.data?.exp_date || "";

    console.log(`[IPTV Panel] Package ${packageId} (trial=${isTrial}): ${bouquetIds.length} bouquets, ${maxConnections} connections, expires ${expireDate}`);

    return { token, bouquetIds, maxConnections, expireDate };
  } catch (err) {
    console.error("[IPTV Panel] Error getting create data:", err);
    return null;
  }
}

/** Generate a random password */
function generatePassword(length = 8): string {
  const chars = "abcdefghijkmnpqrstuvwxyz23456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export interface CreateAccountOptions {
  username?: string;
  password?: string;
  packageKey: PackageKey;
  maxConnections?: number;
  description?: string;
}

export interface CreateAccountResult {
  success: boolean;
  username?: string;
  password?: string;
  packageLabel?: string;
  connections?: number;
  expireDate?: string;
  error?: string;
}

/** Create a new IPTV user account on the panel */
export async function createIPTVAccount(
  options: CreateAccountOptions
): Promise<CreateAccountResult> {
  const pkg = PACKAGES[options.packageKey];
  if (!pkg) {
    return { success: false, error: `Package inconnu: ${options.packageKey}` };
  }

  // Determine if this is a trial package
  const isTrial = pkg.trial;

  // Get CSRF token + bouquets via AJAX (using correct create mode)
  const createData = await getCreateData(pkg.id, isTrial);
  if (!createData) {
    return { success: false, error: "Impossible d'obtenir les données du panel" };
  }

  const password = options.password || generatePassword();
  const connections = options.maxConnections || createData.maxConnections || pkg.connections;

  // Trial accounts use /lines/create/1, normal accounts use /lines/create/0
  const createMode = isTrial ? "1" : "0";

  // Build form body using URLSearchParams for proper encoding
  // The panel's pro-ajax handler serializes the form and sends via $.ajax
  const params = new URLSearchParams();
  params.set("_token", createData.token);
  params.set("line_type", "line");
  params.set("username", options.username || "");
  params.set("password", password);
  params.set("mac", "");
  params.set("forced_country", "");
  params.set("package", pkg.id);
  params.set("connections", String(connections));

  // current_bouquets = comma-separated list of bouquet IDs (what save() does)
  params.set("current_bouquets", createData.bouquetIds.join(","));

  // Also send each bouquet as bouquets[] and bouquets_main[]
  for (const bId of createData.bouquetIds) {
    params.append("bouquets_main[]", String(bId));
    params.append("bouquets[]", String(bId));
  }

  params.set("description", options.description || `Bot Telegram - ${new Date().toISOString()}`);

  console.log(`[IPTV Panel] Creating ${isTrial ? "TRIAL" : "normal"} account: ${options.username || "(auto)"}, package=${pkg.label}, ${createData.bouquetIds.length} bouquets, ${connections} conn`);

  try {
    // Submit via AJAX (like the panel's pro-ajax handler does)
    // This requires X-Requested-With: XMLHttpRequest and returns JSON
    const res = await fetch(`${PANEL_URL}/lines/create/${createMode}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Cookie: sessionCookies.join("; "),
        "User-Agent": "Mozilla/5.0",
        "X-Requested-With": "XMLHttpRequest",
        "X-CSRF-TOKEN": createData.token,
        "Accept": "application/json, text/javascript, */*; q=0.01",
        Referer: `${PANEL_URL}/lines/create/${createMode}/line`,
      },
      body: params.toString(),
      redirect: "manual",
    });

    // Update cookies
    const newCookies = res.headers.getSetCookie?.() || [];
    for (const c of newCookies) {
      const cookiePart = c.split(";")[0];
      const cookieName = cookiePart.split("=")[0];
      sessionCookies = sessionCookies.filter(
        (sc) => !sc.startsWith(cookieName + "=")
      );
      sessionCookies.push(cookiePart);
    }

    console.log(`[IPTV Panel] Create response: status=${res.status}, content-type=${res.headers.get("content-type")}`);

    const responseText = await res.text();

    // Try to parse as JSON (the pro-ajax handler always returns JSON)
    try {
      const json = JSON.parse(responseText);

      // Success: { redirect: "https://.../lines" }
      if (json.redirect) {
        console.log(`[IPTV Panel] Account created successfully! Redirect: ${json.redirect}`);
        return {
          success: true,
          username: options.username || "(auto-generated)",
          password,
          packageLabel: pkg.label,
          connections,
          expireDate: createData.expireDate,
        };
      }

      // Error: { type: "danger", message: "..." }
      if (json.type === "danger") {
        console.error(`[IPTV Panel] Creation error: ${json.message}`);

        // Map common error messages to French
        if (json.message?.includes("already been taken") || json.message?.includes("already exists")) {
          return { success: false, error: "Ce nom d'utilisateur est déjà pris" };
        }
        if (json.message?.includes("Not enough credits") || json.message?.includes("credits")) {
          return { success: false, error: "Pas assez de crédits sur le panel" };
        }
        if (json.message?.includes("package not valid")) {
          return { success: false, error: `Package invalide (ID: ${pkg.id}). Vérifiez les IDs dans le panel.` };
        }

        return { success: false, error: json.message || "Erreur de validation" };
      }

      // Success with type: { type: "success", message: "..." }
      if (json.type === "success") {
        console.log(`[IPTV Panel] Account created successfully! Message: ${json.message}`);
        return {
          success: true,
          username: options.username || "(auto-generated)",
          password,
          packageLabel: pkg.label,
          connections,
          expireDate: createData.expireDate,
        };
      }

      // Unknown JSON response
      console.warn(`[IPTV Panel] Unexpected JSON response:`, json);
      return { success: false, error: `Réponse inattendue du panel: ${JSON.stringify(json).substring(0, 100)}` };

    } catch (parseErr) {
      // Not JSON — might be a 302 redirect (fallback for non-AJAX response)
      if (res.status === 302) {
        const location = res.headers.get("location") || "";
        if (location.includes("/lines") && !location.includes("/lines/create")) {
          console.log(`[IPTV Panel] Account created (302 redirect to users list)`);
          return {
            success: true,
            username: options.username || "(auto-generated)",
            password,
            packageLabel: pkg.label,
            connections,
            expireDate: createData.expireDate,
          };
        }
      }

      console.error(`[IPTV Panel] Non-JSON response (status ${res.status}):`, responseText.substring(0, 200));
      return { success: false, error: `Erreur inattendue (status ${res.status})` };
    }
  } catch (err) {
    console.error("[IPTV Panel] Create account error:", err);
    return { success: false, error: "Erreur de connexion au panel" };
  }
}

/** Check if a username exists in the IPTV panel by searching the Users list */
export async function checkUsernameExists(username: string): Promise<{ exists: boolean; status?: string; expDate?: string }> {
  try {
    if (!(await ensureLoggedIn())) {
      console.error("[IPTV Panel] Cannot login to check username");
      return { exists: false };
    }

    // Search users via the panel's user list page with search parameter
    const searchUrl = `${PANEL_URL}/lines/users?search=${encodeURIComponent(username)}`;
    const res = await fetch(searchUrl, {
      headers: {
        Cookie: sessionCookies.join("; "),
        "User-Agent": "Mozilla/5.0",
      },
    });

    if (!res.ok) {
      console.error("[IPTV Panel] Search users failed:", res.status);
      return { exists: false };
    }

    const html = await res.text();
    
    // Look for the exact username in the table rows
    // The panel renders usernames in <td> cells
    const usernameRegex = new RegExp(`<td[^>]*>\\s*${username.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*</td>`, 'i');
    if (usernameRegex.test(html)) {
      console.log(`[IPTV Panel] Username '${username}' found in panel`);
      
      // Try to extract status and expiry from the same row
      const rowRegex = new RegExp(`<tr[^>]*>[\\s\\S]*?<td[^>]*>\\s*${username.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*</td>[\\s\\S]*?</tr>`, 'i');
      const rowMatch = html.match(rowRegex);
      
      let status = 'Active';
      let expDate = '';
      
      if (rowMatch) {
        // Check for status badges
        if (rowMatch[0].includes('badge-success') || rowMatch[0].includes('Active')) {
          status = 'Active';
        } else if (rowMatch[0].includes('badge-danger') || rowMatch[0].includes('Expired')) {
          status = 'Expired';
        } else if (rowMatch[0].includes('badge-warning') || rowMatch[0].includes('Disabled')) {
          status = 'Disabled';
        }
        
        // Try to extract expiry date
        const dateMatch = rowMatch[0].match(/(\d{4}-\d{2}-\d{2}\s*\d{2}:\d{2})/);
        if (dateMatch) {
          expDate = dateMatch[1];
        }
      }
      
      return { exists: true, status, expDate };
    }
    
    console.log(`[IPTV Panel] Username '${username}' NOT found in panel`);
    return { exists: false };
  } catch (err) {
    console.error("[IPTV Panel] Error checking username:", err);
    return { exists: false };
  }
}

/** Delete a user account from the panel (for cleanup) */
export async function deleteIPTVAccount(username: string): Promise<boolean> {
  console.log(`[IPTV Panel] Manual cleanup needed for user: ${username}`);
  return false;
}
