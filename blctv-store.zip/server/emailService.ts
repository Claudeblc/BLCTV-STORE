/**
 * Email Service — Envoi des identifiants IPTV par email
 * Utilise le Forge API (built-in notification) pour envoyer des emails
 * Fallback: Telegram notification si l'email échoue
 */
import { ENV } from "./_core/env";

interface CredentialEmailData {
  to: string;
  username: string;
  password: string;
  packageLabel: string;
  connections: number;
  expireDate?: string;
}

/**
 * Send IPTV credentials via email using the Forge notification API
 */
export async function sendCredentialEmail(data: CredentialEmailData): Promise<boolean> {
  try {
    const forgeUrl = ENV.forgeApiUrl;
    const forgeKey = ENV.forgeApiKey;

    if (!forgeUrl || !forgeKey) {
      console.warn("[Email] Forge API not configured, skipping email");
      return false;
    }

    const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: Arial, sans-serif; background: #0a0e1a; color: #ffffff; margin: 0; padding: 20px; }
    .container { max-width: 600px; margin: 0 auto; background: #111827; border-radius: 16px; overflow: hidden; border: 1px solid #1e3a5f; }
    .header { background: linear-gradient(135deg, #0066cc, #0099ff); padding: 30px; text-align: center; }
    .header h1 { margin: 0; font-size: 28px; color: white; }
    .header p { margin: 8px 0 0; color: rgba(255,255,255,0.8); font-size: 14px; }
    .content { padding: 30px; }
    .credentials { background: #0d1b2a; border: 1px solid #1e3a5f; border-radius: 12px; padding: 20px; margin: 20px 0; }
    .cred-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #1e3a5f30; }
    .cred-row:last-child { border-bottom: none; }
    .cred-label { color: #60a5fa; font-size: 13px; font-weight: 600; }
    .cred-value { color: #ffffff; font-size: 14px; font-family: monospace; background: #1a2744; padding: 4px 10px; border-radius: 6px; }
    .server-url { background: #0d1b2a; border: 1px solid #1e3a5f; border-radius: 12px; padding: 15px; margin: 15px 0; text-align: center; }
    .server-url .label { color: #60a5fa; font-size: 12px; margin-bottom: 5px; }
    .server-url .url { color: #ffffff; font-size: 16px; font-family: monospace; font-weight: bold; }
    .footer { padding: 20px 30px; text-align: center; color: #6b7280; font-size: 12px; border-top: 1px solid #1e3a5f30; }
    .steps { margin: 20px 0; }
    .step { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 12px; }
    .step-num { background: #0066cc; color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold; flex-shrink: 0; }
    .step-text { color: #d1d5db; font-size: 13px; line-height: 1.5; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>BLCTV Store</h1>
      <p>Vos identifiants IPTV</p>
    </div>
    <div class="content">
      <p style="color: #d1d5db; line-height: 1.6;">
        Bonjour,<br><br>
        Merci pour votre achat ! Voici vos identifiants de connexion pour accéder à votre abonnement IPTV :
      </p>
      
      <div class="credentials">
        <div class="cred-row">
          <span class="cred-label">Nom d'utilisateur</span>
          <span class="cred-value">${data.username}</span>
        </div>
        <div class="cred-row">
          <span class="cred-label">Mot de passe</span>
          <span class="cred-value">${data.password}</span>
        </div>
        <div class="cred-row">
          <span class="cred-label">Package</span>
          <span class="cred-value">${data.packageLabel}</span>
        </div>
        <div class="cred-row">
          <span class="cred-label">Connexions</span>
          <span class="cred-value">${data.connections} appareil(s)</span>
        </div>
        ${data.expireDate ? `
        <div class="cred-row">
          <span class="cred-label">Expiration</span>
          <span class="cred-value">${data.expireDate}</span>
        </div>
        ` : ""}
      </div>

      <div class="server-url">
        <div class="label">URL du serveur</div>
        <div class="url">http://ipro2.pro2-ott.com:80</div>
      </div>

      <div class="steps">
        <p style="color: #ffffff; font-weight: 600; margin-bottom: 12px;">Comment configurer :</p>
        <div class="step">
          <div class="step-num">1</div>
          <div class="step-text">Téléchargez l'application BLCTV Player sur votre appareil</div>
        </div>
        <div class="step">
          <div class="step-num">2</div>
          <div class="step-text">Ouvrez l'application et sélectionnez "Xtream Codes Login"</div>
        </div>
        <div class="step">
          <div class="step-num">3</div>
          <div class="step-text">Entrez l'URL du serveur, votre nom d'utilisateur et mot de passe</div>
        </div>
        <div class="step">
          <div class="step-num">4</div>
          <div class="step-text">Profitez de plus de 10 000 chaînes TV, 25 000 films et 7 000 séries !</div>
        </div>
      </div>

      <p style="color: #9ca3af; font-size: 12px; margin-top: 20px;">
        En cas de problème, contactez notre support via le chat sur notre site web.
      </p>
    </div>
    <div class="footer">
      BLCTV Store — Le meilleur de la télévision en illimité<br>
      <span style="color: #4b5563;">Cet email a été envoyé automatiquement, merci de ne pas y répondre.</span>
    </div>
  </div>
</body>
</html>`;

    // Use the Forge notification API to send email
    const response = await fetch(`${forgeUrl}/v1/notification/email`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${forgeKey}`,
      },
      body: JSON.stringify({
        to: data.to,
        subject: `BLCTV Store — Vos identifiants IPTV (${data.packageLabel})`,
        html: htmlContent,
      }),
      signal: AbortSignal.timeout(15000),
    });

    if (response.ok) {
      console.log(`[Email] Credentials sent to ${data.to}`);
      return true;
    }

    const errorText = await response.text();
    console.error(`[Email] Failed to send: ${response.status} ${errorText}`);
    return false;
  } catch (err) {
    console.error("[Email] Error sending credentials:", err);
    return false;
  }
}
