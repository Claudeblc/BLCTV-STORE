import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("chat router", () => {
  it("should send a message successfully", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.chat.sendMessage({
      sessionId: "test-session-123",
      message: "Hello, this is a test message",
      visitorName: "TestUser",
    });

    expect(result).toEqual({ success: true });
  });

  it("should retrieve messages for a session", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const messages = await caller.chat.getMessages({
      sessionId: "test-session-123",
    });

    expect(Array.isArray(messages)).toBe(true);
    // Should contain at least the message we just sent
    expect(messages.length).toBeGreaterThanOrEqual(1);
    expect(messages.some((m) => m.message === "Hello, this is a test message")).toBe(true);
  });

  it("should reject empty messages", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.chat.sendMessage({
        sessionId: "test-session-123",
        message: "",
      })
    ).rejects.toThrow();
  });

  it("should reject empty session ID", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.chat.sendMessage({
        sessionId: "",
        message: "test",
      })
    ).rejects.toThrow();
  });
});
