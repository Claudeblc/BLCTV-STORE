import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock fetch globally
const mockFetch = vi.fn();
vi.stubGlobal("fetch", mockFetch);

// We test the logic directly since the tRPC procedure calls the XtreamCodes API
describe("verifyClient logic", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should return valid=true for a valid client", async () => {
    const mockResponse = {
      user_info: {
        username: "Chanik97",
        password: "Chanik971",
        auth: 1,
        status: "Active",
        exp_date: "1803263408",
        is_trial: "0",
      },
      server_info: {
        url: "ipro2.pro2-ott.com",
        port: "80",
      },
    };

    mockFetch.mockResolvedValueOnce({
      text: () => Promise.resolve(JSON.stringify(mockResponse)),
    });

    const response = await mockFetch(
      `http://ipro2.pro2-ott.com:80/player_api.php?username=Chanik97&password=Chanik971`
    );
    const text = await response.text();
    const data = JSON.parse(text);

    expect(data.user_info.auth).toBe(1);
    expect(data.user_info.status).toBe("Active");
    expect(data.user_info.username).toBe("Chanik97");
  });

  it("should return empty response for invalid credentials", async () => {
    mockFetch.mockResolvedValueOnce({
      text: () => Promise.resolve(""),
    });

    const response = await mockFetch(
      `http://ipro2.pro2-ott.com:80/player_api.php?username=invalid&password=wrong`
    );
    const text = await response.text();

    expect(text).toBe("");
    // Empty response means invalid credentials
    const valid = text.trim() !== "";
    expect(valid).toBe(false);
  });

  it("should handle network errors gracefully", async () => {
    mockFetch.mockRejectedValueOnce(new Error("Network error"));

    let errorCaught = false;
    try {
      await mockFetch(
        `http://ipro2.pro2-ott.com:80/player_api.php?username=test&password=test`
      );
    } catch {
      errorCaught = true;
    }

    expect(errorCaught).toBe(true);
  });

  it("should parse expiration date correctly", () => {
    const expTimestamp = "1803263408"; // Unix timestamp
    const expDate = new Date(parseInt(expTimestamp) * 1000);
    
    expect(expDate.getFullYear()).toBeGreaterThanOrEqual(2026);
    expect(expDate instanceof Date).toBe(true);
  });

  it("should detect expired/trial clients", async () => {
    const mockResponse = {
      user_info: {
        username: "Test24",
        password: "Test24",
        auth: 1,
        status: "Expired",
        exp_date: "1741230960",
        is_trial: "1",
      },
    };

    mockFetch.mockResolvedValueOnce({
      text: () => Promise.resolve(JSON.stringify(mockResponse)),
    });

    const response = await mockFetch(
      `http://ipro2.pro2-ott.com:80/player_api.php?username=Test24&password=Test24`
    );
    const text = await response.text();
    const data = JSON.parse(text);

    expect(data.user_info.auth).toBe(1);
    expect(data.user_info.status).toBe("Expired");
    expect(data.user_info.is_trial).toBe("1");
  });
});
