import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { createChatMessage, getChatMessagesBySession } from "./db";
import { ENV } from "./_core/env";
import { checkUsernameExists } from "./iptvPanel";

/** Track the last active visitor session for quick admin replies */
export let lastActiveVisitorSession: { sessionId: string; visitorName: string; timestamp: number } | null = null;

export function setLastActiveVisitorSession(sessionId: string, visitorName: string) {
  lastActiveVisitorSession = { sessionId, visitorName, timestamp: Date.now() };
}

/** Send a message to Telegram */
async function sendToTelegram(text: string) {
  const token = ENV.telegramBotToken;
  const chatId = ENV.telegramChatId;
  if (!token || !chatId) return;

  await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      text,
      parse_mode: "HTML",
    }),
  });
}

/** NowPayments API helper */
async function nowpaymentsRequest(endpoint: string, method: string = "GET", body?: unknown) {
  const apiKey = ENV.nowpaymentsApiKey;
  if (!apiKey) throw new Error("NowPayments API key not configured");

  const headers: Record<string, string> = {
    "x-api-key": apiKey,
    "Content-Type": "application/json",
  };

  const response = await fetch(`https://api.nowpayments.io/v1${endpoint}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(15000),
  });

  return response.json();
}

/** Plan definitions */
const PLANS: Record<string, { name: string; amount: number; description: string }> = {
  test6: { name: "Test 7 jours", amount: 6, description: "BLCTV Store — Test 7 jours" },
  "12mois_new": { name: "Abonnement 12 Mois", amount: 150, description: "BLCTV Store — Abonnement 12 Mois" },
  "12mois_renew": { name: "Renouvellement 12 Mois", amount: 100, description: "BLCTV Store — Renouvellement 12 Mois (client existant)" },
  "24mois": { name: "Abonnement 24 Mois", amount: 200, description: "BLCTV Store — Abonnement 24 Mois + Assistance VIP" },
  adultes: { name: "Option Chaînes Adultes", amount: 50, description: "BLCTV Store — Option Chaînes Adultes" },
};

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  chat: router({
    sendMessage: publicProcedure
      .input(
        z.object({
          sessionId: z.string().min(1),
          message: z.string().min(1).max(2000),
          visitorName: z.string().max(100).optional(),
        })
      )
      .mutation(async ({ input }) => {
        await createChatMessage({
          sessionId: input.sessionId,
          message: input.message,
          isFromVisitor: true,
          visitorName: input.visitorName || "Visiteur anonyme",
        });

        const name = input.visitorName || "Visiteur anonyme";
        // Track this as the last active visitor session for quick admin replies
        setLastActiveVisitorSession(input.sessionId, name);

        await sendToTelegram(
          `💬 <b>Nouveau message</b>\n\n` +
            `<b>De:</b> ${name}\n` +
            `<b>Session:</b> <code>${input.sessionId}</code>\n\n` +
            `${input.message}`
        );

        return { success: true };
      }),

    getMessages: publicProcedure
      .input(z.object({ sessionId: z.string().min(1) }))
      .query(async ({ input }) => {
        return getChatMessagesBySession(input.sessionId);
      }),
  }),

  /** Verify if a client exists in the IPTV panel */
  verifyClient: publicProcedure
    .input(
      z.object({
        username: z.string().min(1).max(100),
        password: z.string().min(1).max(100),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const response = await fetch(
          `http://ipro2.pro2-ott.com:80/player_api.php?username=${encodeURIComponent(input.username)}&password=${encodeURIComponent(input.password)}`,
          { signal: AbortSignal.timeout(10000) }
        );
        const text = await response.text();
        if (!text || text.trim() === "") {
          return { valid: false, message: "Identifiants incorrects. Vérifiez votre nom d'utilisateur et mot de passe." };
        }
        const data = JSON.parse(text);
        if (data?.user_info?.auth === 1) {
          const status = data.user_info.status;
          const expDate = data.user_info.exp_date
            ? new Date(parseInt(data.user_info.exp_date) * 1000).toLocaleDateString("fr-FR")
            : "Inconnue";
          return {
            valid: true,
            message: `Client vérifié ! Statut: ${status}, Expiration: ${expDate}`,
            username: data.user_info.username,
            status,
            expDate,
          };
        }
        return { valid: false, message: "Identifiants incorrects. Vérifiez votre nom d'utilisateur et mot de passe." };
      } catch {
        return { valid: false, message: "Erreur de vérification. Veuillez réessayer." };
      }
    }),

  /** Verify if a username exists in the IPTV panel (for web player access) */
  verifyUsername: publicProcedure
    .input(
      z.object({
        username: z.string().min(1).max(100),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const result = await checkUsernameExists(input.username.trim());
        if (result.exists) {
          return {
            valid: true,
            message: "Acc\u00e8s autoris\u00e9 ! Redirection vers BLC TV Player...",
            username: input.username.trim(),
            status: result.status,
            expDate: result.expDate,
          };
        }
        return {
          valid: false,
          message: "Nom d'utilisateur non reconnu. V\u00e9rifiez votre identifiant ou souscrivez \u00e0 un abonnement.",
        };
      } catch {
        return { valid: false, message: "Erreur de v\u00e9rification. Veuillez r\u00e9essayer." };
      }
    }),

  /** Payment routes */
  payment: router({
    /** Create a NowPayments invoice and return the invoice URL */
    createInvoice: publicProcedure
      .input(
        z.object({
          planId: z.enum(["test6", "12mois_new", "12mois_renew", "24mois", "adultes"]),
          email: z.string().email().optional(),
          origin: z.string().min(1),
        })
      )
      .mutation(async ({ input }) => {
        const plan = PLANS[input.planId];
        if (!plan) throw new Error("Plan inconnu");

        const orderId = `${input.planId}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

        const invoice = await nowpaymentsRequest("/invoice", "POST", {
          price_amount: plan.amount,
          price_currency: "eur",
          order_id: orderId,
          order_description: plan.description,
          success_url: `${input.origin}/paiement/succes?order=${orderId}&plan=${input.planId}`,
          cancel_url: `${input.origin}/paiement/annule`,
          customer_email: input.email || undefined,
          is_fee_paid_by_user: false,
        });

        if (!invoice?.invoice_url) {
          throw new Error("Erreur lors de la création du paiement");
        }

        // Notify owner on Telegram
        await sendToTelegram(
          `💰 <b>Nouvelle commande</b>\n\n` +
            `<b>Offre:</b> ${plan.name}\n` +
            `<b>Montant:</b> ${plan.amount}€\n` +
            `<b>ID:</b> <code>${orderId}</code>\n` +
            `<b>Email:</b> ${input.email || "Non fourni"}\n` +
            `<b>Statut:</b> En attente de paiement`
        );

        return {
          invoiceUrl: invoice.invoice_url as string,
          invoiceId: invoice.id as string,
          orderId,
          amount: plan.amount,
          planName: plan.name,
        };
      }),

    /** Check payment status */
    checkStatus: publicProcedure
      .input(z.object({ paymentId: z.string().min(1) }))
      .query(async ({ input }) => {
        const data = await nowpaymentsRequest(`/payment/${input.paymentId}`);
        return {
          status: data.payment_status as string,
          amount: data.price_amount as number,
          currency: data.price_currency as string,
        };
      }),

    /** Get plan info */
    getPlans: publicProcedure.query(() => {
      return Object.entries(PLANS).map(([id, plan]) => ({
        id,
        name: plan.name,
        amount: plan.amount,
        description: plan.description,
      }));
    }),
  }),
});

export type AppRouter = typeof appRouter;
