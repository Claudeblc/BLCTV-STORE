import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock the iptvPanel module
vi.mock("./iptvPanel", () => ({
  checkUsernameExists: vi.fn(),
}));

import { checkUsernameExists } from "./iptvPanel";
const mockCheckUsername = vi.mocked(checkUsernameExists);

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("verifyUsername", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("returns valid=true when username exists in the panel", async () => {
    mockCheckUsername.mockResolvedValue({
      exists: true,
      status: "Active",
      expDate: "2026-12-31 23:59",
    });

    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.verifyUsername({ username: "testuser123" });

    expect(result.valid).toBe(true);
    expect(result.message).toContain("Accès autorisé");
    expect(result.username).toBe("testuser123");
    expect(result.status).toBe("Active");
    expect(result.expDate).toBe("2026-12-31 23:59");
    expect(mockCheckUsername).toHaveBeenCalledWith("testuser123");
  });

  it("returns valid=false when username does not exist", async () => {
    mockCheckUsername.mockResolvedValue({ exists: false });

    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.verifyUsername({ username: "unknownuser" });

    expect(result.valid).toBe(false);
    expect(result.message).toContain("non reconnu");
    expect(mockCheckUsername).toHaveBeenCalledWith("unknownuser");
  });

  it("trims whitespace from username before checking", async () => {
    mockCheckUsername.mockResolvedValue({ exists: true, status: "Active" });

    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.verifyUsername({ username: "  testuser  " });

    expect(result.valid).toBe(true);
    expect(result.username).toBe("testuser");
    expect(mockCheckUsername).toHaveBeenCalledWith("testuser");
  });

  it("returns error message when panel check throws", async () => {
    mockCheckUsername.mockRejectedValue(new Error("Network error"));

    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.verifyUsername({ username: "testuser" });

    expect(result.valid).toBe(false);
    expect(result.message).toContain("Erreur de vérification");
  });

  it("rejects empty username with validation error", async () => {
    const caller = appRouter.createCaller(createPublicContext());

    await expect(caller.verifyUsername({ username: "" })).rejects.toThrow();
  });
});
