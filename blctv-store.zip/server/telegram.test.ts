import { describe, expect, it } from "vitest";

describe("Telegram Bot Token", () => {
  it("should be able to call getMe on the Telegram bot", async () => {
    const token = process.env.TELEGRAM_BOT_TOKEN;
    expect(token).toBeTruthy();

    const res = await fetch(`https://api.telegram.org/bot${token}/getMe`);
    const data = await res.json();

    expect(data.ok).toBe(true);
    expect(data.result).toBeDefined();
    expect(data.result.is_bot).toBe(true);
    console.log("Bot username:", data.result.username);
  });

  it("should have a valid chat ID configured", () => {
    const chatId = process.env.TELEGRAM_CHAT_ID;
    expect(chatId).toBeTruthy();
    expect(Number(chatId)).toBeGreaterThan(0);
  });
});
